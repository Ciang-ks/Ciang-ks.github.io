# 参考资料

讲义自包含，进一步阅读可按章节末尾的参考链接选择。实验所用公开数据的来源和字段见[数据说明](data/README.md)。

- [MIT 18.600 概率论](https://ocw.mit.edu/courses/18-600-probability-and-random-variables-fall-2019/)
- [MIT 18.650 统计](https://ocw.mit.edu/courses/18-650-statistics-for-applications-fall-2016/)
- [Stanford CS229](https://cs229.stanford.edu/)
- [QuantEcon](https://quantecon.org/)
