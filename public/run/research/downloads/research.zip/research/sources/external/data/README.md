# Notebook 实验数据

这些文件是 2026-10-03 通过受控网络下载后固定在仓库中的小型公开数据快照，notebook 默认只读本地文件，不在执行时联网。

| 文件 | 来源和内容 | 处理 |
|---|---|---|
| `yahoo_sp500.csv` | Yahoo Finance chart endpoint, `^GSPC`, daily OHLCV, 2010-01-04–2025-10-08 | 保留原始字段；notebook 使用 close |
| `yahoo_tnx.csv` | Yahoo Finance chart endpoint, `^TNX`, 10-year Treasury yield index, same dates | close 解释为收益率指数，不是债券总回报 |
| `vix_daily.csv` | GitHub `datasets/finance-vix` 的公开 VIX daily 数据，1990-01-02–2026-09-22 | 使用 close；不把 VIX 当可直接交易的现货资产 |

下载源的字段、时间范围和本地处理见 `research/lectures/notebook_helpers.py`。Yahoo chart 数据可能包含供应商更正；再次下载时应保存新的快照和日期，而不是覆盖本文件后声称实验完全相同。

## SHA-256（本地快照）

```text
a51ca6c16359298e133c3605b2daba49d70ca8a9ef889c6269324b533d8c4441  vix_daily.csv
9ad732b1987957fdaa6b7bcb5b85f00179b70ad0f3d6657313a3cd2bcb7e445e  yahoo_sp500.csv
4e29dc43d9faac6c31dd4e85706e77ce0cd42b08774569c24c3a54b26c1c8c8f  yahoo_tnx.csv
```

## Download endpoints

- `https://query1.finance.yahoo.com/v8/finance/chart/%5EGSPC?period1=1262304000&period2=1760000000&interval=1d&events=history`
- `https://query1.finance.yahoo.com/v8/finance/chart/%5ETNX?period1=1262304000&period2=1760000000&interval=1d&events=history`
- `https://raw.githubusercontent.com/datasets/finance-vix/master/data/vix-daily.csv`
