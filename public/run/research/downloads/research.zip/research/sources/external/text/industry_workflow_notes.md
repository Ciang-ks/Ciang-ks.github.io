# Man AHL、AQR、WorldQuant BRAIN 与 Quant Wiki：选择性阅读笔记

下载/阅读日期：2026-10-04（Asia/Singapore）。这些笔记是对公开页面和公开论文的研究摘要，不是对任何公司的内部流程或业绩承诺。原文中的数值、样本区间和策略定义不能直接当作可投资结论。

## 1. Man AHL：把研究问题放进可交付的系统

来源：Man AHL 官方页面 <https://www.man.com/ahl>。

页面明确把 Man AHL 描述为 researchers、developers、traders 的协作，并强调四个与初学者最相关的工作事实：

1. **Diversification（分散化）** 不只是在组合层面买很多资产，也包括研究更多市场、更多信号和不同的模型时间尺度。页面提到 momentum 方案覆盖 800+ markets；这说明“一个股票上的一个信号”只是研究起点。
2. **Risk control is built into models（风险控制内置于模型）**。风险团队、独立风险系统、仓位和组合限制与 alpha 同时设计，而不是回测结束后才加一个止损。
3. **Research-to-production technology** 横跨 market-data acquisition、initial research、model implementation 和 trade execution。研究代码、数据平台和生产代码的边界需要可追溯，而不是一份孤立 notebook。
4. **Execution is a research object（执行也是研究对象）**。页面提到 order netting、自动化 flow、多个 counterparties、备用交易中心和多条执行路线；这对应教学中的 turnover、TCA、容量和故障切换。

因此本课程只吸收一个流程模板：`hypothesis → point-in-time data → signal diagnostics → portfolio/risk → cost-aware replay → paper/shadow → production gate → monitoring`。它不意味着学生要复刻 Man AHL 的基础设施。

## 2. AQR：跨资产结构比单市场漂亮曲线更重要

来源：

- Hurst, Ooi, Pedersen, *A Century of Evidence on Trend-Following Investing*（公开论文 PDF，AQR 作者版本/镜像）；DOI <https://doi.org/10.2139/ssrn.2993026>。
- Asness, Moskowitz, Pedersen, *Value and Momentum Everywhere*（作者/NBER 公开 PDF）；DOI <https://doi.org/10.2139/ssrn.2174501>。

只保留三条对研究流程有直接帮助的结论：

1. 趋势研究的核心不是“某个 lookback 最优”，而是定义**时间序列动量（time-series momentum）**、跨股票指数/债券/商品/货币分散、逐市场波动缩放、组合目标波动，并把交易成本和费用扣除。AQR 的长期研究把 `signal → volatility scaling → portfolio aggregation → net returns` 写成一条可复核链。
2. Value 与 momentum 在多个资产类别上都可定义；同类信号跨市场往往相关，而 value 与 momentum 在很多组合中呈负相关。研究者应先画信号相关矩阵和危机状态表现，再决定是否把两个信号合并，而不是只比较单策略 Sharpe。
3. 长样本、跨资产和成本假设改变了证据强度。论文中的历史证据支持“值得研究的结构”，不保证今天仍有同样收益；应把样本外、容量、流动性状态和参数自由度写进结论。

在讲义中，这些材料被转译为 **breadth、signal correlation、alpha decay、risk budget、cost sensitivity** 五个可计算诊断。

## 3. WorldQuant BRAIN：把 alpha expression 当成实验配置

来源：WorldQuant BRAIN 公开平台 <https://platform.worldquantbrain.com/>。平台是 JavaScript 应用；本地保存的入口和公开静态 bundle 只用于核对页面上可见的配置/指标名称：`sources/external/html/worldquant/worldquant_brain.html`、`sources/external/html/worldquant/index.js`。没有把需要登录的接口或内部阈值当作公开文档。

公开界面能观察到的研究对象包括：

- **expression / data field / universe / region / delay**：一个 alpha 不是只有公式，还绑定数据字段、资产宇宙、地区和信息延迟；这些字段必须进入实验配置。
- **decay、truncation、neutralization、pasteurization、NaN/unit handling**：同一表达式在不同衰减、极值截断、行业/市场中性化和缺失值规则下是不同的策略。
- **coverage、turnover、Sharpe、fitness、drawdown、margin、correlation**：平台同时展示预测/收益、可交易性和与已有 alpha 的相关性；单一 Sharpe 不能决定是否保留表达式。

课程只借用一个面试级别的启发式：把每个表达式视为**可审计实验**，固定原始字段、变换、延迟、截断、中性化、成本和评价窗口，并把复杂度、换手、覆盖率和与已有信号的相关性一起记录。`fitness` 是平台特定的复合诊断，不能在课程中随意宣称一个通用公式。

## 4. Quant Wiki：回测的最低诚实标准

来源：<https://quant-wiki.com/start/>；官方网站在本次网络环境返回 403，因此通过其公开 GitHub 仓库 `LLMQuant/quant-wiki` 的原始 Markdown 核对内容：<https://github.com/LLMQuant/quant-wiki>。

只采用以下必要提醒：

- 回测应保留样本外/前瞻纸面交易；真实可交易的历史宇宙需要考虑退市、清算和幸存者偏差。
- 成本必须进入回测；大量尝试后选择最高 Sharpe 是数据挖掘，不能把它称为验证。
- 多因子组合可以采用独立组合后合并、顺序筛选或交叉排序；选择哪一种会改变暴露、换手和解释，应作为 ablation 而不是隐含实现细节。

## 5. 研究流程中的概念

| 概念 | 最小定义 | 对应章节/项目 |
|---|---|---|
| Alpha decay / half-life | 信号预测不同持有期的 IC 或 spread 如何衰减 | 第 05 章、项目 A Milestone 2 |
| Breadth / ICIR | 独立下注数量与 IC 稳定度；`IR≈IC√Breadth` 只是有条件的近似 | 第 05 章、项目 A Milestone 4 |
| Signal correlation / crowding | 信号之间的相关性、共同暴露和危机时相关性上升 | 第 05–06 章、项目 A Milestone 4 |
| Turnover-aware portfolio | 优化目标中加入旧仓位距离或交易成本惩罚 | 第 06 章、项目 A Milestone 3 |
| TCA / implementation shortfall | 把 spread、fee、impact、delay/opportunity cost 分开 | 第 06 章、项目 A Milestone 3 |
| Expression audit | 记录 field、universe、delay、decay、neutralization、coverage 与复杂度 | 第 05、07 章、项目 B Milestone 4 |
| Research-to-production gate | paper/shadow、监控、回滚条件和版本/数据 lineage | 第 09 章、两个项目最终验收 |

其余名词暂不扩展，避免把课程变成不具备练习入口的术语列表。
