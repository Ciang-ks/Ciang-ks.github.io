# 从 0 开始的量化研究

从市场与资产出发，把一个研究问题变成可复现的实验。适合有数学和编程基础、金融经验较少的读者。

- [学习路线与阅读指南](roadmap.md)
- [基础讲义](lectures.md)
- [项目 A：跨资产 Alpha 与组合研究](projects/alpha_research/README.md)
- [项目 B：ML/LLM 增量研究](projects/ml_llm_research/README.md)
- [Notebook 与项目下载](downloads.md)
