# Notebook 与项目下载

[下载完整实验包](downloads/research.zip){ .md-button .md-button--primary }

包含九章讲义 Notebook、两个项目的源码与实验 Notebook，以及公开数据本地快照。默认实验不联网；可选的语义模型需另行安装。

解压后，在 `research/` 中运行：

```sh
uv venv --python 3.13 .venv
uv pip install --python .venv/bin/python -r requirements-notebooks.txt -r projects/alpha_research/requirements.txt -r projects/ml_llm_research/requirements.txt
.venv/bin/python -m jupyterlab .
```

| 讲义 | Notebook |
|---|---|
| 第一章：市场、资产与交易对象 | [下载](lectures/01-markets-assets.ipynb) |
| 第二章：收益、风险、组合与绩效 | [下载](lectures/02-returns-risk.ipynb) |
| 第三章：金融计量、时序建模与随机微积分 | [下载](lectures/03-probability-statistics.ipynb) |
| 第四章：数据、偏差与量化研究管线 | [下载](lectures/04-data-pipeline.ipynb) |
| 第五章：策略、Alpha 与信号研究 | [下载](lectures/05-strategies-alpha.ipynb) |
| 第六章：组合构建、执行与风险控制 | [下载](lectures/06-portfolio-execution.ipynb) |
| 第七章：机器学习用于量化研究 | [下载](lectures/07-machine-learning.ipynb) |
| 第八章：LLM4Quant 与文本研究 | [下载](lectures/08-language-models.ipynb) |
| 第九章：全链路项目、岗位能力与面试表达 | [下载](lectures/09-research-communication.ipynb) |

| 项目 | 实验 Notebook |
|---|---|
| 项目 A | [下载实验 Notebook](projects/alpha_research/project_lab.ipynb) |
| 项目 B | [下载实验 Notebook](projects/ml_llm_research/project_lab.ipynb) |

单独下载 Notebook 时，还需从完整实验包取得辅助代码和数据。项目的运行方式、研究边界和练习安排见各自说明。
