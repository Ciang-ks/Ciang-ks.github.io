# 基础讲义

先理解概念，再手推一个例子，最后运行对应实验。

| 章节 | 讲义 |
|---|---|
| 01 | [市场、资产与交易对象](lectures/01-markets-assets.ipynb) |
| 02 | [收益、风险、组合与绩效](lectures/02-returns-risk.ipynb) |
| 03 | [概率、统计推断与回归](lectures/03-probability-statistics.ipynb) |
| 04 | [数据、偏差与量化研究管线](lectures/04-data-pipeline.ipynb) |
| 05 | [策略、Alpha 与信号研究](lectures/05-strategies-alpha.ipynb) |
| 06 | [组合构建、执行与风险控制](lectures/06-portfolio-execution.ipynb) |
| 07 | [机器学习用于量化研究](lectures/07-machine-learning.ipynb) |
| 08 | [LLM4Quant 与文本研究](lectures/08-language-models.ipynb) |
| 09 | [全链路项目、岗位能力与面试表达](lectures/09-research-communication.ipynb) |

[学习路线](roadmap.md) · [Notebook 与项目下载](downloads.md)
