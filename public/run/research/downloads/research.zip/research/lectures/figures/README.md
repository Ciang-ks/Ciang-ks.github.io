# 讲义插图目录

本目录里的每张图都由 `lectures/make_figures.py` 或章节 notebook 在本仓库内生成。**没有引用任何第三方图片**，因此不存在转载许可问题；如果你要加入教材或百科的截图，必须新建 `SOURCES.md` 记录来源、作者、许可和访问日期，并把原图保存到本地而不是外链。

## 重新生成

```bash
cd research
.venv/bin/python lectures/make_figures.py            # 全部章节
.venv/bin/python lectures/make_figures.py --chapter 01 02
.venv/bin/python lectures/make_figures.py --list      # 只列出注册表
.venv/bin/python lectures/check_figures.py            # 校验引用、清单与可复现性
```

当前渲染环境：matplotlib 3.11.2，style `seaborn-v0_8-whitegrid`，dpi 150，图内文字语言 `zh`（CJK 字体 `WenQuanYi Zen Hei`）。缺少中文字体时脚本不会报错，只会改用英文标签，因此图在任何机器上都能生成。

## 四种数据类型（每张图都必须归入其中一种）

| kind | 含义 |
|---|---|
| `concept` | 概念示意图（手绘数据，只说明结构，不代表任何真实市场数值） |
| `synthetic` | 确定性合成教学数据（由固定 seed 生成，非真实行情） |
| `public_data` | 公开数据本地快照（sources/external/data，非实时、不构成投资建议） |
| `project_output` | 本仓库项目的可复现输出（合成数据 + 固定 pipeline，非真实交易结果） |

图内和图注都必须写清数据类型：概念示意图不是行情，合成数据不是历史，项目输出不是真实交易结果，任何图都不构成投资建议。

## 脚本生成的插图

| 文件 | 章节 | 位置 | 类型 | 说明 | 附注 | SHA-256（前 12 位） |
|---|---|---|---|---|---|---|
| `ch01_candle_anatomy.png` | 01 市场、资产与交易对象 | §2.1 OHLCV 的含义 | `concept` | 一根 K 线的四个价格：实体与上下影线 | 数值为手绘示意，不对应任何真实证券。 | `e19956b00579` |
| `ch01_real_sp500_bars.png` | 01 市场、资产与交易对象 | §2.1 OHLCV 的含义 | `public_data` | 真实 S&P 500 日线 OHLCV（2020 年 2–4 月本地快照） | Yahoo Finance ^GSPC 本地快照，2020-02-24 至 2020-04-03；教学用途，不构成投资建议。 | `05295d8e69ea` |
| `ch01_quote_ladder.png` | 01 市场、资产与交易对象 | §2.2 Bid、ask、mid 和 spread | `concept` | 买卖报价阶梯：mid、spread 与立即成交的半个价差成本 | 示例报价为手绘数值，用于说明字段含义。 | `5ac1836b7d5e` |
| `ch01_raw_vs_adjusted.png` | 01 市场、资产与交易对象 | §3.2 公司行动（corporate actions） | `synthetic` | 拆股与分红如何造成 raw close 与 adjusted close 的差别 | 由固定 seed 生成的合成价格，用于展示复权口径差异。 | `804cf2c248e5` |
| `ch01_bond_cashflows.png` | 01 市场、资产与交易对象 | §4.1 债券的现金流 | `concept` | 息票债券现金流时间线与两种收益率下的价格 | 面值 100、年息票 4、5 年期；价格为公式计算结果，非市场报价。 | `59a8dbbcfe41` |
| `ch01_term_structure.png` | 01 市场、资产与交易对象 | §6.2 Contango 与 backwardation 的例子 | `concept` | Contango 与 backwardation 的期货曲线及展期收益方向 | 曲线为手绘示例点位，用于说明期限结构与展期成本方向。 | `f75789da1519` |
| `ch01_option_payoffs.png` | 01 市场、资产与交易对象 | §8.1 到期收益 | `concept` | 期权到期 payoff 与含权利金的净利润：四种基本头寸 | 执行价 K=100，call 权利金 6、put 权利金 4；数值为公式计算示例。 | `41c1b6274d61` |
| `ch02_simple_vs_log.png` | 02 收益、风险、组合与绩效 | §1.2 Log return（对数收益） | `synthetic` | 同一段价格路径：simple return 相加会错，log return 相加才对 | 合成路径：100 → 50 → 100，两段 simple return 之和为 +50%，但财富没有变化。 | `4dd0374471b6` |
| `ch02_vol_drag.png` | 02 收益、风险、组合与绩效 | §2. 复利、财富曲线和路径 | `synthetic` | 同样的平均日收益、不同的波动：复利终点不同（波动拖累） | 两条合成路径的算术平均日收益相同，高波动路径终点财富更低，差额约 σ²/2 每天。 | `276ef01b310b` |
| `ch02_vol_clustering.png` | 02 收益、风险、组合与绩效 | §3.2 年化波动的条件 | `public_data` | 真实 S&P 500 日收益与 60 日滚动年化波动：波动是聚集的 | Yahoo Finance ^GSPC 本地快照；教学用途，不构成投资建议。 | `55bd646e7c7b` |
| `ch02_correlation_diversification.png` | 02 收益、风险、组合与绩效 | §4.2 组合收益与协方差矩阵 | `synthetic` | 相关性如何决定分散化：散点与组合波动随权重的变化 | 左图为固定 seed 的二元正态样本；右图由两资产波动与相关系数公式直接计算。 | `b3fc2577cf49` |
| `ch02_drawdown_real.png` | 02 收益、风险、组合与绩效 | §6. 回撤（Drawdown）与恢复 | `public_data` | 真实 S&P 500 财富曲线与水下曲线：最大回撤与恢复时间 | Yahoo Finance ^GSPC 本地快照（2010–2025）；教学用途，不构成投资建议。 | `db40a328d6cc` |
| `ch02_var_cvar.png` | 02 收益、风险、组合与绩效 | §8. VaR、CVaR 与压力测试 | `public_data` | 真实日收益分布上的 5% VaR 与 CVaR（尾部平均损失） | Yahoo Finance ^GSPC 本地快照；历史 VaR 不是未来承诺，尾部还会更坏。 | `1cbc37d864da` |
| `ch03_fat_tails.png` | 03 概率、统计推断与回归 | §3.2 Normal 与 Student-t | `public_data` | 真实日收益的尾部比正态厚：对数刻度下的直方图对照 | Yahoo Finance ^GSPC 本地快照；表中计数为样本内事实，不是未来概率。 | `e102446abd0d` |
| `ch03_lln_clt.png` | 03 概率、统计推断与回归 | §4.2 中心极限定理（CLT） | `synthetic` | LLN：样本均值收敛到期望；CLT：标准化后的均值分布趋近正态 | 固定 seed 的合成日收益样本；左图带 ±2σ/√n 收敛带，右图为 2000 次重复抽样。 | `9430c2871b2f` |
| `ch03_ci_coverage.png` | 03 概率、统计推断与回归 | §5.1 置信区间的正确解释 | `synthetic` | 95% 置信区间的含义：100 次重复里约 95 次覆盖真值 | 固定 seed 的 100 次独立抽样，真值 μ = 0；未覆盖的区间标红。 | `9ce862d5caa3` |
| `ch03_pvalue_null.png` | 03 概率、统计推断与回归 | §5.2 Null、alternative 和 p-value | `synthetic` | p-value 的几何含义：零假设下比观测更极端的概率 | 零假设为均值 0、标准误 0.004；观测统计量 0.0078，双尾 p 由正态尾部面积计算。 | `295fd131b943` |
| `ch03_ols_residuals.png` | 03 概率、统计推断与回归 | §6.3 R² 和残差 | `synthetic` | 一元 OLS：拟合线、残差茎与残差—拟合值检查图 | 固定 seed 合成样本；R² 与残差统计由样本计算，用于说明解释与预测的区别。 | `9bec874d1ae6` |
| `ch03_multiple_testing.png` | 03 概率、统计推断与回归 | §10. Multiple testing 与研究者自由度 | `synthetic` | 数据窥探：20 个纯噪声策略里最好的 t 统计量经常超过 2 | 固定 seed 的 4000 次模拟，每次 20 个独立零信号策略；比较单个 t 与最大 t 的分布。 | `9b18391ffd94` |
| `ch04_three_timestamps.png` | 04 数据、偏差与量化研究管线 | §1.2 三个时间必须分开 | `concept` | 报告期末、披露时间、可交易时间：三个必须分开的时间戳 | 时间轴为示意；真实研究中这三个时间可能相差数周到数月。 | `be841c785ba7` |
| `ch04_survivorship.png` | 04 数据、偏差与量化研究管线 | §3.1 Survivorship bias（幸存者偏差） | `synthetic` | 幸存者偏差：只用活到今天的成分会系统性高估历史收益 | 固定 seed 合成 universe：8 个成分中 3 个中途退市（退市前收益为负）。 | `37b5404fd29b` |
| `ch04_lookahead_alignment.png` | 04 数据、偏差与量化研究管线 | §3.2 Look-ahead bias（前视偏差） | `synthetic` | 信号对齐错了会制造假 IC：r_t 与 r_{t+1} 的差别 | 固定 seed 合成 AR(1) 信号；leak 版把信号与同日收益配对，正确版与次日收益配对。 | `7889b75b3e39` |
| `ch04_time_splits.png` | 04 数据、偏差与量化研究管线 | §5.3 Purged 和 embargo split | `concept` | 三种时间切分：单次 holdout、walk-forward、purged + embargo | 色块表示训练/验证/测试区间；embargo 是为重叠标签留出的隔离带。 | `d0da7aabe941` |
| `ch04_signal_to_fill.png` | 04 数据、偏差与量化研究管线 | §6.1 Signal、position、order、fill | `concept` | 从信号到成交的时间链：哪一天的收益才属于这个信号 | 时刻为示意（收盘 16:00、次日开盘 09:30）；重点是收益归属区间。 | `e188087d37e0` |
| `ch05_trend_real_spx.png` | 05 策略、Alpha 与信号研究 | §3.1 经济直觉 | `public_data` | 真实 S&P 500 上的 12 个月趋势规则：信号只用过去价格，仓位滞后一天 | Yahoo Finance ^GSPC 本地快照；教学示例规则，不构成投资建议。 | `5ebf23a0937e` |
| `ch05_signal_heatmap.png` | 05 策略、Alpha 与信号研究 | §3.2 关键设计 | `project_output` | 项目 A 合成面板上的 60 日动量信号：状态持续与资产差异 | 由 projects/alpha_research 的固定 seed 面板在进程内重算，不读取 outputs 目录。 | `cb98bf9a0268` |
| `ch05_rebalance_weights.png` | 05 策略、Alpha 与信号研究 | §4. Cross-Sectional Momentum（截面动量） | `project_output` | 一次再平衡日：截面排序如何变成带约束的权重 | 项目 A 合成面板；权重 = 信号/|信号|之和，再按 ±25% 截断。 | `46f4ce89e0d0` |
| `ch05_mean_reversion_zscore.png` | 05 策略、Alpha 与信号研究 | §5.1 直觉和风险 | `synthetic` | 均值回归的 z-score 与 ±2 触发带：价差会回归，也可能不回归 | 固定 seed 合成价差：前段围绕均值波动，后段加入结构性漂移以展示失败模式。 | `82dbfd27a9cb` |
| `ch05_ic_horizon_decay.png` | 05 策略、Alpha 与信号研究 | §10. Step 3：测量 signal quality | `project_output` | 信号质量随持有期衰减：rank IC 与 horizon 的关系 | 项目 A 合成面板上计算：信号为 60 日动量/波动，标签为未来 h 日收益。 | `5b915d9f83db` |
| `ch05_score_to_weight.png` | 05 策略、Alpha 与信号研究 | §10. Step 5：从分数到仓位 | `concept` | 从 raw score 到最终权重：标准化、截断、归一化三步 | 六个示例分数为手写数值，用于展示约束如何改变权重。 | `00d9ad6f653c` |
| `ch06_vol_targeting.png` | 06 组合构建、执行与风险控制 | §2.1 Volatility targeting | `public_data` | 波动率目标如何自动去杠杆： realized vol 上升时仓位倍数下降 | Yahoo Finance ^GSPC 本地快照；目标年化波动 10%，仓位倍数上限 2、下限 0.2。 | `63dde6ecbf9b` |
| `ch06_risk_contribution.png` | 06 组合构建、执行与风险控制 | §2.2 Risk parity | `project_output` | 等权 vs 逆波动权重：权重份额与风险贡献份额的差别 | 项目 A 合成面板的样本协方差；风险贡献 = w_i (Σw)_i / w'Σw。 | `807889791231` |
| `ch06_book_walk.png` | 06 组合构建、执行与风险控制 | §4.2 订单簿和成交概率 | `concept` | 大单吃穿订单簿：平均成交价为什么差于 mid | 手写五档卖单；市价买单 6,000 股逐档成交，计算平均成交价与冲击。 | `251defba574c` |
| `ch06_cost_monotonicity.png` | 06 组合构建、执行与风险控制 | §6.3 Cost-aware backtest | `project_output` | 成本单调性：同一策略在 0/10/25/50 bps 下的净值与 Sharpe | 项目 A 固定 pipeline 在进程内重算；成本越高净值越低是必须通过的不变量。 | `414d7dba65ff` |
| `ch06_pnl_decomposition.png` | 06 组合构建、执行与风险控制 | §7. PnL、风险归因与监控 | `project_output` | PnL 分解：毛收益、成本拖累与净收益三条累计曲线 | 项目 A 10 bps 成本情景；成本累计曲线单调向下，是会计正确性的检查项。 | `286541c2cc05` |
| `ch07_label_overlap.png` | 07 机器学习用于量化研究 | §3.4 Label horizon 与 overlap | `concept` | 重叠标签为什么需要 purge 与 embargo | 标签为未来 5 日收益；相邻样本的标签窗口互相重叠。 | `7acdf1a6b2fc` |
| `ch07_bias_variance.png` | 07 机器学习用于量化研究 | §5. Bias-variance 与模型选择 | `synthetic` | 模型复杂度与 train/test 误差：U 形曲线与过拟合区 | 固定 seed 合成数据，多项式阶数 1–12；test 误差最低点才是可选复杂度。 | `9e7e1cd86104` |
| `ch07_calibration.png` | 07 机器学习用于量化研究 | §8. Calibration、uncertainty 与 position sizing | `synthetic` | 校准曲线：预测概率与实现频率是否一致 | 固定 seed 合成分类器输出；raw 模型过度自信，缩放后贴近对角线。 | `878f3e7be0cc` |
| `ch07_feature_drift.png` | 07 机器学习用于量化研究 | §10. Drift、retraining 与 model governance | `synthetic` | 特征漂移：同一特征在不同年份的分布会移动 | 固定 seed 合成特征，2021 年起均值与方差同时变化；标注两年间 KS 统计量。 | `32fd06770a14` |
| `ch07_importance_stability.png` | 07 机器学习用于量化研究 | §9. Feature importance 与可解释性 | `synthetic` | 特征重要性要带误差棒：重抽样下的不稳定排序会误导归因 | 固定 seed 合成模型，30 次 bootstrap 重算 importance；误差棒为 ±1 标准差。 | `ac9fc1043489` |
| `ch08_text_timeline.png` | 08 LLM4Quant 与文本研究 | §2.1 四种时间 | `concept` | 文本的四种时间：事件、发布、入库、特征可用 | 时间轴为示意；as-of 切线右侧的信息在任何情况下都不能进入当天特征。 | `28d740927a8d` |
| `ch08_token_to_vector.png` | 08 LLM4Quant 与文本研究 | §3.2 Embedding | `concept` | Token 到向量：文本如何变成模型可以计算的矩阵 | 矩阵数值为手写示例，用于说明 token × 维度 的结构与相似度计算。 | `8889e12bbeb9` |
| `ch08_embedding_scatter.png` | 08 LLM4Quant 与文本研究 | §4. Level 2：预训练 embedding + 轻量模型 | `synthetic` | 二维 embedding 散点与线性分类边界：可分与不可分 | 固定 seed 合成 embedding；右簇重叠区域就是线性模型会犯错的地方。 | `96508d3ea512` |
| `ch08_label_agreement.png` | 08 LLM4Quant 与文本研究 | §7.1 Label quality | `synthetic` | LLM 标签与人工标签的一致性：混淆矩阵与 Cohen's kappa | 固定 seed 合成 400 份文档的双标签对照；kappa 扣除随机一致的部分。 | `51ac8f4e164a` |
| `ch08_ablation_oos.png` | 08 LLM4Quant 与文本研究 | §7.2 Incremental predictive value | `project_output` | 项目 B 的 OOS ablation：market-only 与加入文本特征的增量 | 读取 projects/ml_llm_research/outputs/metrics.json；若未运行项目则跳过该图。 | `433256ff9c4b` |
| `ch09_pipeline_layers.png` | 09 全链路项目、岗位能力与面试表达 | §1.1 从问题到部署候选 | `concept` | 研究管线的五层与每层的检查门 | 层与检查项对应两个项目的目录结构；箭头表示显式输入输出，不允许隐藏全局状态。 | `749484b679d1` |
| `ch09_stage_gates.png` | 09 全链路项目、岗位能力与面试表达 | §补充二：从研究候选到生产候选的 Stage Gate | `concept` | Stage gate 漏斗：100 个想法到最后 1 个生产候选 | 数量为示意比例，用于说明筛选强度；每个 gate 的通过标准写在右侧。 | `ae8ef84a4351` |

## Notebook 执行后生成的插图

这些文件由同名 `.ipynb` 末尾的实验单元写出，不被 `make_figures.py` 覆盖：

| 文件 | 来源 |
|---|---|
| `01_market_objects.png` | 01-markets-assets.ipynb：真实 ^GSPC / ^TNX / VIX 三种单位不同的市场对象 |
| `02_returns_risk.png` | 02-returns-risk.ipynb：真实收益、波动与回撤实验 |
| `03_probability_regression.png` | 03-probability-statistics.ipynb：分布与回归实验 |
| `04_asof_pipeline.png` | 04-data-pipeline.ipynb：as-of 对齐与 pipeline 实验 |
| `05_trend_baseline.png` | 05-strategies-alpha.ipynb：真实数据上的趋势 baseline |
| `05_alpha_decay.png` | 05-strategies-alpha.ipynb：alpha decay 与 horizon 实验 |
| `06_portfolio_execution.png` | 06-portfolio-execution.ipynb：组合与执行实验 |
| `06_impact_curve.png` | 06-portfolio-execution.ipynb：市场冲击曲线 |
| `06_tca_decomposition.png` | 06-portfolio-execution.ipynb：TCA 成本分解 |
| `07_ml_ridge.png` | 07-machine-learning.ipynb：ridge 正则化实验 |
| `08_real_text_frequency.png` | 08-language-models.ipynb：真实文本词频实验 |
| `09_end_to_end.png` | 09-research-communication.ipynb：全链路串联实验 |

## 公开数据快照的时间范围

真实行情图只读 `sources/external/data/` 的本地快照，不在生成图片时联网：

| 序列 | 本地快照覆盖区间 |
|---|---|
| S&P 500 (`^GSPC`) 收盘/OHLCV | 2010-01-04 – 2025-10-08 (3966 obs) |
| 10 年期美债收益率指数 (`^TNX`) | 2010-01-04 – 2025-10-08 (3964 obs) |
| VIX 日线 | 1990-01-02 – 2026-09-22 (9278 obs) |

字段、下载端点和 SHA-256 见 [`sources/external/data/README.md`](../../sources/external/data/README.md)。重新下载数据时必须保存新快照并更新本表，否则图注中的区间会失真。

## 已知的取舍

- 目前只有三条真实公开序列（股票指数、利率、波动率指数）。跨资产的“各类资产日线”用`projects/alpha_research` 的合成面板绘制，并在图注中明确标注为合成数据；接入真实多资产快照（黄金、原油、外汇、加密、信用、REITs）是明确的扩展点，需要先补齐许可、复权和时间对齐说明。
- 图内文字默认中文，但坐标轴与图例仍保留英文术语（如 `bid/ask`、`drawdown`、`rank IC`），以便读者把讲义、代码字段和行业资料对应起来。
