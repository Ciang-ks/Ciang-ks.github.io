# 讲义插图目录

本目录里的每张图都由 `lectures/make_figures.py` 或章节 notebook 在本仓库内生成。**没有引用任何第三方图片**，因此不存在转载许可问题；如果你要加入教材或百科的截图，必须新建 `SOURCES.md` 记录来源、作者、许可和访问日期，并把原图保存到本地而不是外链。

## 重新生成

```bash
cd research
.venv/bin/python lectures/make_figures.py            # 全部章节
.venv/bin/python lectures/make_figures.py --chapter 01 02
.venv/bin/python lectures/make_figures.py --list      # 只列出注册表
.venv/bin/python lectures/check_figures.py            # 校验引用、清单与可复现性
```

当前渲染环境：matplotlib 3.11.2，style `seaborn-v0_8-whitegrid`，dpi 150，图内文字语言 `zh`（CJK 字体 `Droid Sans Fallback`）。缺少中文字体时脚本不会报错，只会改用英文标签，因此图在任何机器上都能生成。

## 四种数据类型（每张图都必须归入其中一种）

| kind | 含义 |
|---|---|
| `concept` | 概念示意图（手绘数据，只说明结构，不代表任何真实市场数值） |
| `synthetic` | 确定性合成教学数据（由固定 seed 生成，非真实行情） |
| `public_data` | 公开数据本地快照（sources/external/data，非实时、不构成投资建议） |
| `project_output` | 本仓库项目的可复现输出（合成数据 + 固定 pipeline，非真实交易结果） |

图内和图注都必须写清数据类型：概念示意图不是行情，合成数据不是历史，项目输出不是真实交易结果，任何图都不构成投资建议。

## 脚本生成的插图

| 文件 | 章节 | 位置 | 类型 | 说明 | 附注 | SHA-256（前 12 位） |
|---|---|---|---|---|---|---|
| `ch01_candle_anatomy.png` | 01 市场、资产与交易对象 | §2. 从一根日线走到一次可成交交易 | `concept` | 一根 K 线的四个价格：实体与上下影线 | 数值为手绘示意，不对应任何真实证券。 | `bdb22265bc60` |
| `ch01_real_sp500_bars.png` | 01 市场、资产与交易对象 | §2. 从一根日线走到一次可成交交易 | `public_data` | 真实 S&P 500 日线 OHLCV（2020 年 2–4 月本地快照） | Yahoo Finance ^GSPC 本地快照，2020-02-24 至 2020-04-03；教学用途，不构成投资建议。 | `cc4ac601fb38` |
| `ch01_quote_ladder.png` | 01 市场、资产与交易对象 | §2. 从一根日线走到一次可成交交易 | `concept` | 买卖报价阶梯：mid、spread 与立即成交的半个价差成本 | 示例报价为手绘数值，用于说明字段含义。 | `00c2523ad6ba` |
| `ch01_raw_vs_adjusted.png` | 01 市场、资产与交易对象 | §3. 股票和基金：数量与现金为什么会变 | `synthetic` | 拆股与分红如何造成 raw close 与 adjusted close 的差别 | 由固定 seed 生成的合成价格，用于展示复权口径差异。 | `9662e27744c0` |
| `ch01_bond_cashflows.png` | 01 市场、资产与交易对象 | §4. 把股票换成债券：不变的账本，不同的现金流 | `concept` | 息票债券现金流时间线与两种收益率下的价格 | 面值 100、年息票 4、5 年期；价格为公式计算结果，非市场报价。 | `9ed8ed771424` |
| `ch01_term_structure.png` | 01 市场、资产与交易对象 | §6. 换成期货：保证金不是全部风险 | `concept` | Contango 与 backwardation 的期货曲线及展期收益方向 | 曲线为手绘示例点位，用于说明期限结构与展期成本方向。 | `67881dd56460` |
| `ch01_option_payoffs.png` | 01 市场、资产与交易对象 | §7. 换成期权：不能只预测方向 | `concept` | 期权到期 payoff 与含权利金的净利润：四种基本头寸 | 执行价 K=100，call 权利金 6、put 权利金 4；数值为公式计算示例。 | `88bb3379e207` |
| `01_market_objects.png` | 01 市场、资产与交易对象 | §1. 先把研究问题写成一笔持仓 | `public_data` | 三种市场对象使用不同单位 | S&P 500、10 年美债收益率报价与 VIX 的本地公开快照，2018–2025。 | `2fd15fef8e34` |
| `ch02_simple_vs_log.png` | 02 收益、风险、组合与绩效 | §1. 先固定收益的对象、期间和分母 | `synthetic` | 同一段价格路径：simple return 相加会错，log return 相加才对 | 合成路径：100 → 50 → 100，两段 simple return 之和为 +50%，但财富没有变化。 | `889d3ef3985c` |
| `ch02_vol_drag.png` | 02 收益、风险、组合与绩效 | §2. 复利：每天做对一点，和最后赚到多少是两回事 | `synthetic` | 同样的平均日收益、不同的波动：复利终点不同（波动拖累） | 两条合成路径的算术平均日收益相同，高波动路径终点财富更低，小幅收益近似下，对数增长率每天约少一半日收益方差。 | `050a10f3393a` |
| `ch02_vol_clustering.png` | 02 收益、风险、组合与绩效 | §4. 波动：同样的平均结果，途中有多不稳定 | `public_data` | 真实 S&P 500 日收益与 60 日滚动年化波动：波动是聚集的 | Yahoo Finance ^GSPC 本地快照；教学用途，不构成投资建议。 | `b7db06f3e4d9` |
| `ch02_correlation_diversification.png` | 02 收益、风险、组合与绩效 | §5. 分散化：债券为什么能缓冲，又为什么可能失灵 | `synthetic` | 相关性如何决定分散化：散点与组合波动随权重的变化 | 左图为固定 seed 的二元正态样本；右图由两资产波动与相关系数公式直接计算。 | `c433ef6795dc` |
| `ch02_drawdown_real.png` | 02 收益、风险、组合与绩效 | §7. 回撤：账户从高点走到了哪里 | `public_data` | 真实 S&P 500 财富曲线与水下曲线：最大回撤与恢复时间 | Yahoo Finance ^GSPC 本地快照（2010–2025）；教学用途，不构成投资建议。 | `0aa697183f85` |
| `ch02_var_cvar.png` | 02 收益、风险、组合与绩效 | §9. 尾部风险：一个分位点以外还有多坏 | `public_data` | 真实日收益分布上的 5% VaR 与 CVaR（尾部平均损失） | Yahoo Finance ^GSPC 本地快照；历史 VaR 不是未来承诺，尾部还会更坏。 | `9d2b71a37a6b` |
| `ch03_endogeneity_iv.png` | 03 金融计量、时序建模与随机微积分 | §2. 工具变量：只使用订单流中能解释清楚的那一部分 | `synthetic` | 同一订单流样本中的 OLS 偏差与 IV 识别 | 固定种子；结构斜率为 0.6；工具有效性由生成机制保证。 | `249a28fb88e2` |
| `ch03_hac_overlap.png` | 03 金融计量、时序建模与随机微积分 | §3. 金融时序的误差：系数算对了，精度仍可能算错 | `synthetic` | 重叠标签的相关性与标准误 | 独立日收益的五日滚动和；HAC 带宽为 8。 | `ba765ddc9f13` |
| `ch03_stationarity.png` | 03 金融计量、时序建模与随机微积分 | §4. 平稳性、单位根与协整：不要让价格水平替你制造关系 | `synthetic` | 独立随机游走与平稳价差 | 价差为系数 0.8 的自回归过程；未计成本。 | `488d6595136d` |
| `ch03_conditional_vol.png` | 03 金融计量、时序建模与随机微积分 | §5. 从 AR 到条件波动：分别预测方向和风险 | `synthetic` | GARCH 创新与条件波动 | 参数 omega=0.08、alpha=0.12、delta=0.80，与主线相同。 | `c47a6bc960e1` |
| `ch03_ito_variation.png` | 03 金融计量、时序建模与随机微积分 | §6. 随机微积分：为什么对数增长少了半个方差 | `synthetic` | 简单收益与对数收益之差的二阶极限 | 同一布朗路径；年化 sigma=20%，期限一年。 | `dd72ea494318` |
| `ch03_multiple_testing.png` | 03 金融计量、时序建模与随机微积分 | §8. 多重尝试与不确定性：模型之外还有研究者 | `synthetic` | 20 个零信号策略中的最大绝对 t 值 | 4000 次模拟，每条策略 252 个独立标准正态收益。 | `8aeae9defd3e` |
| `ch04_three_timestamps.png` | 04 数据、偏差与量化研究管线 | §2. 同一个利润数字，为什么有四种时间 | `concept` | 报告期末、披露时间、可交易时间：三个必须分开的时间戳 | 时间轴为示意；真实研究中这三个时间可能相差数周到数月。 | `49c514965790` |
| `ch04_survivorship.png` | 04 数据、偏差与量化研究管线 | §5. 清洗怎样改变研究对象：成员、复权和陈旧价格 | `synthetic` | 幸存者偏差：只用活到今天的成分会系统性高估历史收益 | 固定 seed 合成 universe：8 个成分中 3 个中途退市（退市前收益为负）。 | `9434af54e690` |
| `ch04_lookahead_alignment.png` | 04 数据、偏差与量化研究管线 | §6. 一天的错位，足以让收益的主人换人 | `synthetic` | 信号对齐错了会制造假 IC：r_t 与 r_{t+1} 的差别 | 固定 seed 独立收益；信号含当天收益，比较同日误配与次日预测。 | `2d190e34f8bf` |
| `ch04_time_splits.png` | 04 数据、偏差与量化研究管线 | §9. 切分的是信息流，不只是日期行数 | `concept` | 三种时间切分：单次 holdout、walk-forward、purged + embargo | 色块表示训练/验证/测试区间；embargo 是为重叠标签留出的隔离带。 | `dbc5209b70bc` |
| `ch04_signal_to_fill.png` | 04 数据、偏差与量化研究管线 | §10. 回到事件顺序：什么时候数据会改变，什么时候钱会改变 | `concept` | 从信号到成交的时间链：哪一天的收益才属于这个信号 | 时刻为示意（收盘 16:00、次日开盘 09:30）；重点是收益归属区间。 | `29bb8d7094c4` |
| `ch05_trend_real_spx.png` | 05 策略、Alpha 与信号研究 | §3. 从过去涨跌到时间序列动量 | `public_data` | 真实 S&P 500 上的 12 个月趋势规则：信号只用过去价格，仓位滞后一天 | Yahoo Finance ^GSPC 本地快照；教学示例规则，不构成投资建议。 | `49913a037959` |
| `ch05_signal_heatmap.png` | 05 策略、Alpha 与信号研究 | §3. 从过去涨跌到时间序列动量 | `project_output` | 项目 A 合成面板上的 60 日动量信号：状态持续与资产差异 | 由 projects/alpha_research 的固定 seed 面板在进程内重算，不读取 outputs 目录。 | `b63cf066e42f` |
| `ch05_rebalance_weights.png` | 05 策略、Alpha 与信号研究 | §4. 截面动量：替换问题以后，交易也变了 | `project_output` | 一次再平衡日：截面排序如何变成带约束的权重 | 项目 A 合成面板；权重 = 信号/|信号|之和，再按 ±25% 截断。 | `187ef49bae8a` |
| `ch05_mean_reversion_zscore.png` | 05 策略、Alpha 与信号研究 | §5. 如果方向反过来：均值回归究竟假设了什么 | `synthetic` | 均值回归的 z-score 与 ±2 触发带：价差会回归，也可能不回归 | 固定 seed 合成价差：前段围绕均值波动，后段加入结构性漂移以展示失败模式。 | `49a75b1758fb` |
| `ch05_ic_horizon_decay.png` | 05 策略、Alpha 与信号研究 | §7. 先量信号：信息系数到底在问什么 | `project_output` | 不同持有期的 rank IC：衰减需要由数据检验 | 项目 A 合成面板上计算：信号为 60 日动量/波动，标签为未来 h 日收益。 | `58b47b0a1cf1` |
| `ch05_score_to_weight.png` | 05 策略、Alpha 与信号研究 | §8. 从分数到权重：变换会改变我们交易的内容 | `concept` | 从 raw score 到最终权重：标准化、截断、归一化三步 | 六个示例分数为手写数值，用于展示约束如何改变权重。 | `0e385c39490a` |
| `ch06_vol_targeting.png` | 06 组合构建、执行与风险控制 | §2. 风险预算：相同资金不等于相同风险 | `public_data` | 波动率目标如何自动去杠杆： realized vol 上升时仓位倍数下降 | Yahoo Finance ^GSPC 本地快照；目标年化波动 10%，仓位倍数上限 2、下限 0.2。 | `1ffa14360853` |
| `ch06_risk_contribution.png` | 06 组合构建、执行与风险控制 | §3. 风险贡献：为什么逆波动不等于风险平价 | `project_output` | 等权 vs 逆波动权重：权重份额与风险贡献份额的差别 | 项目 A 合成面板的样本协方差；每项风险贡献由权重与协方差向量的乘积除以组合方差得到。 | `7198b64d5667` |
| `ch06_book_walk.png` | 06 组合构建、执行与风险控制 | §4. 中间价不能成交：买卖价差与订单簿 | `concept` | 大单吃穿订单簿：平均成交价为什么差于 mid | 手写五档卖单；市价买单 6,000 股逐档成交，计算平均成交价与冲击。 | `36ea6c814fff` |
| `ch06_cost_monotonicity.png` | 06 组合构建、执行与风险控制 | §7. 每一分钱的损益如何对上 | `project_output` | 成本单调性：同一策略在 0/10/25/50 bps 下的净值与 Sharpe | 项目 A 固定 pipeline 在进程内重算；成本越高净值越低是必须通过的不变量。 | `72caae49514e` |
| `ch06_pnl_decomposition.png` | 06 组合构建、执行与风险控制 | §7. 每一分钱的损益如何对上 | `project_output` | PnL 分解：毛收益、成本拖累与净收益三条累计曲线 | 项目 A 10 bps 成本情景；成本累计曲线单调向下，是会计正确性的检查项。 | `1791fb0c80fc` |
| `ch07_label_overlap.png` | 07 机器学习用于量化研究 | §2. 从一行数据看见泄漏与样本依赖 | `concept` | 重叠标签为什么需要 purge 与 embargo | 标签为未来 5 日收益；相邻样本的标签窗口互相重叠。 | `74d37971c4f8` |
| `ch07_bias_variance.png` | 07 机器学习用于量化研究 | §4. 线性回归到底在学习什么 | `synthetic` | 模型复杂度与 训练/验证误差与模型复杂度 | 固定 seed 合成数据，多项式阶数 1–12；根据验证误差选择复杂度，测试集留到最后。 | `9c4c452efda9` |
| `ch07_calibration.png` | 07 机器学习用于量化研究 | §7. 从预测到交易：成本如何改变问题 | `synthetic` | 校准曲线：预测概率与实现频率是否一致 | 固定 seed 合成分类器输出；raw 概率被非线性扭曲，示意映射后更接近对角线。 | `3fd845614906` |
| `ch07_feature_drift.png` | 07 机器学习用于量化研究 | §9. 当关系变化时，监控什么 | `synthetic` | 特征漂移：同一特征在不同年份的分布会移动 | 固定 seed 合成特征，2021 年起均值与方差同时变化；标注两年间 KS 统计量。 | `6b319cffe737` |
| `ch07_importance_stability.png` | 07 机器学习用于量化研究 | §8. 新特征是否增加了独立信息 | `synthetic` | 特征重要性要带误差棒：重抽样下的不稳定排序会误导归因 | 固定 seed 合成 iid 回归，30 次训练重采样后在独立留出集做置换；误差棒为 ±1 标准差。 | `1286844cf969` |
| `ch08_text_timeline.png` | 08 LLM4Quant 与文本研究 | §2. 一份文本至少有四个时间 | `concept` | 文本的四种时间：事件、发布、入库、特征可用 | 时间轴为示意；as-of 切线右侧的信息在任何情况下都不能进入当天特征。 | `5a8f12992149` |
| `ch08_token_to_vector.png` | 08 LLM4Quant 与文本研究 | §5. 从词到向量，再到语言模型：复杂度增加在哪里 | `concept` | Token 到向量：文本如何变成模型可以计算的矩阵 | 矩阵数值为手写示例，用于说明 token 数与向量维度组成的矩阵结构与相似度计算。 | `6e9de23081e9` |
| `ch08_embedding_scatter.png` | 08 LLM4Quant 与文本研究 | §5. 从词到向量，再到语言模型：复杂度增加在哪里 | `synthetic` | 二维 embedding 散点与线性分类边界：可分与不可分 | 固定 seed 合成 embedding；右簇重叠区域就是线性模型会犯错的地方。 | `c507ebfd5be2` |
| `ch08_label_agreement.png` | 08 LLM4Quant 与文本研究 | §7. 先检查抽取质量，再谈交易 | `synthetic` | LLM 标签与人工标签的一致性：混淆矩阵与 Cohen's kappa | 固定 seed 合成 400 份文档的双标签对照；kappa 扣除随机一致的部分。 | `eeaeff2d47d5` |
| `ch08_ablation_oos.png` | 08 LLM4Quant 与文本研究 | §8. 同一批公告如何进入收益模型 | `project_output` | 项目 B 的 OOS ablation：market-only 与加入文本特征的增量 | 在临时目录重算项目 B 默认实验，读取样本外指标。 | `eece55bf04ac` |
| `ch09_pipeline_layers.png` | 09 全链路项目、岗位能力与面试表达 | §2. 六层管线不是六个文件夹，而是六个可解释对象 | `concept` | 研究管线的六层与每层的检查门 | 层与检查项对应两个项目的目录结构；箭头表示显式输入输出，不允许隐藏全局状态。 | `d676339a95bd` |
| `ch09_stage_gates.png` | 09 全链路项目、岗位能力与面试表达 | §8. 研究候选怎样逐步成为生产候选 | `concept` | Stage gate 漏斗：100 个想法到最后 1 个生产候选 | 数量为示意比例，用于说明筛选强度；每个 gate 的通过标准写在右侧。 | `01c70584e4ac` |

## 公开数据快照的时间范围

真实行情图只读 `sources/external/data/` 的本地快照，不在生成图片时联网：

| 序列 | 本地快照覆盖区间 |
|---|---|
| S&P 500 (`^GSPC`) 收盘/OHLCV | 2010-01-04 – 2025-10-08 (3966 obs) |
| 10 年期美债收益率指数 (`^TNX`) | 2010-01-04 – 2025-10-08 (3964 obs) |
| VIX 日线 | 1990-01-02 – 2026-09-22 (9278 obs) |

字段、下载端点和 SHA-256 见 [`sources/external/data/README.md`](../../sources/external/data/README.md)。重新下载数据时必须保存新快照并更新本表，否则图注中的区间会失真。

## 已知的取舍

- 目前只有三条真实公开序列（股票指数、利率、波动率指数）。跨资产的“各类资产日线”用`projects/alpha_research` 的合成面板绘制，并在图注中明确标注为合成数据；接入真实多资产快照（黄金、原油、外汇、加密、信用、REITs）是明确的扩展点，需要先补齐许可、复权和时间对齐说明。
- 图内文字默认中文，但坐标轴与图例仍保留英文术语（如 `bid/ask`、`drawdown`、`rank IC`），以便读者把讲义、代码字段和行业资料对应起来。
