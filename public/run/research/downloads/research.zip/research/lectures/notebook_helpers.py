"""Shared helpers used by the lecture notebooks.

The helpers intentionally keep the data contract visible: the notebooks read
small, locally cached public files under ``sources/external/data`` and never
silently download data while executing.
"""
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd


def repo_root(start: str | Path | None = None) -> Path:
    """Find the repository root from a notebook's current working directory."""
    here = Path(start or Path.cwd()).resolve()
    candidates = [here, *here.parents]
    for candidate in candidates:
        if (candidate / "sources" / "external" / "data").is_dir():
            return candidate
        if (candidate / "lectures" / "notebook_helpers.py").exists():
            return candidate
    raise FileNotFoundError("Could not locate repository root with sources/external/data")


def data_dir(root: str | Path | None = None) -> Path:
    return repo_root(root) / "sources" / "external" / "data"


def load_real_market_data(root: str | Path | None = None) -> pd.DataFrame:
    """Load locally cached Yahoo chart data and GitHub VIX data.

    Yahoo's index data are converted to a daily date index; the source files
    and download metadata are documented in ``sources/external/README.md``.
    Missing observations remain missing until a notebook explicitly decides
    how to handle them.
    """
    directory = data_dir(root)
    spx = pd.read_csv(directory / "yahoo_sp500.csv", parse_dates=["date"])
    tnx = pd.read_csv(directory / "yahoo_tnx.csv", parse_dates=["date"])
    vix = pd.read_csv(directory / "vix_daily.csv", parse_dates=["date"])
    for frame in (spx, tnx, vix):
        frame["date"] = pd.to_datetime(frame["date"], errors="coerce").dt.normalize()
        frame.dropna(subset=["date"], inplace=True)
    spx = spx.set_index("date").rename(columns={"close": "spx_close"})[["spx_close"]]
    tnx = tnx.set_index("date").rename(columns={"close": "tnx_yield"})[["tnx_yield"]]
    vix = vix.set_index("date").rename(columns={"vix_close": "vix"})[["vix"]]
    result = spx.join(tnx, how="outer").join(vix, how="outer").sort_index()
    result["spx_return"] = result["spx_close"].pct_change(fill_method=None)
    result["spx_log_return"] = np.log(result["spx_close"]).diff()
    result["vix_change"] = result["vix"].diff()
    return result


def annualized_sharpe(returns: pd.Series, periods: int = 252) -> float:
    returns = pd.Series(returns).dropna().astype(float)
    if len(returns) < 2 or returns.std(ddof=1) == 0:
        return float("nan")
    return float(returns.mean() / returns.std(ddof=1) * np.sqrt(periods))


def max_drawdown(returns: pd.Series) -> float:
    returns = pd.Series(returns).dropna().astype(float)
    if returns.empty:
        return 0.0
    wealth = (1.0 + returns).cumprod()
    return float((wealth / wealth.cummax() - 1.0).min())


def summary(returns: pd.Series, periods: int = 252) -> dict[str, float]:
    returns = pd.Series(returns).dropna().astype(float)
    wealth = (1.0 + returns).cumprod()
    years = len(returns) / periods if len(returns) else 0.0
    annual_return = float(wealth.iloc[-1] ** (1 / years) - 1) if years else 0.0
    return {
        "observations": int(len(returns)),
        "annual_return": annual_return,
        "annualized_volatility": float(returns.std(ddof=1) * np.sqrt(periods)) if len(returns) > 1 else 0.0,
        "sharpe": annualized_sharpe(returns, periods),
        "max_drawdown": max_drawdown(returns),
    }
