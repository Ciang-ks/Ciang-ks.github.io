"""Figure placements and captions for the canonical lecture notebooks.

Each entry associates an image with an anchor paragraph. The insertion tool
updates Notebook Markdown cells; the site converter publishes those same cells.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Insertion:
    chapter: str          # "01" ... "09"
    number: str           # figure number inside the chapter, e.g. "1-2"
    image: str            # path relative to lectures/, e.g. "figures/ch01_x.png"
    alt: str              # alt text for the image
    title: str            # short title after the ｜ in the caption
    caption: str          # self-contained Chinese caption, incl. data provenance
    anchor: str           # unique substring of the paragraph the figure follows


def block(entry: Insertion) -> str:
    return (
        f"![{entry.alt}]({entry.image})\n"
        f"\n"
        f"**图 {entry.number}｜{entry.title}。** {entry.caption}"
    )


INSERTIONS: list[Insertion] = [
    Insertion(
        chapter='01',
        number='1-1',
        image='figures/01_market_objects.png',
        alt='三类单位不同的市场对象：股票指数、收益率报价、隐含波动率指标',
        title='三种市场对象，三种单位',
        caption=(
            '同一张图里的三条曲线单位完全不同：S&P 500 是价格指数点位，^TNX 是 10 年期美债收益率报价，VIX 是期权隐含波动率指标。把它们画在一起是为了提醒：收益率上升不等于债券价格上涨，'
            'VIX 也不是可以按“现货价”直接长期持有的资产。读图时把每一列补成数据字典：来源、单位、时间戳、何时可见、是否可交易。数据类型：公开数据本地快照（Yahoo '
            'Finance ^GSPC/^TNX 与公开 VIX 日线），由本章 notebook 的实验单元生成。'
        ),
        anchor='少写一个条件，回测就可能把不同的经济对象混在一起。',
    ),
    Insertion(
        chapter='01',
        number='1-2',
        image='figures/ch01_candle_anatomy.png',
        alt='一根 K 线的四个价格：实体与上下影线',
        title='K 线解剖',
        caption=(
            '日线记录开盘、最高、最低、收盘四价；实体高度为 \\(\\lvert P_{\\mathrm{close}}-P_{\\mathrm{open}}\\rvert\\)。影线表示实体之外的成交价格区间。'
            '上涨日仅表示收盘高于开盘。数据类型：概念示意图，数值为教学设定。'
        ),
        anchor='使用前要阅读字段定义。',
    ),
    Insertion(
        chapter='01',
        number='1-3',
        image='figures/ch01_real_sp500_bars.png',
        alt='真实 S&P 500 日线 OHLC 与成交量（2020 年 2–4 月）',
        title='真实日线长什么样',
        caption=(
            '日线与成交量来自公开 S&P 500 本地快照，2020-03-16 的日对数收益约为 -12.8%。高成交量并不自动意味着低交易成本；本图没有盘口数据，不能直接测得价差或市场冲击。'
            '数据类型：公开 OHLCV 快照，2020-02-24 至 2020-04-03。'
        ),
        anchor='使用前要阅读字段定义。',
    ),
    Insertion(
        chapter='01',
        number='1-4',
        image='figures/ch01_quote_ladder.png',
        alt='五档买卖报价阶梯与中间价、价差',
        title='报价阶梯与半个价差的成本',
        caption=(
            '图把 bid/ask 画成两侧的深度条：最好的买价 99.9、最好的卖价 100.1，中间价 100.00，报价价差 0.20。如果你立即买入再立即卖出，价格没变也会损失 '
            '0.20，这就是短周期策略最先遇到的成本。数据类型：概念示意图（手写报价；真实盘口每毫秒都在变化）。'
        ),
        anchor='真实成交还会有 queue position（排队位置）、market impact（市场冲击）和 latency（延迟）。',
    ),
    Insertion(
        chapter='01',
        number='1-5',
        image='figures/ch01_raw_vs_adjusted.png',
        alt='同一证券的原始收盘价与复权收盘价在拆股和分红后分叉',
        title='raw close 与 adjusted close 的分叉',
        caption=(
            '原始成交价在 2:1 拆股日减半，除息日扣除现金股息；向前调整历史价格后，复权曲线去掉这两种机械跳变。直接使用原始价格会把拆股误计为约 50% 的亏损；复权价格也不是当时的成交价。'
            '数据类型：固定 seed 合成价格，公司行动为教学设定。'
        ),
        anchor='项目中要明确 `raw_close`、`adjusted_close` 和现金股息是否分别使用。',
    ),
    Insertion(
        chapter='01',
        number='1-6',
        image='figures/ch01_bond_cashflows.png',
        alt='息票债券的现金流时间线与两种收益率下的价格',
        title='债券现金流与价格—收益率反向关系',
        caption=(
            '面值 100、每期息票 4、共 5 期，最后一期收回本金。相同现金流按 \\(y=3\\%\\)、\\(5\\%\\)、\\(8\\%\\) 折现，价格分别为 104.58、95.67、'
            '84.03；未来收入不变，折现率越高现值越低。数据类型：由贴现公式计算的概念示例，非市场报价。'
        ),
        anchor='债券价格与收益率通常反向变化，因为未来现金流被更重地折现。',
    ),
    Insertion(
        chapter='01',
        number='1-7',
        image='figures/ch01_term_structure.png',
        alt='contango 与 backwardation 两条期货曲线及展期收益方向',
        title='期限结构决定展期收益的符号',
        caption=(
            '两条曲线从同一现货价 100 出发。若现货与期限曲线保持不变，合约随到期向现货收敛，则 contango 对应负的收敛收益，backwardation 对应正的收敛收益。'
            '换仓时的价差本身不是立即发生的损益；曲线变化也可能改变实际结果。因此“看对现货方向”和“期货头寸赚钱”是两件事。数据类型：概念示意图（曲线点位为示例）。'
        ),
        anchor='拼接规则（前复权、后复权、比例调整或固定主力）会改变收益统计。',
    ),
    Insertion(
        chapter='01',
        number='1-8',
        image='figures/ch01_option_payoffs.png',
        alt='四种基本期权头寸的到期 payoff 与含权利金净利润',
        title='期权到期 payoff 与净利润',
        caption=(
            '四个面板分别为买入和卖出看涨、看跌；灰线是到期 payoff，蓝色虚线是计入权利金的净利润。买方最大损失为权利金；未对冲看涨卖方亏损可无上限，看跌卖方的亏损上限则受执行价约束。'
            '数据类型：概念示例，\\(K=100\\)，看涨、看跌权利金分别为 6 和 4。'
        ),
        anchor='若 put 权利金是 4，买方净利润为 16。',
    ),
    Insertion(
        chapter='02',
        number='2-1',
        image='figures/ch02_simple_vs_log.png',
        alt='100 到 50 再回到 100 的往返路径上两种收益口径的累加差异',
        title='simple 与 log 的可加性差异',
        caption=(
            '价格从 100 到 50 再回 100，财富没有变化。简单收益直接相加却为 50%，对数收益相加为 0。多期财富应使用简单收益连乘，或先累加对数收益再取指数，不能把两种公式混用。'
            '数据类型：三点合成路径。'
        ),
        anchor='日收益很小时二者接近，日波动大、杠杆高或持有期长时应明确使用哪一种。',
    ),
    Insertion(
        chapter='02',
        number='2-2',
        image='figures/ch02_vol_drag.png',
        alt='相同平均日收益、不同波动的两条合成财富路径',
        title='波动拖累：均值相同，终点不同',
        caption=(
            '两组日收益被调整为相同的样本算术均值，高波动组的复利终值仍更低。小收益近似下，平均对数收益约为 \\(\\bar r-s^2/2\\)；两条路径的预期对数增长差约为 '
            '\\((s_H^2-s_L^2)/2\\)。下图使用收益率横轴展示两组分布。数据类型：固定 seed 合成样本，单次路径不代表一般保证。'
        ),
        anchor='在固定平均收益下，路径越不稳定，复利结果可能越差。',
    ),
    Insertion(
        chapter='02',
        number='2-3',
        image='figures/ch02_vol_clustering.png',
        alt='真实 S&P 500 日收益与 60 日滚动年化波动',
        title='波动是聚集的',
        caption=(
            '上半部分是真实日收益的正负茎线，下半部分是 60 日滚动年化波动：2011、2018、2020、2022 等危机期波动成簇出现，平静期可以长期低于中位数。因此“一个年化波动数字”只是窗口平均，'
            '报告必须写明估计窗口和频率。数据类型：公开数据本地快照（Yahoo Finance ^GSPC，2010 年起）；仅用于教学。'
        ),
        anchor='研究报告要注明频率和估计窗口。',
    ),
    Insertion(
        chapter='02',
        number='2-4',
        image='figures/ch02_correlation_diversification.png',
        alt='两资产收益散点与不同相关系数下组合波动随权重的变化',
        title='相关性如何决定分散化',
        caption=(
            '左图为相关系数约 0.6 的合成二元样本。右图按两资产组合方差公式计算：其他条件相同，相关系数 \\(\\rho\\) 越低，组合的最低波动越低；\\(\\rho=1\\) '
            '且权重非负时，组合波动才等于两资产波动的加权平均。数据类型：固定 seed 样本与公式计算。'
        ),
        anchor='因此实务常用 shrinkage（收缩估计）、因子模型或风险上限。',
    ),
    Insertion(
        chapter='02',
        number='2-5',
        image='figures/ch02_drawdown_real.png',
        alt='真实 S&P 500 财富曲线与水下曲线',
        title='最大回撤与恢复时间',
        caption=(
            '上半部分是再基准化的财富曲线与历史峰值线，下半部分是水下曲线（drawdown）。2020-02-19 到 2020-03-23 的价格回撤约 -33.9%，于 '
            '2020-08-18 恢复前高；2022 年的回撤更慢、更磨人。读图时同时记录深度、持续时间和恢复时间，三者缺一不可。数据类型：公开数据本地快照（Yahoo Finance '
            '^GSPC）；仅用于教学。'
        ),
        anchor='投资者的承受能力、保证金需求和实际风险完全不同。',
    ),
    Insertion(
        chapter='02',
        number='2-6',
        image='figures/ch02_var_cvar.png',
        alt='真实日收益直方图上的 5% VaR 与 CVaR',
        title='VaR 与 ES 的符号口径',
        caption=(
            '横轴为日简单收益。灰色线画在 5% 收益分位点 \\(q_{0.05}<0\\)，图中报告的损失风险取正值：\\(\\mathrm{VaR}_{0.95}=-q_{0.05}\\)。'
            'ES 是最差 5% 样本日平均收益的相反数；它与 VaR 都按损失为正的口径报告。数据类型：公开 S&P 500 本地快照，历史样本不承诺未来风险。'
        ),
        anchor='计算时要明确历史窗口、是否按资产重估、是否包含成本和流动性冲击。',
    ),
    Insertion(
        chapter='03',
        number='3-1',
        image='figures/ch03_fat_tails.png',
        alt='真实日收益分布与正态、Student-t 在对数刻度下的对照',
        title='真实尾部比正态厚',
        caption=(
            '在这份历史样本中，\\(\\lvert r-\\bar r\\rvert>3s\\) 的频率高于同均值同方差正态模型的预测。Student-t 曲线仅为同方差、自由度 3 '
            '的参照，并未经过拟合。这个尾部阈值的结果不能推广为所有正态分位数都低估风险。数据类型：公开 S&P 500 日收益本地快照。'
        ),
        anchor='不要把“画出来像钟形”当成检验。',
    ),
    Insertion(
        chapter='03',
        number='3-2',
        image='figures/ch03_lln_clt.png',
        alt='样本均值收敛与标准化均值分布趋近正态',
        title='LLN 与 CLT 的两张脸',
        caption=(
            '原始样本来自有限方差的平移指数分布，并非正态。左图展示累计均值逐渐稳定，\\(\\mu\\pm2\\sigma/\\sqrt n\\) 只是各样本量下的标准误尺度，不保证整条路径都在带内。'
            '右图对 2000 组、每组 200 个观测的均值标准化，与标准正态密度对照。数据类型：固定 seed 合成 iid 样本。'
        ),
        anchor='若收益一阶自相关为正，100 个观察值的信息量可能少于 100 个独立样本。',
    ),
    Insertion(
        chapter='03',
        number='3-3',
        image='figures/ch03_ci_coverage.png',
        alt='100 次重复抽样的 95% 置信区间，未覆盖真值者标红',
        title='95% 置信区间的正确含义',
        caption=(
            '每一行是一次独立抽样算出的 95% 置信区间，灰色行是没有覆盖真值 \\(\\mu = 0\\) 的少数几次。95% 描述的是这个“造区间的方法”的长期覆盖率，而不是某一条已算出区间包含真值的概率。'
            '数据类型：固定 seed 的 100 次合成重复抽样。'
        ),
        anchor='当样本小、总体方差未知时常用 Student-t 临界值而非正态临界值。',
    ),
    Insertion(
        chapter='03',
        number='3-4',
        image='figures/ch03_pvalue_null.png',
        alt='零假设分布、观测统计量与双尾 p-value 面积',
        title='p-value 是尾部面积',
        caption=(
            '曲线是零假设下均值估计量的分布，标准误为 \\(\\mathrm{SE}=0.4\\%\\)，观测值为 \\(0.78\\%\\)。两侧阴影表示在零假设下得到至少同样极端统计量的概率；'
            '它不是零假设为真的概率。数据类型：教学设定数值，双尾概率由正态分布计算。'
        ),
        anchor='它不是 $H_0$ 为真的概率，也不是策略赚钱概率。',
    ),
    Insertion(
        chapter='03',
        number='3-5',
        image='figures/ch03_ols_residuals.png',
        alt='一元 OLS 的拟合线、残差茎与残差检查图',
        title='拟合、残差与 \\(R^{2}\\)',
        caption=(
            '左图的拟合线与残差来自同一组合成样本。右图先按拟合值排序，再计算 30 点局部残差均值，避免按原始无序横坐标连线制造结构；局部波动本身不构成模型错设的证明。数据类型：固定 '
            'seed 合成样本。'
        ),
        anchor='反过来，高 R² 可能只是把时间趋势或泄漏字段放进了模型。',
    ),
    Insertion(
        chapter='03',
        number='3-6',
        image='figures/ch03_multiple_testing.png',
        alt='单个零信号策略与 20 个零信号策略中最大 |t| 的分布',
        title='多重检验让 |t| > 2 变得廉价',
        caption=(
            '蓝线是单个零信号策略的 \\(\\lvert t\\rvert\\) 分布，灰色直方图是 20 个独立零信号策略中最大绝对 t 值的分布。约六成模拟会找到 \\(\\lvert '
            't\\rvert>2\\) 的“最佳策略”，尽管真实期望收益全为零。数据类型：固定 seed 的 4000 次模拟，每个策略用 252 个观测计算样本 t 统计量。'
        ),
        anchor='实际试验次数更多。',
    ),
    Insertion(
        chapter='04',
        number='4-1',
        image='figures/ch04_three_timestamps.png',
        alt='报告期末、披露时间、可交易时间三个时间戳与泄漏窗口',
        title='一个数字的三个时间戳',
        caption=(
            '报告期末、披露时间和最早成交时间回答不同问题。披露前使用该数字会泄漏未来信息；披露后还应计入处理、下单与成交时延，不能直接假设按先前价格成交。数据类型：时间间隔为概念示意。'
        ),
        anchor='用 3 月 31 日作为特征时间会让回测偷看未来。',
    ),
    Insertion(
        chapter='04',
        number='4-2',
        image='figures/ch04_survivorship.png',
        alt='含退市成分的合成 universe 与幸存者口径的收益偏差',
        title='幸存者偏差是一个水平位移',
        caption=(
            '8 个合成成分中有 3 个中途退市，灰色虚线仅画到最后可见价格。右图比较日均收益乘 252：本例中，排除退市前的下跌历史会抬高统计值。图中未模拟退市清算损益，也不是完整投资组合回测。'
            '数据类型：固定 seed 合成价格。'
        ),
        anchor='指数成分也必须按当时版本复建，不能使用今天下载的成分表回填过去。',
    ),
    Insertion(
        chapter='04',
        number='4-3',
        image='figures/ch04_lookahead_alignment.png',
        alt='信号与同日收益配对（泄漏）和与次日收益配对（正确）的 IC 对比',
        title='对齐错了会制造假 IC',
        caption=(
            '信号含有当天收盘收益，左图把它与同日收益配对，得到很高但不可交易的相关性。右图用同一信号预测次日独立收益，相关性接近零。散点、拟合线与 IC 均由各面板实际显示的配对计算。'
            '数据类型：固定 seed 合成独立收益，不代表真实信号。'
        ),
        anchor='并写一个单元测试构造“未来值改变但过去信号不能改变”的情况。',
    ),
    Insertion(
        chapter='04',
        number='4-4',
        image='figures/ch04_time_splits.png',
        alt='单次切分、walk-forward 与 purged + embargo 三种时间切分',
        title='三种切分，一条规则：不打乱时间',
        caption=(
            '第一行是最简单的训练/验证/测试切分；第二行是 walk-forward，训练窗滚动、测试窗跟随；第三行在边界加入 purge（删除标签跨边界的样本）与 embargo（安全间隔）。'
            '三者都保持时间顺序。数据类型：概念示意图。'
        ),
        anchor='**embargo** 在训练和验证之间留出一段间隔，防止信息通过持仓或标签传播。',
    ),
    Insertion(
        chapter='04',
        number='4-5',
        image='figures/ch04_signal_to_fill.png',
        alt='信号、下单、成交的时间链与收益归属区间',
        title='哪一段收益属于这个信号',
        caption=(
            '本图约定：信号在 \\(t\\) 日收盘后生成，\\(t+1\\) 日开盘买入，\\(t+2\\) 日开盘卖出。该笔持仓的毛收益为 \\(P^{\\mathrm{open}}_{t+2}/P^{\\mathrm{open}}_{t+1}-1\\)，'
            '不含买入前的隔夜收益。项目中的简化收盘到收盘回测须按其独立约定理解。数据类型：成交时间概念示意。'
        ),
        anchor='短周期或高换手研究需要模拟 bid/ask、部分成交、延迟、市场冲击、撤单和限额。',
    ),
    Insertion(
        chapter='05',
        number='5-1',
        image='figures/ch05_trend_real_spx.png',
        alt='真实 S&P 500 上 12 个月趋势规则的仓位状态与切换点',
        title='真实价格上的趋势规则',
        caption=(
            '规则按 12 个月动量的符号决定多空状态，并滞后一个交易日执行；蓝色背景只标出多头区间，下图同时显示空头与暖启动空仓状态。负动量时做空，不是简单离场。图中波动与持仓时间不等于扣费后投资业绩。'
            '数据类型：公开 S&P 500 快照上的教学规则。'
        ),
        anchor='其中 $L$ 是回看窗口。更平滑的版本使用 moving average、指数加权收益或 z-score：',
    ),
    Insertion(
        chapter='05',
        number='5-2',
        image='figures/ch05_signal_heatmap.png',
        alt='项目 A 合成面板上各资产各周的动量/波动信号热图',
        title='信号在时间和资产上的结构',
        caption=(
            '热图每一行是一个资产、每一列是一周，颜色是动量除以波动后的信号值：红色看多、蓝色看空。可以看到信号在时间上成块持续（趋势状态），在资产间并不同步（分散化来源）。'
            '数据类型：projects/alpha_research 的确定性合成面板（seed 固定），不是真实市场历史。'
        ),
        anchor='而不是只展示一个最好的参数。',
    ),
    Insertion(
        chapter='05',
        number='5-3',
        image='figures/ch05_rebalance_weights.png',
        alt='一个再平衡日的截面动量排序与截断归一化后的目标权重',
        title='截面排序如何变成权重',
        caption=(
            '左图为一个再平衡日的 60 日动量排序。右图先用波动缩放信号，再按绝对信号和归一，截断单资产权重至 \\(\\pm25\\%\\)。截断后总绝对权重可能小于 1；单资产上限不能代替组合相关性管理。'
            '数据类型：项目 A 的确定性合成面板。'
        ),
        anchor='交易成本和借券是否吞掉 spread return。',
    ),
    Insertion(
        chapter='05',
        number='5-4',
        image='figures/ch05_mean_reversion_zscore.png',
        alt='合成价差的 z-score 与 ±2 触发带，后段出现结构断裂',
        title='均值回归会失败的样子',
        caption=(
            '前 450 天价差按均值回归过程生成，之后取消回归项并加入漂移。滚动 z-score 仍可能发出极值信号，但已不能依赖原来的平稳性假设；图中没有计算交易损益，不能据此断言某策略必然亏损。'
            '数据类型：固定 seed 合成价差。'
        ),
        anchor='价格也可能因为结构变化越走越远。',
    ),
    Insertion(
        chapter='05',
        number='5-5',
        image='figures/ch05_ic_horizon_decay.png',
        alt='项目 A 合成面板上 rank IC 随前瞻持有期的衰减',
        title='不同持有期的实测 IC',
        caption=(
            '用项目 A 的同一组动量/波动信号与不同持有期的未来收益，计算平均截面 rank IC。本次合成样本不呈单调衰减，部分持有期接近零或为负，因此不能直接套用正的指数衰减曲线。'
            '数据类型：固定 seed 项目输出，仅用于教学。'
        ),
        anchor='IC 为正不一定能赚钱：若横截面相关弱、成本高或组合权重不稳定，净收益仍可能为负。',
    ),
    Insertion(
        chapter='05',
        number='5-6',
        image='figures/ch05_score_to_weight.png',
        alt='原始分数、截面 z-score 与截断归一化权重的三步转换',
        title='从分数到仓位的三步',
        caption=(
            '三图依次为原始分数、截面 z-score，以及截断分数再归一后的权重。本例结果位于图示 40% 参考线内；实际权重上限必须在最终归一后检查，不能只靠分数截断保证。'
            '数据类型：六个手写分数的概念示例。'
        ),
        anchor='再归一化 gross exposure，并设置单名、行业、流动性和杠杆上限。',
    ),
    Insertion(
        chapter='06',
        number='6-1',
        image='figures/ch06_vol_targeting.png',
        alt='真实 S&P 500 的 realized 波动与波动率目标下的仓位倍数',
        title='波动率目标自动去杠杆',
        caption=(
            '用 60 日简单收益波动估计计算 \\(0.10/\\hat\\sigma_t\\)，截断在 \\([0.2,2]\\)，下一交易日采用该倍数。图内极值标注由同一序列计算。'
            '滞后估计、上下限与波动变化意味着实际组合风险不一定恰好等于目标。数据类型：公开 S&P 500 本地快照。'
        ),
        anchor='否则波动估计噪声会造成频繁交易。',
    ),
    Insertion(
        chapter='06',
        number='6-2',
        image='figures/ch06_risk_contribution.png',
        alt='等权与逆波动权重的权重份额和风险贡献份额对比',
        title='权重不等于风险贡献',
        caption=(
            '两种方案的权重份额与风险贡献份额不同。风险贡献份额为 \\(w_i(\\Sigma w)_i/(w^T\\Sigma w)\\)，可因对冲关系而为负；逆波动权重也不保证各资产贡献完全相等。'
            '数据类型：项目 A 合成收益的样本协方差，用于描述而非预测风险。'
        ),
        anchor='高相关资产仍可能共享同一风险来源。',
    ),
    Insertion(
        chapter='06',
        number='6-3',
        image='figures/ch06_book_walk.png',
        alt='市价买单逐档吃穿卖单与平均成交价相对 mid 的冲击',
        title='大单为什么成交在更差的价格',
        caption=(
            '6,000 股买单按卖价从低到高成交，最后触及 100.5，均价约为 100.258。相对中间价 100.00 的滑点约为 25.8 bp，包含价差与静态吃单深度；'
            '它不全是因果意义的市场冲击。右图用阶梯表示边际卖价。数据类型：手写报价的概念示例，未模拟补单与撤单。'
        ),
        anchor='订单簿深度、撤单率、成交速度和价差随时段变化，不能用日均成交量完全替代。',
    ),
    Insertion(
        chapter='06',
        number='6-4',
        image='figures/ch06_cost_monotonicity.png',
        alt='同一策略在 0/10/25/50 bps 成本下的净值曲线与净 Sharpe',
        title='成本单调性是不变量',
        caption=(
            '价格与权重固定时，提高非负交易成本不能提高对应日的净收益与净值。图中净 Sharpe 也下降，但 Sharpe 的单调性不是普适会计不变量。虚线为同资产集合的等权基准。'
            '数据类型：项目 A 的确定性合成输出。'
        ),
        anchor='不要只在最终收益上扣一个总数，因为成本会改变仓位路径、换手和下一期信号。',
    ),
    Insertion(
        chapter='06',
        number='6-5',
        image='figures/ch06_pnl_decomposition.png',
        alt='项目 A 10 bps 情景下毛收益、成本拖累与净收益的累计曲线',
        title='PnL 分解：毛收益与成本拖累',
        caption=(
            '图中毛收益、负的成本拖累与净收益都按逐日简单收益累加，满足加法分解；它们不是复利净值。成本为 \\(\\mathrm{turnover}_t c_{\\mathrm{bps}}10^{-4}\\)，'
            '换手按目标权重变化的绝对值和计算。数据类型：项目 A 合成数据的 10 bps 成本情景。'
        ),
        anchor='- **model/hedge residual**：未解释部分。',
    ),
    Insertion(
        chapter='07',
        number='7-1',
        image='figures/ch07_label_overlap.png',
        alt='相邻样本的 5 日前瞻标签互相重叠与 purge/embargo 位置',
        title='重叠标签与 purge/embargo',
        caption=(
            '深蓝块为特征日，浅蓝块为未来 5 日标签窗口。跨越切分边界的训练标签需要 purge；额外 embargo 间隔应按标签跨度、信息延迟和评价协议确定。图示区间不代表所有任务都采用同一间隔。'
            '数据类型：标签窗口的概念示意。'
        ),
        anchor='训练/验证边界要 purge，评估有效样本量，不能直接把日样本数量当成独立观测数。',
    ),
    Insertion(
        chapter='07',
        number='7-2',
        image='figures/ch07_bias_variance.png',
        alt='多项式阶数从 1 到 12 的训练与测试 MSE 曲线',
        title='训练与验证误差',
        caption=(
            '复杂度增加时训练误差下降，验证误差用于选择阶数；最终测试集应保留到模型确定后评价。本例高阶验证误差略有上升，不必形成明显 U 形。数据类型：固定 seed 多项式回归样本；'
            '真实金融任务还须按时间切分。'
        ),
        anchor='复杂度应由样本外稳定性、数据量、执行收益和可解释性证明，而不是由模型名字决定。',
    ),
    Insertion(
        chapter='07',
        number='7-3',
        image='figures/ch07_calibration.png',
        alt='原始模型概率与校准后概率相对实现频率的校准曲线',
        title='概率必须经得起频率检验',
        caption=(
            '对角线表示预测概率等于实现频率。原始概率经过幂变换而系统性偏低，示意映射后更接近对角线；图中没有训练独立的校准器，也不能据此报告样本外校准表现。数据类型：固定 '
            'seed 的合成概率与二元标签。'
        ),
        anchor='可用 reliability diagram、Brier score、Platt scaling 或 isotonic regression 检查，但校准参数同样只能用训练/验证数据。',
    ),
    Insertion(
        chapter='07',
        number='7-4',
        image='figures/ch07_importance_stability.png',
        alt='带 bootstrap 误差棒的 permutation importance',
        title='重要性与不确定度',
        caption=(
            '在固定 seed 的合成 iid 回归中，对训练集做 30 次 bootstrap，每次在独立留出集逐特征置换，记录 MSE 增量。柱高是均值，误差棒为 ±1 '
            '标准差；它们不是置信区间，也不能支持真实交易信号或因果效应的结论。数据类型：可复现的合成回归与置换计算。'
        ),
        anchor='解释性要围绕研究问题：模型是不是只依赖一个不稳定字段？去掉文本、市场 beta 或某一资产后是否还成立？',
    ),
    Insertion(
        chapter='07',
        number='7-5',
        image='figures/ch07_feature_drift.png',
        alt='同一特征在 2018–2023 年的分布山脊图与 KS 统计量',
        title='特征漂移的可见形态',
        caption=(
            '各年份的合成特征分布不同，2021 年后均值右移且波动扩大；2019 与 2023 的双样本 KS 统计量约为 0.50。分布漂移提示重新检查标准化与模型假设，'
            '不等于所有阈值或预测能力都已失效。数据类型：固定 seed 合成特征。'
        ),
        anchor='部署前定义再训练频率、触发阈值、回滚版本和人工复核。不要看到一周亏损就随意调参，否则 live 结果被噪声追着走。',
    ),
    Insertion(
        chapter='08',
        number='8-1',
        image='figures/ch08_text_timeline.png',
        alt='文本的事件、发布、入库、特征可用四个时间戳与 as-of 切线',
        title='每份文本的四个时间戳',
        caption=(
            '事件、发布、入库与特征完成时间需要分别保存。信号只能使用发布时间、入库时间和特征可用时间均不晚于决策时点的版本；修订不能覆盖旧版本。灰色虚线表示一次决策时点。数据类型：概念时间轴。'
        ),
        anchor='新闻聚合器可能显示原始发布时间，也可能把旧文重新推到首页；网页抓取要保存原文、HTML/hash 和抓取时间。',
    ),
    Insertion(
        chapter='08',
        number='8-2',
        image='figures/ch08_token_to_vector.png',
        alt='token 乘维度的 embedding 矩阵与 token 间余弦相似度',
        title='文本如何变成矩阵',
        caption=(
            '左图是 6 个 token 在 6 个维度上的示例向量；右图是它们两两之间的余弦相似度：revenue/up/growth 聚在一起，down/risk/lawsuit '
            '聚在一起。embedding 把“语义相近”变成可计算的距离，但语义相近不等于收益方向相同。数据类型：概念示意图（手写示例向量）。'
        ),
        anchor='市场需要的是与未来收益或事件相关的增量信息。',
    ),
    Insertion(
        chapter='08',
        number='8-3',
        image='figures/ch08_embedding_scatter.png',
        alt='二维 embedding 投影散点与线性分类边界',
        title='线性分类头在哪里会错',
        caption=(
            '三组合成二维点表示正面、负面与歧义文档，直线是示意分类边界。投影中的重叠不能直接当作高维模型的实测错误率；真实系统还应检验拒绝机制与样本外表现。数据类型：固定 '
            'seed 合成投影与手设直线。'
        ),
        anchor='要记录 embedding 模型版本和生成日期。',
    ),
    Insertion(
        chapter='08',
        number='8-4',
        image='figures/ch08_label_agreement.png',
        alt="LLM 标签与人工标签的混淆矩阵及 Cohen's kappa",
        title='LLM 标签要先过人工一致性',
        caption=(
            '400 对合成标签的一致率为 85.0%，Cohen’s kappa 约为 0.70。矩阵只演示一致性指标；人工标签不是天然真值，一致性也不能证明收益预测能力。'
            '数据类型：固定 seed 生成的标签对，不是真实 LLM 评测。'
        ),
        anchor='- evidence validity 检查模型是否给出支持结论的原文。',
    ),
    Insertion(
        chapter='08',
        number='8-5',
        image='figures/ch08_ablation_oos.png',
        alt='项目 B 样本外 ablation：均值、仅市场、市场加词典文本',
        title='文本增量必须和 baseline 同框比较',
        caption=(
            '三组柱状图是项目 B 在合成 filing 上的样本外 rank IC、平均净收益与平均换手：market-only ridge 相对均值预测有明确增量，加入词典文本后 '
            'IC 略升但净收益和换手同时变差——增量是否值得，必须放在同一时间切分和同一成本下判断。数据类型：projects/ml_llm_research 的确定性输出。'
        ),
        anchor='使用相同时间切分和成本，检验文本是否带来增量 IC、净收益或降低风险，而不是只报告语言任务 F1。',
    ),
    Insertion(
        chapter='09',
        number='9-1',
        image='figures/ch09_pipeline_layers.png',
        alt='研究管线五层与每层的检查门',
        title='六层结构，每层一个检查门',
        caption=(
            '六个环节依次是数据、特征、信号、组合、执行和报告；箭头按处理方向向下。每一步都应有明确输入输出与检查条件。数据类型：研究工作流概念示意。'
        ),
        anchor='每个箭头都可能引入错误。策略不是“模型 + equity curve”，而是研究、组合、执行、风险和运营的联合系统。',
    ),
    Insertion(
        chapter='09',
        number='9-2',
        image='figures/ch09_stage_gates.png',
        alt='从 100 个想法到 1 个生产候选的 stage gate 漏斗',
        title='大多数想法应该早死',
        caption=(
            '漏斗从 100 个想法逐层筛到 1 个生产候选，每个 gate 右侧写着通过证据：机制一句话、样本外验证、成本与容量、纸面交易、监控与回滚。漏斗的意义不是淘汰本身，'
            '而是让失败发生在占用资金之前。数据类型：概念示意图（比例为示意，不是任何公司的真实漏斗）。'
        ),
        anchor='任何 gate 失败都应留下记录。研究的产物不是“通过所有 gate 的故事”，而是下一位研究员能定位失败发生在哪一层。',
    ),
]
