"""Verification for lecture figures.

Checks (all offline, all deterministic):

1. every ``![...](figures/...)`` reference in the Markdown lectures and in the
   notebook markdown cells points at a file that exists;
2. figure numbers inside each chapter are sequential (图 N-1, N-2, ...);
3. every figure caption states its data provenance (``数据类型：``), so no image
   can pretend to be real market data or investment advice;
4. every registered insertion in ``figure_insertions.py`` is present in both the
   Markdown file and the notebook (Markdown and notebook cannot drift);
5. no orphan PNG: every file in ``lectures/figures/`` is either referenced by a
   lecture or listed as a notebook-generated figure;
6. ``figures/manifest.json`` matches the files on disk, including SHA-256, so a
   stale or hand-edited figure is detected.

Usage::

    .venv/bin/python lectures/check_figures.py
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import nbformat  # noqa: E402

from figure_insertions import INSERTIONS, block  # noqa: E402
from make_figures import NOTEBOOK_FIGURES  # noqa: E402

IMAGE_RE = re.compile(r"!\[(?P<alt>[^\]]*)\]\((?P<path>figures/[^)]+)\)")
CAPTION_RE = re.compile(r"\*\*图 (?P<chapter>\d+)-(?P<number>\d+)｜(?P<title>[^*]+)。\*\* (?P<body>[^\n]*)")


def markdown_texts() -> dict[str, str]:
    texts = {}
    for path in sorted(HERE.glob("*.md")):
        if path.name in {"README.md"}:
            continue
        texts[path.name] = path.read_text(encoding="utf-8")
    return texts


def notebook_markdown_texts() -> dict[str, str]:
    texts = {}
    for path in sorted(HERE.glob("*.ipynb")):
        notebook = nbformat.read(str(path), as_version=4)
        texts[path.name] = "\n\n".join(
            "".join(cell.source) for cell in notebook.cells if cell.cell_type == "markdown"
        )
    return texts


def main() -> int:
    problems: list[str] = []
    md_texts = markdown_texts()
    nb_texts = notebook_markdown_texts()

    # 1. references resolve
    referenced: set[str] = set()
    for name, text in {**md_texts, **nb_texts}.items():
        for match in IMAGE_RE.finditer(text):
            relative = match.group("path")
            referenced.add(relative)
            if not (HERE / relative).exists():
                problems.append(f"{name}: missing image {relative}")

    # 2 + 3. numbering and provenance
    for name, text in md_texts.items():
        captions = CAPTION_RE.findall(text)
        numbers = [int(number) for _, number, _, _ in captions]
        if numbers != list(range(1, len(numbers) + 1)):
            problems.append(f"{name}: figure numbers not sequential: {numbers}")
        for _, _, _, body in captions:
            if "数据类型：" not in body:
                problems.append(f"{name}: caption without 数据类型 provenance: {body[:40]}...")

    # 4. md / notebook parity
    for entry in INSERTIONS:
        blk = block(entry)
        first_line = blk.splitlines()[0]
        md_name = next((name for name in md_texts if name.startswith(entry.chapter + "-")), None)
        nb_name = next((name for name in nb_texts if name.startswith(entry.chapter + "-")), None)
        if md_name and first_line not in md_texts[md_name]:
            problems.append(f"{md_name}: missing figure {entry.image}")
        if nb_name and first_line not in nb_texts[nb_name]:
            problems.append(f"{nb_name}: missing figure {entry.image}")

    # 5. orphans
    manifest_path = HERE / "figures" / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
    known = referenced | {f"figures/{name}" for name in NOTEBOOK_FIGURES}
    for path in sorted((HERE / "figures").glob("*.png")):
        if f"figures/{path.name}" not in known:
            problems.append(f"orphan figure not referenced by any lecture: {path.name}")

    # 6. manifest integrity
    for entry in manifest.get("figures", []):
        path = HERE / "figures" / entry["file"]
        if not path.exists():
            problems.append(f"manifest lists missing file {entry['file']}")
            continue
        from figures_kit.style import sha256

        if sha256(path) != entry["sha256"]:
            problems.append(f"figure differs from manifest (re-run make_figures.py): {entry['file']}")

    if problems:
        print("figure check FAILED:")
        for problem in problems:
            print("  -", problem)
        return 1
    print(
        f"figure check OK: {len(referenced)} referenced images, "
        f"{sum(len(CAPTION_RE.findall(t)) for t in md_texts.values())} captions, "
        f"{len(INSERTIONS)} registered insertions, manifest entries {len(manifest.get('figures', []))}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
