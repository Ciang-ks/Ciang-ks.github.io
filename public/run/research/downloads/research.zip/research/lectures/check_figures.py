"""Check Notebook structure, figure captions, placements and image integrity."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import nbformat  # noqa: E402

from figure_insertions import INSERTIONS, block  # noqa: E402

IMAGE_RE = re.compile(r"!\[(?P<alt>[^\]]*)\]\((?P<path>figures/[^)]+)\)")
CAPTION_RE = re.compile(r"\*\*图 (?P<chapter>\d+)-(?P<number>\d+)｜(?P<title>[^*]+)。\*\* (?P<body>[^\n]*)")


def notebook_markdown_texts() -> dict[str, str]:
    texts = {}
    for path in sorted(HERE.glob("*.ipynb")):
        notebook = nbformat.read(str(path), as_version=4)
        nbformat.validate(notebook)
        texts[path.name] = "\n\n".join(
            "".join(cell.source) for cell in notebook.cells if cell.cell_type == "markdown"
        )
    return texts


def main() -> int:
    problems: list[str] = []
    nb_texts = notebook_markdown_texts()

    # 1. references resolve
    referenced: set[str] = set()
    for name, text in nb_texts.items():
        for match in IMAGE_RE.finditer(text):
            relative = match.group("path")
            referenced.add(relative)
            if not (HERE / relative).exists():
                problems.append(f"{name}: missing image {relative}")

    # 2 + 3. numbering and provenance
    for name, text in nb_texts.items():
        captions = CAPTION_RE.findall(text)
        numbers = [int(number) for _, number, _, _ in captions]
        if numbers != list(range(1, len(numbers) + 1)):
            problems.append(f"{name}: figure numbers not sequential: {numbers}")
        for _, _, _, body in captions:
            if "数据类型：" not in body:
                problems.append(f"{name}: caption without 数据类型 provenance: {body[:40]}...")

    # 4. Registered notebook placements
    for entry in INSERTIONS:
        blk = block(entry)
        first_line = blk.splitlines()[0]
        nb_name = next((name for name in nb_texts if name.startswith(entry.chapter + "-")), None)
        if nb_name is None:
            problems.append(f"missing notebook for chapter {entry.chapter}")
        if nb_name and first_line not in nb_texts[nb_name]:
            problems.append(f"{nb_name}: missing figure {entry.image}")

    # 5. orphans
    manifest_path = HERE / "figures" / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
    known = referenced
    for path in sorted((HERE / "figures").glob("*.png")):
        if f"figures/{path.name}" not in known:
            problems.append(f"orphan figure not referenced by any lecture: {path.name}")

    # 6. manifest integrity
    for entry in manifest.get("figures", []):
        path = HERE / "figures" / entry["file"]
        if not path.exists():
            problems.append(f"manifest lists missing file {entry['file']}")
            continue
        from figures_kit.style import sha256

        if sha256(path) != entry["sha256"]:
            problems.append(f"figure differs from manifest (re-run make_figures.py): {entry['file']}")

    if problems:
        print("figure check FAILED:")
        for problem in problems:
            print("  -", problem)
        return 1
    print(
        f"figure check OK: {len(referenced)} referenced images, "
        f"{sum(len(CAPTION_RE.findall(t)) for t in nb_texts.values())} captions, "
        f"{len(INSERTIONS)} registered insertions, manifest entries {len(manifest.get('figures', []))}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
