# 基础讲义

先理解概念，再手推一个例子，最后运行对应实验。

| 章节 | 讲义 |
|---|---|
| 01 | [市场、资产与交易对象](01-markets-assets.md) |
| 02 | [收益、风险、组合与绩效](02-returns-risk.md) |
| 03 | [概率、统计推断与回归](03-probability-statistics.md) |
| 04 | [数据、偏差与量化研究管线](04-data-pipeline.md) |
| 05 | [策略、Alpha 与信号研究](05-strategies-alpha.md) |
| 06 | [组合构建、执行与风险控制](06-portfolio-execution.md) |
| 07 | [机器学习用于量化研究](07-machine-learning.md) |
| 08 | [LLM4Quant 与文本研究](08-language-models.md) |
| 09 | [全链路项目、岗位能力与面试表达](09-research-communication.md) |

[学习路线](../roadmap.md) · [Notebook 与项目下载](../downloads.md)
