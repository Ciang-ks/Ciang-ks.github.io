"""Shared style, registry and save helpers for lecture figures.

Design rules (see ``lectures/figures/README.md``):

1. Every figure is drawn by this repository. No third-party image is copied,
   so there is no licence/attribution burden and no hot-linking.
2. In-figure text prefers Chinese when a CJK font is available and falls back
   to English otherwise, so the same script renders on any machine.
3. Rendering is deterministic: fixed seeds, fixed figure sizes, and PNG
   metadata stripped of timestamps. Re-running must produce identical bytes.
4. Each figure declares what kind of data it shows (concept sketch, public
   local snapshot, deterministic synthetic teaching data, or project output)
   so a reader can never mistake an illustration for real tradable results.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Callable, Iterable, Sequence

import logging
import matplotlib

matplotlib.use("Agg")
logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)

import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.figure import Figure  # noqa: E402

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------

HERE = Path(__file__).resolve().parent          # research/lectures
LECTURES_DIR = HERE.parent                      # research/lectures (package lives here)
REPO_ROOT = LECTURES_DIR.parent                 # research
FIG_DIR = LECTURES_DIR / "figures"
DATA_DIR = REPO_ROOT / "sources" / "external" / "data"
PROJECTS_DIR = REPO_ROOT / "projects"

# Textbook-ish palette: colour-blind friendly and stable across figures.
COLORS = {
    "price": "#1f4e79",
    "signal": "#c0504d",
    "cost": "#7f7f7f",
    "positive": "#2e7d32",
    "negative": "#b71c1c",
    "neutral": "#4d4d4d",
    "accent": "#e08214",
    "muted": "#9ecae1",
    "band": "#dbe5f1",
}

CJK_FONT_CANDIDATES: tuple[str, ...] = (
    "Noto Sans CJK SC",
    "Noto Sans CJK JP",
    "Source Han Sans SC",
    "Source Han Sans CN",
    "WenQuanYi Zen Hei",
    "Microsoft YaHei",
    "PingFang SC",
    "Hiragino Sans GB",
    "SimHei",
    "AR PL UMing CN",
)


# --------------------------------------------------------------------------
# Language / font handling
# --------------------------------------------------------------------------

@dataclass
class StyleState:
    lang: str = "auto"          # "auto" | "zh" | "en"
    resolved_lang: str = "en"   # what figures actually use
    cjk_font: str | None = None
    dpi: int = 150
    style_name: str | None = None


STATE = StyleState()


def _find_cjk_font() -> str | None:
    from matplotlib import font_manager

    available = {font.name for font in font_manager.fontManager.ttflist}
    for candidate in CJK_FONT_CANDIDATES:
        if candidate in available:
            return candidate
    return None


def setup(lang: str = "auto", dpi: int = 150) -> StyleState:
    """Configure matplotlib once per process and resolve the figure language."""

    STATE.lang = lang
    STATE.dpi = dpi

    style_name = None
    for candidate in ("seaborn-v0_8-whitegrid", "seaborn-whitegrid"):
        try:
            plt.style.use(candidate)
            style_name = candidate
            break
        except (OSError, ValueError):
            continue
    STATE.style_name = style_name

    cjk_font = _find_cjk_font()
    STATE.cjk_font = cjk_font
    if lang == "zh":
        STATE.resolved_lang = "zh"
    elif lang == "en":
        STATE.resolved_lang = "en"
    else:
        STATE.resolved_lang = "zh" if cjk_font else "en"

    plt.rcParams.update(
        {
            "figure.dpi": dpi,
            "savefig.dpi": dpi,
            "figure.figsize": (9.0, 5.0),
            "axes.unicode_minus": False,
            "axes.titlesize": 12,
            "axes.labelsize": 10,
            "xtick.labelsize": 9,
            "ytick.labelsize": 9,
            "legend.fontsize": 9,
            "font.size": 10,
            "savefig.bbox": "tight",
            "savefig.pad_inches": 0.12,
        }
    )
    if STATE.resolved_lang == "zh" and cjk_font:
        plt.rcParams["font.family"] = "sans-serif"
        plt.rcParams["font.sans-serif"] = [cjk_font, "DejaVu Sans"]
    else:
        plt.rcParams["font.family"] = "sans-serif"
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans"]
    return STATE


def L(en: str, zh: str) -> str:
    """Return the in-figure label for the resolved language."""

    if STATE.resolved_lang == "zh" and zh:
        return zh
    return en


# --------------------------------------------------------------------------
# Figure registry
# --------------------------------------------------------------------------

KINDS = {
    "concept": "概念示意图（手绘数据，只说明结构，不代表任何真实市场数值）",
    "synthetic": "确定性合成教学数据（由固定 seed 生成，非真实行情）",
    "public_data": "公开数据本地快照（sources/external/data，非实时、不构成投资建议）",
    "project_output": "本仓库项目的可复现输出（合成数据 + 固定 pipeline，非真实交易结果）",
}


@dataclass(frozen=True)
class FigureSpec:
    chapter: str                 # "01" ... "09"
    name: str                    # file stem, e.g. "ch01_candle_anatomy"
    section: str                 # where it is used, e.g. "§2.1 OHLCV 的含义"
    kind: str                    # key of KINDS
    title: str                   # short Chinese description used in the manifest
    note: str = ""               # extra provenance / caveat sentence
    figsize: tuple[float, float] = (9.0, 5.0)
    func: Callable[["FigureSpec"], Path] | None = field(default=None, repr=False, compare=False)

    @property
    def filename(self) -> str:
        return f"{self.name}.png"

    @property
    def path(self) -> Path:
        return FIG_DIR / self.filename

    def __post_init__(self) -> None:
        if self.kind not in KINDS:
            raise ValueError(f"unknown figure kind {self.kind!r}; expected one of {sorted(KINDS)}")


REGISTRY: dict[str, list[FigureSpec]] = {}


def figure(
    chapter: str,
    name: str,
    *,
    section: str,
    kind: str,
    title: str,
    note: str = "",
    figsize: tuple[float, float] = (9.0, 5.0),
) -> Callable[[Callable[["FigureSpec"], Path]], Callable[["FigureSpec"], Path]]:
    """Register a builder ``def build(spec) -> Path`` as a lecture figure."""

    def decorator(func: Callable[["FigureSpec"], Path]) -> Callable[["FigureSpec"], Path]:
        spec = FigureSpec(
            chapter=chapter,
            name=name,
            section=section,
            kind=kind,
            title=title,
            note=note,
            figsize=figsize,
            func=func,
        )
        REGISTRY.setdefault(chapter, []).append(spec)
        return func

    return decorator


def all_specs(chapters: Sequence[str] | None = None) -> list[FigureSpec]:
    specs: Iterable[FigureSpec] = (
        spec for chapter in sorted(REGISTRY) for spec in REGISTRY[chapter]
    )
    if chapters:
        wanted = {str(chapter).zfill(2) for chapter in chapters}
        specs = [spec for spec in specs if spec.chapter in wanted]
    return list(specs)


def render(spec: FigureSpec) -> Path:
    """Run one registered builder and return the written PNG path."""

    if spec.func is None:
        raise ValueError(f"figure {spec.name!r} has no builder")
    path = spec.func(spec)
    if Path(path) != spec.path:
        raise AssertionError(f"{spec.name}: builder saved {path}, expected {spec.path}")
    return Path(path)


# --------------------------------------------------------------------------
# Drawing / saving helpers
# --------------------------------------------------------------------------

def new_figure(spec: FigureSpec, nrows: int = 1, ncols: int = 1, **kwargs):
    """Create a figure sized from the spec (keeps sizes reproducible)."""

    squeeze = kwargs.pop("squeeze", True)
    if nrows == 1 and ncols == 1:
        fig, ax = plt.subplots(figsize=spec.figsize, **kwargs)
        return fig, ax
    fig, axes = plt.subplots(nrows, ncols, figsize=spec.figsize, squeeze=squeeze, **kwargs)
    return fig, axes


def finalize(fig: Figure, spec: FigureSpec, *, titles: Sequence[str] | None = None) -> Path:
    """Save a figure deterministically and return its path."""

    FIG_DIR.mkdir(parents=True, exist_ok=True)
    if titles:
        fig.suptitle(titles[0], fontsize=12)
    path = spec.path
    fig.savefig(
        path,
        dpi=STATE.dpi,
        bbox_inches="tight",
        metadata={"Software": "research lectures", "Creation Time": None},
    )
    plt.close(fig)
    return path


def sha256(path: Path) -> str:
    import hashlib

    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def spec_to_manifest_entry(spec: FigureSpec, path: Path) -> dict:
    entry = asdict(spec)
    entry.pop("func", None)
    entry.update(
        {
            "file": path.name,
            "kind_explained": KINDS[spec.kind],
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
        }
    )
    return entry


def plain_log_ticks(ax, axis: str = "both") -> None:
    """Replace mathtext log tick labels with plain text.

    CJK fonts such as WenQuanYi lack the U+2212 glyph that mathtext uses for
    exponents, which would render broken boxes on log axes. Plain decimal
    labels avoid the problem on every machine.
    """

    import matplotlib.ticker as mticker

    names = {"x": ("x",), "y": ("y",), "both": ("x", "y")}[axis]
    for name in names:
        ticker_axis = getattr(ax, f"{name}axis")
        ticker_axis.set_major_formatter(mticker.FuncFormatter(lambda value, _: f"{value:g}"))
        ticker_axis.set_minor_formatter(mticker.NullFormatter())


def annotate_source(ax, text: str, *, y: float = -0.16) -> None:
    """Print the data provenance line inside the figure, under the axes."""

    ax.text(
        0.0,
        y,
        text,
        transform=ax.transAxes,
        fontsize=7.5,
        color="#555555",
        verticalalignment="top",
    )
