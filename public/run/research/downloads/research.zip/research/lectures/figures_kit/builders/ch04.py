"""Figures for chapter 04 (data, bias and the research pipeline)."""

from __future__ import annotations

import numpy as np
import pandas as pd

from ..style import COLORS, L, annotate_source, figure, finalize, new_figure


@figure(
    "04",
    "ch04_three_timestamps",
    section="§1.2 三个时间必须分开",
    kind="concept",
    title="报告期末、披露时间、可交易时间：三个必须分开的时间戳",
    note="时间轴为示意；真实研究中这三个时间可能相差数周到数月。",
    figsize=(10.2, 4.2),
)
def three_timestamps(spec):
    fig, ax = new_figure(spec)
    events = [
        (0.0, L("period end\n(report describes this window)", "报告期末\n（财报描述的经营期间）"), COLORS["price"]),
        (2.0, L("filing / release\n(investors first see it)", "披露\n首次公开"), COLORS["accent"]),
        (3.6, L("tradable\n(first signal date that may use it)", "可交易\n首次允许使用"), COLORS["positive"]),
    ]
    ax.hlines(0, -0.6, 4.6, color=COLORS["neutral"], lw=1.4)
    for x, text, color in events:
        ax.plot([x], [0], "o", color=color, ms=11, zorder=3)
        ax.text(x, 0.32, text, ha="center", va="bottom", fontsize=9, color=color)
        ax.vlines(x, 0, 0.26, color=color, lw=1.0)
    ax.axvspan(0.0, 2.0, ymin=0.06, ymax=0.24, color=COLORS["negative"], alpha=0.12)
    ax.text(
        1.0,
        -0.42,
        L(
            "leak window: using the number before publication = information leakage",
            "泄漏窗口：披露前使用该数字 = 信息泄漏",
        ),
        ha="center",
        fontsize=9,
        color=COLORS["negative"],
    )
    ax.annotate(
        "",
        xy=(0.05, -0.22),
        xytext=(1.95, -0.22),
        arrowprops=dict(arrowstyle="<->", color=COLORS["negative"], lw=1.1),
    )
    ax.set_xlim(-0.8, 4.8)
    ax.set_ylim(-0.8, 1.5)
    ax.set_yticks([])
    ax.set_xticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.set_title(
        L(
            "One number, three timestamps",
            "同一个数字的三个时间戳：期末、披露、可交易",
        )
    )
    annotate_source(
        ax,
        L(
            "Concept sketch: the horizontal distances are illustrative, not a real filing calendar.",
            "概念示意图：水平距离为示意，不是真实财报日历。",
        ),
        y=-0.02,
    )
    return finalize(fig, spec)


@figure(
    "04",
    "ch04_survivorship",
    section="§3.1 Survivorship bias（幸存者偏差）",
    kind="synthetic",
    title="幸存者偏差：只用活到今天的成分会系统性高估历史收益",
    note="固定 seed 合成 universe：8 个成分中 3 个中途退市（退市前收益为负）。",
    figsize=(10.4, 4.8),
)
def survivorship(spec):
    rng = np.random.default_rng(505)
    days = 500
    index = pd.RangeIndex(days, name="day")
    names = [f"A{i}" for i in range(8)]
    delist = {"A3": 180, "A5": 300, "A6": 420}
    drifts = rng.normal(0.0004, 0.0006, 8)
    for i, name in enumerate(names):
        if name in delist:
            drifts[i] = -0.004
    prices = pd.DataFrame(index=index, columns=names, dtype=float)
    for i, name in enumerate(names):
        path = 100 * np.exp(np.cumsum(drifts[i] + rng.normal(0, 0.012, days)))
        if name in delist:
            path[delist[name]:] = np.nan
        prices[name] = path

    survivors_mean = prices.dropna(axis=1).pct_change(fill_method=None).mean(axis=1).mean() * 252
    full_mean = prices.pct_change(fill_method=None).mean(axis=1).mean() * 252

    fig, (ax, axb) = new_figure(spec, 1, 2, width_ratios=[2.0, 1])
    for name in names:
        dead = name in delist
        ax.plot(prices.index, prices[name], lw=1.3,
                color=COLORS["negative"] if dead else COLORS["price"],
                alpha=0.9 if dead else 0.65,
                ls="--" if dead else "-")
        if dead:
            ax.plot([delist[name]], [prices[name].dropna().iloc[-1]], "x", color=COLORS["negative"], ms=9)
            ax.text(delist[name] + 8, prices[name].dropna().iloc[-1], L(f"{name} delists", f"{name} 退市"),
                    fontsize=8.5, color=COLORS["negative"], va="center")
    ax.set_yscale("log")
    from ..style import plain_log_ticks

    plain_log_ticks(ax, "y")
    ax.set_xlabel(L("day", "交易日"))
    ax.set_ylabel(L("price (log scale)", "价格（对数刻度）"))
    ax.set_title(L("8 members, 3 delist", "8 个成分，3 个中途退市（灰色虚线）"))

    bars = axb.bar(
        [0, 1],
        [survivors_mean * 100, full_mean * 100],
        color=[COLORS["negative"], COLORS["positive"]],
        alpha=0.85,
        width=0.55,
    )
    axb.set_xticks([0, 1])
    axb.set_xticklabels(
        [L("survivors only\n(today's list)", "只用幸存者\n（今天的成分表）"), L("full history\n(incl. delisted)", "可见历史\n（含退市前价格）")],
        fontsize=9,
    )
    axb.set_ylabel(L("annualized mean return (%)", "日均收益 × 252（%）"))
    axb.set_ylim(min(full_mean, 0) * 100 - 4, max(survivors_mean, 0) * 100 + 4)
    for bar, value in zip(bars, (survivors_mean, full_mean)):
        height = bar.get_height()
        offset = 0.5 if height >= 0 else -0.5
        axb.text(
            bar.get_x() + bar.get_width() / 2,
            height + offset,
            f"{value:.1%}",
            ha="center",
            va="bottom" if height >= 0 else "top",
            fontsize=9,
        )
    axb.set_title(L("the bias is a level shift", "剔除退市样本改变统计"))
    annotate_source(
        axb,
        L(
            "Synthetic universe (fixed seed). A backtest that starts from today's index members never sees the red paths.",
            "合成 universe（固定 seed）。仅比较可见价格收益，未模拟退市最终清算损益。",
        ),
        y=-0.34,
    )
    fig.get_layout_engine().execute(fig)
    return finalize(fig, spec)


@figure(
    "04",
    "ch04_lookahead_alignment",
    section="§3.2 Look-ahead bias（前视偏差）",
    kind="synthetic",
    title="信号对齐错了会制造假 IC：r_t 与 r_{t+1} 的差别",
    note="固定 seed 独立收益；信号含当天收益，比较同日误配与次日预测。",
    figsize=(10.2, 4.8),
)
def lookahead_alignment(spec):
    rng = np.random.default_rng(606)
    n = 1500
    returns = rng.normal(size=n)
    # A close-derived feature can describe its own day without predicting tomorrow.
    signal = 0.85 * returns + rng.normal(0, 0.65, n)
    fig, axes = new_figure(spec, 1, 2)
    pairs = [(signal[1:], returns[1:], L("Same day: unavailable before the return", "同日配对：收益发生后才有信号")),
             (signal[:-1], returns[1:], L("Next day: genuinely forward", "次日配对：检验未来预测能力"))]
    for ax, (x, y, title) in zip(axes, pairs):
        ic = np.corrcoef(x, y)[0, 1]
        ax.scatter(x, y, s=7, alpha=0.22, color=COLORS["price"], edgecolor="none")
        slope, intercept = np.polyfit(x, y, 1)
        grid = np.linspace(x.min(), x.max(), 60)
        ax.plot(grid, intercept + slope * grid, color=COLORS["neutral"], lw=1.6)
        ax.set_xlabel(L("close-derived signal", "收盘后生成的信号"))
        ax.set_ylabel(L("paired return", "配对收益"))
        ax.set_title(f"{title}\nIC = {ic:.2f}", fontsize=10)
    annotate_source(axes[1], L("Synthetic iid returns; each panel's IC and line use exactly the displayed pairs.", "合成独立收益；各图的 IC、拟合线与散点使用同一组配对。"))
    return finalize(fig, spec)


@figure(
    "04",
    "ch04_time_splits",
    section="§5.3 Purged 和 embargo split",
    kind="concept",
    title="三种时间切分：单次 holdout、walk-forward、purged + embargo",
    note="色块表示训练/验证/测试区间；embargo 是为重叠标签留出的隔离带。",
    figsize=(10.4, 5.2),
)
def time_splits(spec):
    fig, axes = new_figure(spec, 3, 1, sharex=True)

    def band(ax, x0, x1, y, color, label):
        ax.barh(y, x1 - x0, left=x0, height=0.55, color=color, alpha=0.85, edgecolor="white")
        ax.text((x0 + x1) / 2, y, label, ha="center", va="center", fontsize=8.5, color="white")

    ax = axes[0]
    band(ax, 0, 60, 0, COLORS["price"], L("train", "训练"))
    band(ax, 60, 80, 0, COLORS["accent"], L("val", "验证"))
    band(ax, 80, 100, 0, COLORS["positive"], L("test", "测试"))
    ax.set_ylabel(L("single holdout", "单次切分"), fontsize=9)

    ax = axes[1]
    for fold, start in enumerate((0, 20, 40)):
        band(ax, start, start + 40, fold, COLORS["price"], L("train", "训练"))
        band(ax, start + 40, start + 55, fold, COLORS["positive"], L("test", "测试"))
    ax.set_ylabel(L("walk-forward", "滚动向前"), fontsize=9)

    ax = axes[2]
    band(ax, 0, 55, 0, COLORS["price"], L("train", "训练"))
    ax.barh(0, 5, left=55, height=0.55, color=COLORS["negative"], alpha=0.9, edgecolor="white")
    ax.text(57.5, 0.62, L("purge + embargo", "purge + embargo 隔离带"), ha="center", fontsize=8.5, color=COLORS["negative"])
    band(ax, 60, 80, 0, COLORS["accent"], L("val", "验证"))
    ax.barh(0, 3, left=80, height=0.55, color=COLORS["negative"], alpha=0.9, edgecolor="white")
    band(ax, 83, 100, 0, COLORS["positive"], L("test", "测试"))
    ax.set_ylabel(L("purged split", "带隔离的切分"), fontsize=9)
    ax.set_xlabel(L("time →", "时间 →"))

    for ax in axes:
        ax.set_yticks([])
        ax.set_xlim(0, 100)
        ax.set_ylim(-0.7, 3.0 if ax is axes[1] else 0.7)
        for spine in ax.spines.values():
            spine.set_visible(False)
    axes[0].set_title(
        L(
            "Time splits: never shuffle a time series",
            "时间切分的三种做法：永远不要随机打乱时间序列",
        )
    )
    annotate_source(
        axes[2],
        L(
            "Concept sketch. Purge removes samples whose labels overlap the boundary; embargo adds a safety gap.",
            "概念示意图。purge 删除标签跨越边界的样本，embargo 再留一段安全间隔。",
        ),
        y=-0.55,
    )
    fig.get_layout_engine().execute(fig)
    return finalize(fig, spec)


@figure(
    "04",
    "ch04_signal_to_fill",
    section="§6.1 Signal、position、order、fill",
    kind="concept",
    title="从信号到成交的时间链：哪一天的收益才属于这个信号",
    note="时刻为示意（收盘 16:00、次日开盘 09:30）；重点是收益归属区间。",
    figsize=(10.6, 4.6),
)
def signal_to_fill(spec):
    fig, ax = new_figure(spec)
    rows = [
        (2.0, L("t close 16:00\nsignal computed from data ≤ t", "t 日收盘 16:00\n只用收盘前已知数据"), COLORS["price"]),
        (1.0, L("t+1 open 09:30\norder sent and filled (+ impact)", "t+1 开盘 09:30\n下单并成交（含冲击成本）"), COLORS["accent"]),
        (0.0, L("t+1 open to t+2 open\nis the holding interval", "次日开盘买入\n下一个开盘卖出"), COLORS["positive"]),
    ]
    for y, text, color in rows:
        ax.barh(y, 3.0, left=0.4, height=0.5, color=color, alpha=0.85)
        ax.text(0.55, y, text, va="center", fontsize=9, color="white")
    ax.annotate(
        L("WRONG: fill at t close 16:00\n(the price was already gone)", "错误做法：按 t 日收盘价成交\n（信号产生时该价格已经过去）"),
        xy=(3.5, 2.0),
        xytext=(4.0, 2.75),
        fontsize=8.5,
        color=COLORS["negative"],
        arrowprops=dict(arrowstyle="->", color=COLORS["negative"], lw=0.9),
    )
    ax.annotate(
        "",
        xy=(3.5, 1.0),
        xytext=(3.5, 2.0),
        arrowprops=dict(arrowstyle="->", color=COLORS["neutral"], lw=1.2),
    )
    ax.annotate(
        "",
        xy=(3.5, 0.0),
        xytext=(3.5, 1.0),
        arrowprops=dict(arrowstyle="->", color=COLORS["neutral"], lw=1.2),
    )
    ax.set_xlim(0, 8.2)
    ax.set_ylim(-0.8, 3.4)
    ax.set_yticks([])
    ax.set_xticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.set_title(
        L(
            "Signal → position → order → fill: who earns which return",
            "信号 → 仓位 → 订单 → 成交：哪一段收益属于这个信号",
        )
    )
    annotate_source(
        ax,
        L(
            "Concept sketch of a daily research loop; intraday strategies use the same logic at finer timestamps.",
            "日频研究循环的概念示意图；日内策略在更细的时间戳上遵循同样逻辑。",
        ),
        y=-0.02,
    )
    return finalize(fig, spec)
