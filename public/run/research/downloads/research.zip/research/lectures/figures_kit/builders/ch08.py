"""Figures for chapter 08 (LLMs and text research)."""

from __future__ import annotations

import json

import numpy as np
import pandas as pd

from .. import data as D
from ..style import COLORS, L, annotate_source, figure, finalize, new_figure


@figure(
    "08",
    "ch08_text_timeline",
    section="§2.1 四种时间",
    kind="concept",
    title="文本的四种时间：事件、发布、入库、特征可用",
    note="时间轴为示意；as-of 切线右侧的信息在任何情况下都不能进入当天特征。",
    figsize=(10.4, 4.4),
)
def text_timeline(spec):
    fig, ax = new_figure(spec)
    events = [
        (0.4, L("event time\n(the fact happens)", "事件时间\n（事实发生）"), COLORS["price"]),
        (2.2, L("publish time\n(document becomes public)", "发布时间\n（文件公开）"), COLORS["accent"]),
        (3.4, L("ingest time\n(crawler / vendor stores it)", "入库时间\n（爬虫或供应商收录）"), COLORS["neutral"]),
        (4.4, L("feature time\n(parsed, aligned, usable)", "特征时间\n（解析、对齐、可用）"), COLORS["positive"]),
    ]
    ax.hlines(0, -0.4, 6.4, color=COLORS["neutral"], lw=1.4)
    for x, text, color in events:
        ax.plot([x], [0], "o", color=color, ms=11, zorder=3)
        ax.vlines(x, 0, 0.26, color=color, lw=1.0)
        ax.text(x, 0.34, text, ha="center", va="bottom", fontsize=9, color=color)
    asof = 5.2
    ax.axvline(asof, color=COLORS["negative"], lw=1.6, ls="--")
    ax.text(asof + 0.08, 1.05, L("as-of cut for today's signal", "今天信号的 as-of 切线"), fontsize=9, color=COLORS["negative"], va="top")
    ax.annotate(
        L(
            "a revision published after ingest\nmust not overwrite history",
            "入库之后发布的修订\n不允许覆盖历史版本",
        ),
        xy=(3.4, 0.0),
        xytext=(2.0, -0.62),
        fontsize=8.5,
        color=COLORS["negative"],
        arrowprops=dict(arrowstyle="->", color=COLORS["negative"], lw=0.9),
    )
    ax.set_xlim(-0.6, 6.6)
    ax.set_ylim(-1.0, 1.3)
    ax.set_yticks([])
    ax.set_xticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.set_title(L("Four timestamps for every document", "每份文本的四个时间戳"))
    annotate_source(
        ax,
        L(
            "Concept sketch. Project B stores publish date and aligns text features to it, not to the event date.",
            "概念示意图。项目 B 保存发布日期，并把文本特征对齐到发布日期而不是事件日期。",
        ),
        y=-0.04,
    )
    return finalize(fig, spec)


@figure(
    "08",
    "ch08_token_to_vector",
    section="§3.2 Embedding",
    kind="concept",
    title="Token 到向量：文本如何变成模型可以计算的矩阵",
    note="矩阵数值为手写示例，用于说明 token × 维度 的结构与相似度计算。",
    figsize=(10.2, 4.6),
)
def token_to_vector(spec):
    tokens = ["revenue", "up", "risk", "down", "lawsuit", "growth"]
    dims = [f"d{i}" for i in range(1, 7)]
    matrix = np.array(
        [
            [0.8, 0.6, 0.1, -0.2, 0.3, 0.5],
            [0.7, 0.5, 0.0, -0.1, 0.2, 0.6],
            [-0.4, -0.2, 0.8, 0.6, -0.3, -0.2],
            [-0.6, -0.4, 0.7, 0.5, -0.4, -0.3],
            [-0.5, -0.3, 0.9, 0.7, -0.2, -0.4],
            [0.6, 0.7, -0.1, -0.3, 0.4, 0.5],
        ]
    )

    fig, (ax, axs) = new_figure(spec, 1, 2, width_ratios=[1.5, 1], gridspec_kw=dict(wspace=0.35))
    im = ax.imshow(matrix, cmap="RdBu_r", vmin=-1, vmax=1, aspect="auto")
    ax.set_xticks(np.arange(len(dims)))
    ax.set_xticklabels(dims, fontsize=8.5)
    ax.set_yticks(np.arange(len(tokens)))
    ax.set_yticklabels(tokens, fontsize=9)
    for i in range(len(tokens)):
        for j in range(len(dims)):
            ax.text(j, i, f"{matrix[i, j]:+.1f}", ha="center", va="center", fontsize=7.5,
                    color="white" if abs(matrix[i, j]) > 0.55 else "#333333")
    ax.set_title(L("token × dimension embedding matrix", "token × 维度 的 embedding 矩阵"))
    fig.colorbar(im, ax=ax, pad=0.02, shrink=0.9)

    cosine = matrix @ matrix.T / np.outer(np.linalg.norm(matrix, axis=1), np.linalg.norm(matrix, axis=1))
    im2 = axs.imshow(cosine, cmap="RdBu_r", vmin=-1, vmax=1)
    axs.set_xticks(np.arange(len(tokens)))
    axs.set_xticklabels(tokens, rotation=45, ha="right", fontsize=8)
    axs.set_yticks(np.arange(len(tokens)))
    axs.set_yticklabels(tokens, fontsize=8)
    axs.set_title(L("cosine similarity between tokens", "token 之间的余弦相似度"))
    fig.colorbar(im2, ax=axs, pad=0.02, shrink=0.9)
    annotate_source(
        axs,
        L(
            "Hand-written example vectors. Real embeddings have hundreds of dimensions learned from corpora.",
            "手写示例向量。真实 embedding 有数百维，由语料训练得到。",
        ),
        y=-0.34,
    )
    fig.tight_layout()
    return finalize(fig, spec)


@figure(
    "08",
    "ch08_embedding_scatter",
    section="§4. Level 2：预训练 embedding + 轻量模型",
    kind="synthetic",
    title="二维 embedding 散点与线性分类边界：可分与不可分",
    note="固定 seed 合成 embedding；右簇重叠区域就是线性模型会犯错的地方。",
    figsize=(9.8, 5.0),
)
def embedding_scatter(spec):
    rng = np.random.default_rng(1212)
    n = 300
    positive = rng.normal([1.6, 0.8], [0.55, 0.5], size=(n, 2))
    negative = rng.normal([-1.2, -0.6], [0.7, 0.6], size=(n, 2))
    overlap = rng.normal([0.2, 0.1], [0.5, 0.5], size=(n // 3, 2))
    x = np.vstack([positive, negative, overlap])
    y = np.concatenate([np.ones(n), np.zeros(n), rng.uniform(0, 1, n // 3) < 0.5])

    fig, ax = new_figure(spec)
    ax.scatter(x[:n, 0], x[:n, 1], s=9, alpha=0.5, color=COLORS["positive"], edgecolor="none", label=L("positive tone docs", "正面语气文档"))
    ax.scatter(x[n : 2 * n, 0], x[n : 2 * n, 1], s=9, alpha=0.5, color=COLORS["negative"], edgecolor="none", label=L("negative tone docs", "负面语气文档"))
    ax.scatter(x[2 * n :, 0], x[2 * n :, 1], s=9, alpha=0.5, color=COLORS["neutral"], edgecolor="none", label=L("ambiguous docs", "歧义文档"))
    grid_x = np.linspace(-3, 3.5, 120)
    ax.plot(grid_x, -0.9 * grid_x + 0.25, color=COLORS["price"], lw=1.8, label=L("linear boundary on embeddings", "embedding 上的线性边界"))
    ax.set_xlabel(L("embedding dim 1 (projected)", "embedding 维度 1（投影）"))
    ax.set_ylabel(L("embedding dim 2 (projected)", "embedding 维度 2（投影）"))
    ax.set_title(L("Where a linear head on embeddings fails", "embedding 上的线性分类头在哪里会错"))
    ax.legend(loc="upper right", frameon=False, fontsize=8.5)
    annotate_source(
        ax,
        L(
            "Synthetic 2-D projection (fixed seed). Real embeddings need dimensionality reduction to be plotted.",
            "合成的二维投影（固定 seed）。真实 embedding 需要降维才能画出来。",
        ),
    )
    return finalize(fig, spec)


@figure(
    "08",
    "ch08_label_agreement",
    section="§7.1 Label quality",
    kind="synthetic",
    title="LLM 标签与人工标签的一致性：混淆矩阵与 Cohen's kappa",
    note="固定 seed 合成 400 份文档的双标签对照；kappa 扣除随机一致的部分。",
    figsize=(9.2, 4.8),
)
def label_agreement(spec):
    rng = np.random.default_rng(1313)
    n = 400
    human = rng.uniform(size=n) < 0.45
    flip = rng.uniform(size=n) < np.where(human, 0.12, 0.18)
    llm = np.where(flip, ~human, human)
    matrix = np.array(
        [
            [((human == 0) & (llm == 0)).sum(), ((human == 0) & (llm == 1)).sum()],
            [((human == 1) & (llm == 0)).sum(), ((human == 1) & (llm == 1)).sum()],
        ]
    )
    po = matrix.trace() / matrix.sum()
    pe = ((matrix.sum(axis=1) / matrix.sum()) * (matrix.sum(axis=0) / matrix.sum())).sum()
    kappa = (po - pe) / (1 - pe)

    fig, ax = new_figure(spec)
    im = ax.imshow(matrix, cmap="Blues", aspect="auto")
    labels = [L("neutral/negative", "中性/负面"), L("positive", "正面")]
    ax.set_xticks([0, 1])
    ax.set_xticklabels(labels, fontsize=9)
    ax.set_yticks([0, 1])
    ax.set_yticklabels(labels, fontsize=9)
    ax.set_xlabel(L("LLM label", "LLM 标签"))
    ax.set_ylabel(L("human label", "人工标签"))
    for i in range(2):
        for j in range(2):
            ax.text(j, i, f"{matrix[i, j]}", ha="center", va="center", fontsize=13,
                    color="white" if matrix[i, j] > matrix.max() / 2 else "#222222")
    ax.set_title(L(f"agreement {po:.1%}, Cohen's kappa = {kappa:.2f}", f"一致率 {po:.1%}，Cohen's kappa = {kappa:.2f}"))
    fig.colorbar(im, ax=ax, pad=0.02, shrink=0.9)
    annotate_source(
        ax,
        L(
            "Synthetic double-labelling (fixed seed). Low kappa means the LLM label cannot validate a trading hypothesis.",
            "合成双标签（固定 seed）。kappa 过低意味着 LLM 标签无法验证交易假设。",
        ),
    )
    return finalize(fig, spec)


@figure(
    "08",
    "ch08_ablation_oos",
    section="§7.2 Incremental predictive value",
    kind="project_output",
    title="项目 B 的 OOS ablation：market-only 与加入文本特征的增量",
    note="读取 projects/ml_llm_research/outputs/metrics.json；若未运行项目则跳过该图。",
    figsize=(9.8, 4.9),
)
def ablation_oos(spec):
    outputs = D.project_b_outputs()
    if outputs is None:
        raise RuntimeError("project B outputs missing; run projects/ml_llm_research first")
    metrics = json.loads((D.PROJECTS_DIR / "ml_llm_research" / "outputs" / "metrics.json").read_text(encoding="utf-8"))
    names = {
        "mean": L("mean forecast", "均值预测"),
        "market_ridge": L("market-only ridge", "仅市场特征 ridge"),
        "market_lexical_ridge": L("market + lexical text", "市场 + 词典文本"),
    }
    keys = [key for key in ("mean", "market_ridge", "market_lexical_ridge") if key in metrics]
    rank_ic = [metrics[key]["rank_ic"] for key in keys]
    net = [metrics[key]["average_net"] for key in keys]
    turnover = [metrics[key]["average_turnover"] for key in keys]

    fig, axes = new_figure(spec, 1, 3)
    palette = [COLORS["neutral"], COLORS["price"], COLORS["accent"]]
    for ax, values, title in (
        (axes[0], rank_ic, L("OOS rank IC", "OOS rank IC")),
        (axes[1], [v * 100 for v in net], L("OOS average net return (%)", "OOS 平均净收益（%）")),
        (axes[2], turnover, L("average turnover", "平均换手")),
    ):
        bars = ax.bar([names[key] for key in keys], values, color=palette[: len(keys)], alpha=0.9)
        for bar, value in zip(bars, values):
            offset = abs(max(values, default=1) - min(values, default=0)) * 0.02 or 0.01
            ax.text(bar.get_x() + bar.get_width() / 2, value + (offset if value >= 0 else -offset),
                    f"{value:.3f}", ha="center", va="bottom" if value >= 0 else "top", fontsize=8.5)
        ax.axhline(0, color="#333333", lw=0.9)
        ax.set_title(title, fontsize=10.5)
        ax.set_xticklabels([names[key] for key in keys], rotation=18, ha="right", fontsize=8.5)
    annotate_source(
        axes[2],
        L(
            "Project B deterministic outputs on synthetic filings; incremental value must also survive turnover and cost.",
            "项目 B 在合成 filing 上的确定性输出；增量价值还必须经得起换手与成本的检验。",
        ),
        y=-0.42,
    )
    fig.tight_layout()
    return finalize(fig, spec)
