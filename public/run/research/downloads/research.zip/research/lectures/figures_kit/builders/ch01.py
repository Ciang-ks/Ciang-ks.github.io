"""Figures for chapter 01 (markets, assets and tradable objects)."""

from __future__ import annotations

import numpy as np
from matplotlib.patches import Rectangle

from .. import data as D
from ..style import COLORS, L, annotate_source, figure, finalize, new_figure


@figure(
    "01",
    "ch01_candle_anatomy",
    section="§2.1 OHLCV 的含义",
    kind="concept",
    title="一根 K 线的四个价格：实体与上下影线",
    note="数值为手绘示意，不对应任何真实证券。",
    figsize=(8.6, 4.6),
)
def candle_anatomy(spec):
    fig, ax = new_figure(spec)
    candles = [
        # (open, high, low, close)
        (100.0, 104.0, 98.0, 103.0),
        (103.0, 105.5, 99.5, 100.5),
    ]
    for position, (open_, high, low, close) in enumerate(candles):
        up = close >= open_
        color = COLORS["positive"] if up else COLORS["negative"]
        body_low, body_high = min(open_, close), max(open_, close)
        ax.vlines(position, low, high, color=color, linewidth=1.8, zorder=2)
        ax.add_patch(
            Rectangle(
                (position - 0.24, body_low),
                0.48,
                max(body_high - body_low, 0.35),
                facecolor=color,
                edgecolor=color,
                alpha=0.88,
                zorder=3,
            )
        )

    def leader(text, xy, xytext, color=COLORS["neutral"]):
        ax.annotate(
            text,
            xy=xy,
            xytext=xytext,
            fontsize=8.5,
            color=color,
            arrowprops=dict(arrowstyle="-", color="#aaaaaa", lw=0.8),
        )

    # Left candle: labels on the left, high/low on the right.
    leader(L("open = 100", "开盘价 open = 100"), (-0.24, 100.0), (-1.62, 96.6))
    leader(L("close = 103", "收盘价 close = 103"), (-0.24, 103.0), (-1.62, 106.6))
    leader(L("high = 104", "最高价 high = 104"), (0.02, 104.0), (0.34, 104.6))
    leader(L("low = 98", "最低价 low = 98"), (0.02, 98.0), (0.34, 96.4))
    # Right candle: high/low/open/close on the right, vertically separated.
    leader(L("high = 105.5", "最高价 high = 105.5"), (1.02, 105.5), (1.42, 110.2))
    leader(L("open = 103", "开盘价 open = 103"), (1.24, 103.0), (1.42, 106.2))
    leader(L("close = 100.5", "收盘价 close = 100.5"), (1.24, 100.5), (1.42, 99.2))
    leader(L("low = 99.5", "最低价 low = 99.5"), (1.02, 99.5), (1.42, 94.6))

    ax.annotate(
        L("body = |close - open|", "实体 = |收盘价 - 开盘价|"),
        xy=(1.25, 101.75),
        xytext=(2.15, 102.6),
        fontsize=8.5,
        color=COLORS["price"],
        arrowprops=dict(arrowstyle="->", color=COLORS["price"], lw=0.9),
    )
    ax.annotate(
        L("upper wick: high above the body", "上影线：最高价高于实体"),
        xy=(1.0, 104.6),
        xytext=(2.15, 107.6),
        fontsize=8.5,
        color=COLORS["price"],
        arrowprops=dict(arrowstyle="->", color=COLORS["price"], lw=0.9),
    )
    ax.annotate(
        L("lower wick: low below the body", "下影线：最低价低于实体"),
        xy=(1.0, 99.9),
        xytext=(2.15, 92.4),
        fontsize=8.5,
        color=COLORS["price"],
        arrowprops=dict(arrowstyle="->", color=COLORS["price"], lw=0.9),
    )
    ax.text(0, 90.4, L("up day", "上涨日"), ha="center", fontsize=9.5, color=COLORS["neutral"])
    ax.text(1, 90.4, L("down day", "下跌日"), ha="center", fontsize=9.5, color=COLORS["neutral"])

    ax.set_xlim(-1.75, 3.7)
    ax.set_ylim(88, 112)
    ax.set_xticks([])
    ax.set_ylabel(L("price", "价格"))
    ax.set_title(L("Anatomy of one daily bar (OHLC)", "一根日线 K 线的四个价格（OHLC）"))
    annotate_source(
        ax,
        L(
            "Concept sketch: hand-written numbers, not a real security. Volume is a sixth column, see the next figure.",
            "概念示意图：手绘数值，不对应任何真实证券。成交量是第六列，见下一张真实日线图。",
        ),
    )
    return finalize(fig, spec)


@figure(
    "01",
    "ch01_real_sp500_bars",
    section="§2.1 OHLCV 的含义",
    kind="public_data",
    title="真实 S&P 500 日线 OHLCV（2020 年 2–4 月本地快照）",
    note="Yahoo Finance ^GSPC 本地快照，2020-02-24 至 2020-04-03；教学用途，不构成投资建议。",
    figsize=(10.4, 5.6),
)
def real_sp500_bars(spec):
    window = D.spx_window("2020-02-24", "2020-04-03")
    fig, (ax, axv) = new_figure(
        spec, 2, 1, sharex=True, height_ratios=[3, 1]
    )
    x = np.arange(len(window))
    up = window["close"] >= window["open"]
    ax.vlines(x, window["low"], window["high"], color="#555555", linewidth=0.8, zorder=2)
    ax.bar(
        x[up.to_numpy()],
        (window["close"] - window["open"])[up],
        bottom=window["open"][up],
        width=0.62,
        color=COLORS["positive"],
        alpha=0.85,
        zorder=3,
        label=L("close >= open", "收盘 ≥ 开盘"),
    )
    ax.bar(
        x[~up.to_numpy()],
        (window["close"] - window["open"])[~up],
        bottom=window["open"][~up],
        width=0.62,
        color=COLORS["negative"],
        alpha=0.85,
        zorder=3,
        label=L("close < open", "收盘 < 开盘"),
    )
    worst = window["log_return"].idxmin()
    worst_pos = int(window.index.get_loc(worst))
    ax.annotate(
        L(
            f"{worst.date()}: log return {window.loc[worst, 'log_return']:.1%}",
            f"{worst.date()}：对数收益 {window.loc[worst, 'log_return']:.1%}",
        ),
        (worst_pos, window.loc[worst, "low"]),
        xytext=(worst_pos + 1.5, window["low"].min() * 0.985),
        fontsize=8.5,
        color=COLORS["negative"],
        arrowprops=dict(arrowstyle="->", color=COLORS["negative"], lw=0.9),
    )
    ax.set_ylabel(L("S&P 500 index level", "S&P 500 指数点位"))
    ax.legend(loc="lower left", frameon=False, ncol=2)
    ax.set_title(
        L(
            "Real daily OHLC and volume, ^GSPC local snapshot",
            "真实日线 OHLC 与成交量：^GSPC 本地快照（2020-02-24 至 2020-04-03）",
        )
    )

    axv.bar(x, window["volume"] / 1e9, width=0.62, color=COLORS["muted"], edgecolor="none")
    axv.set_ylabel(L("volume (bn shares)", "成交量（十亿股）"))
    step = max(len(window) // 8, 1)
    axv.set_xticks(x[::step])
    axv.set_xticklabels([d.strftime("%m-%d") for d in window.index[::step]], rotation=0, fontsize=8)
    axv.set_xlim(-0.8, len(window) - 0.2)
    annotate_source(
        axv,
        L(
            "Public local snapshot: Yahoo Finance ^GSPC, sources/external/data/yahoo_sp500.csv. Teaching only.",
            "公开数据本地快照：Yahoo Finance ^GSPC，sources/external/data/yahoo_sp500.csv；仅用于教学。",
        ),
        y=-0.42,
    )
    fig.tight_layout()
    return finalize(fig, spec)


@figure(
    "01",
    "ch01_quote_ladder",
    section="§2.2 Bid、ask、mid 和 spread",
    kind="concept",
    title="买卖报价阶梯：mid、spread 与立即成交的半个价差成本",
    note="示例报价为手绘数值，用于说明字段含义。",
    figsize=(9.4, 4.8),
)
def quote_ladder(spec):
    fig, ax = new_figure(spec)
    asks = [(100.1, 2_000), (100.2, 1_400), (100.3, 900), (100.4, 500), (100.5, 300)]
    bids = [(99.9, 1_800), (99.8, 1_200), (99.7, 700), (99.6, 400), (99.5, 250)]
    max_size = max(size for _, size in asks + bids)

    for row, (price, size) in enumerate(asks):
        y = row + 0.9
        width = size / max_size
        ax.barh(y, width, color=COLORS["negative"], alpha=0.75, height=0.62)
        ax.text(width + 0.03, y, f"ask {price:g}  ×  {size:,}", va="center", fontsize=8.5)
    for row, (price, size) in enumerate(bids):
        y = -row - 0.9
        width = size / max_size
        ax.barh(y, -width, color=COLORS["positive"], alpha=0.75, height=0.62)
        ax.text(-width - 0.03, y, f"{size:,}  ×  bid {price:g}", va="center", ha="right", fontsize=8.5)

    ax.axhline(0, color="#333333", lw=1.0)
    ax.text(
        0.0,
        0.0,
        L(
            "mid = 100.00,  quoted spread = 0.20  (20 bp of mid)",
            "中间价 mid = 100.00，报价价差 spread = 0.20（相当于 mid 的 20 bp）",
        ),
        ha="center",
        va="center",
        fontsize=9,
        color=COLORS["price"],
        bbox=dict(boxstyle="round,pad=0.32", fc="white", ec=COLORS["price"], lw=0.8),
        zorder=5,
    )
    # Spread bracket between best bid and best ask on the right side.
    ax.annotate(
        "",
        xy=(1.28, 0.9),
        xytext=(1.28, -0.9),
        arrowprops=dict(arrowstyle="<->", color=COLORS["negative"], lw=1.1),
    )
    ax.text(
        1.33,
        0.0,
        L("spread\n0.20", "价差\n0.20"),
        fontsize=8.5,
        color=COLORS["negative"],
        va="center",
    )
    ax.text(
        0.01,
        0.99,
        L(
            "buy now at 100.1, sell now at 99.9:\n-0.20 before any price move",
            "立即买 100.1、立即卖 99.9：\n价格未变也先损失 0.20（半个价差 × 2）",
        ),
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=8.5,
        color=COLORS["negative"],
        bbox=dict(boxstyle="round,pad=0.32", fc="#fdecea", ec=COLORS["negative"], lw=0.7),
    )
    ax.set_ylim(-5.4, 5.6)
    ax.set_xlim(-1.62, 1.62)
    ax.set_yticks([])
    ax.set_xticks([])
    ax.set_title(
        L(
            "Five-level quote ladder: size at each price",
            "五档报价阶梯：每个价格上的挂单量（depth）",
        )
    )
    for spine in ax.spines.values():
        spine.set_visible(False)
    annotate_source(
        ax,
        L(
            "Concept sketch with hand-written quotes; real ladders change every millisecond.",
            "概念示意图：报价为手写数值；真实盘口每毫秒都在变化。",
        ),
        y=-0.04,
    )
    return finalize(fig, spec)


@figure(
    "01",
    "ch01_raw_vs_adjusted",
    section="§3.2 公司行动（corporate actions）",
    kind="synthetic",
    title="拆股与分红如何造成 raw close 与 adjusted close 的差别",
    note="由固定 seed 生成的合成价格，用于展示复权口径差异。",
    figsize=(9.6, 4.8),
)
def raw_vs_adjusted(spec):
    frame = D.synthetic_price(260, seed=5, drift=0.0006, vol=0.010, start=200.0)
    split_pos = 120
    dividend_pos = 200

    raw = frame["close"].to_numpy().copy()
    adjusted = raw.copy()
    adjusted[:split_pos] *= 0.5          # 2-for-1 split: history halved
    adjusted[:dividend_pos] *= 0.985      # cash dividend back-adjustment

    fig, ax = new_figure(spec)
    ax.plot(frame.index, raw, color=COLORS["neutral"], lw=1.4, label=L("raw close (as traded)", "原始收盘价 raw close"))
    ax.plot(frame.index, adjusted, color=COLORS["price"], lw=1.4, ls="--", label=L("adjusted close", "复权收盘价 adjusted close"))
    ax.axvline(frame.index[split_pos], color=COLORS["negative"], lw=1.0, ls=":")
    ax.axvline(frame.index[dividend_pos], color=COLORS["accent"], lw=1.0, ls=":")
    ax.text(
        frame.index[split_pos],
        ax.get_ylim()[1] * 0.98,
        L("  2-for-1 split", "  股票分割 2:1"),
        color=COLORS["negative"],
        fontsize=8.5,
        va="top",
    )
    ax.text(
        frame.index[dividend_pos],
        adjusted.min() * 1.02,
        L("  cash dividend", "  现金分红"),
        color=COLORS["accent"],
        fontsize=8.5,
    )
    ax.set_ylabel(L("price", "价格"))
    ax.set_title(
        L(
            "Same security, two price conventions",
            "同一证券的两种价格口径：不复权与复权",
        )
    )
    ax.legend(loc="upper left", frameon=False)
    annotate_source(
        ax,
        L(
            "Synthetic teaching series (fixed seed); corporate-action dates are invented for the example.",
            "确定性合成教学数据（固定 seed）；分割与分红日期为示例设定，非真实公司行动。",
        ),
    )
    return finalize(fig, spec)


@figure(
    "01",
    "ch01_bond_cashflows",
    section="§4.1 债券的现金流",
    kind="concept",
    title="息票债券现金流时间线与两种收益率下的价格",
    note="面值 100、年息票 4、5 年期；价格为公式计算结果，非市场报价。",
    figsize=(9.6, 4.8),
)
def bond_cashflows(spec):
    face, coupon, periods = 100.0, 4.0, 5
    fig, (ax, axp) = new_figure(spec, 2, 1, height_ratios=[2.2, 1], sharex=True)

    times = np.arange(1, periods + 1)
    cashflows = np.full(periods, coupon, dtype=float)
    cashflows[-1] += face
    ax.bar(times, cashflows, color=COLORS["price"], alpha=0.85, width=0.5)
    ax.bar([0], [0], color="none")
    ax.axhline(0, color="#333333", lw=0.8)
    for t, cf in zip(times, cashflows):
        ax.text(t, cf + 2.0, f"{cf:g}", ha="center", fontsize=8.5, color=COLORS["neutral"])
    ax.annotate(
        L(
            "today: pay price P\n(no cashflow at t = 0)",
            "今天：支付价格 P\n（t = 0 没有现金流）",
        ),
        xy=(0.0, 0.0),
        xytext=(0.35, face * 0.62),
        fontsize=8.5,
        color=COLORS["negative"],
        arrowprops=dict(arrowstyle="->", color=COLORS["negative"], lw=0.9),
    )
    ax.set_ylabel(L("cashflow", "现金流"))
    ax.set_title(
        L(
            "Coupon bond: coupons then principal at maturity",
            "息票债券现金流：每期息票 + 到期本金（面值 100，息票 4，5 期）",
        )
    )

    yields = np.linspace(0.005, 0.10, 200)
    prices = np.array([
        sum(cf / (1 + y) ** t for t, cf in zip(times, cashflows)) for y in yields
    ])
    axp.plot(yields * 100, prices, color=COLORS["price"], lw=1.6)
    offsets = {0.03: (0.4, 2.8), 0.05: (0.5, -5.4), 0.08: (-0.5, 4.4)}
    for y in (0.03, 0.05, 0.08):
        price = sum(cf / (1 + y) ** t for t, cf in zip(times, cashflows))
        dx, dy = offsets[y]
        ha = "left" if dx > 0 else "right"
        axp.plot([y * 100], [price], "o", color=COLORS["negative"], ms=5, zorder=4)
        axp.annotate(
            f"y = {y:.0%}  →  P = {price:.2f}",
            (y * 100, price),
            xytext=(y * 100 + dx, price + dy),
            fontsize=8.5,
            ha=ha,
            color=COLORS["negative"],
            arrowprops=dict(arrowstyle="-", color=COLORS["negative"], lw=0.7),
        )
    axp.set_xlabel(L("yield to maturity y (%)", "到期收益率 y（%）"))
    axp.set_ylabel(L("price P", "价格 P"))
    axp.set_xticks([1, 3, 5, 7, 9])
    axp.set_xticklabels([f"{v}%" for v in (1, 3, 5, 7, 9)])
    axp.set_xlim(0.5, 10.0)
    annotate_source(
        axp,
        L(
            "Prices computed from the discounting formula in §4.1; not quoted market prices.",
            "价格由 §4.1 的贴现公式计算得到，不是市场报价。",
        ),
        y=-0.52,
    )
    fig.tight_layout()
    return finalize(fig, spec)


@figure(
    "01",
    "ch01_term_structure",
    section="§6.2 Contango 与 backwardation 的例子",
    kind="concept",
    title="Contango 与 backwardation 的期货曲线及展期收益方向",
    note="曲线为手绘示例点位，用于说明期限结构与展期成本方向。",
    figsize=(9.6, 4.6),
)
def term_structure(spec):
    fig, ax = new_figure(spec)
    months = np.arange(0, 13)
    spot = 100.0
    contango = spot * (1 + 0.004) ** months
    backwardation = spot * (1 - 0.0035) ** months

    ax.plot(months, contango, "o-", color=COLORS["negative"], lw=1.8, ms=4.5, label=L("contango (upward)", "contango（正向市场，远月更贵）"))
    ax.plot(months, backwardation, "s-", color=COLORS["positive"], lw=1.8, ms=4.5, label=L("backwardation (downward)", "backwardation（反向市场，远月更便宜）"))
    ax.axhline(spot, color=COLORS["neutral"], lw=1.0, ls=":")
    ax.text(12.1, spot + 0.18, L("spot = 100", "现货 = 100"), fontsize=8.5, color=COLORS["neutral"], ha="right")

    ax.annotate(
        L(
            "long futures in contango:\nroll from cheap near month to dear far month\n→ negative roll yield",
            "contango 中做多期货：\n从便宜近月换到更贵远月\n→ 展期收益为负",
        ),
        (6, contango[6]),
        xytext=(0.8, 104.1),
        fontsize=8.5,
        color=COLORS["negative"],
        arrowprops=dict(arrowstyle="->", color=COLORS["negative"], lw=0.9),
    )
    ax.annotate(
        L(
            "long futures in backwardation:\nroll from dear near month to cheap far month\n→ positive roll yield",
            "backwardation 中做多期货：\n从贵的近月换到便宜的远月\n→ 展期收益为正",
        ),
        (6, backwardation[6]),
        xytext=(0.8, 96.1),
        fontsize=8.5,
        color=COLORS["positive"],
        arrowprops=dict(arrowstyle="->", color=COLORS["positive"], lw=0.9),
    )
    ax.set_xlabel(L("months to maturity", "距到期月数"))
    ax.set_ylabel(L("futures price", "期货价格"))
    ax.set_title(
        L(
            "Two term structures, two roll-yield signs",
            "两种期限结构，两种展期收益方向",
        )
    )
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.13), ncol=2, frameon=False, fontsize=8.5)
    annotate_source(
        ax,
        L(
            "Concept sketch: illustrative curve levels, not a quoted futures curve.",
            "概念示意图：曲线点位为示例，不是任何真实期货报价。",
        ),
        y=-0.32,
    )
    return finalize(fig, spec)


@figure(
    "01",
    "ch01_option_payoffs",
    section="§8.1 到期收益",
    kind="concept",
    title="期权到期 payoff 与含权利金的净利润：四种基本头寸",
    note="执行价 K=100，call 权利金 6、put 权利金 4；数值为公式计算示例。",
    figsize=(10.2, 6.4),
)
def option_payoffs(spec):
    fig, axes = new_figure(spec, 2, 2, sharex=True, sharey=True)
    S = np.linspace(60, 140, 400)
    K, call_premium, put_premium = 100.0, 6.0, 4.0
    panels = [
        (axes[0, 0], np.maximum(S - K, 0), np.maximum(S - K, 0) - call_premium, L("long call", "买入看涨 long call")),
        (axes[0, 1], np.maximum(K - S, 0), np.maximum(K - S, 0) - put_premium, L("long put", "买入看跌 long put")),
        (axes[1, 0], -np.maximum(S - K, 0), call_premium - np.maximum(S - K, 0), L("short call", "卖出看涨 short call")),
        (axes[1, 1], -np.maximum(K - S, 0), put_premium - np.maximum(K - S, 0), L("short put", "卖出看跌 short put")),
    ]
    for ax, payoff, profit, title in panels:
        ax.plot(S, payoff, color=COLORS["neutral"], lw=1.5, label=L("payoff at expiry", "到期 payoff"))
        ax.plot(S, profit, color=COLORS["price"], lw=1.8, ls="--", label=L("profit after premium", "扣除权利金后的净利润"))
        ax.axhline(0, color="#333333", lw=0.8)
        ax.axvline(K, color="#bbbbbb", lw=0.8, ls=":")
        ax.fill_between(S, 0, profit, where=profit >= 0, color=COLORS["positive"], alpha=0.12)
        ax.fill_between(S, 0, profit, where=profit < 0, color=COLORS["negative"], alpha=0.12)
        ax.set_title(f"{title}  (K = {K:g})", fontsize=10.5)
        ax.set_xlabel(L("spot at expiry S_T", "到期标的价格 S_T"))
    axes[0, 0].set_ylabel(L("value", "价值"))
    axes[1, 0].set_ylabel(L("value", "价值"))
    axes[0, 0].legend(loc="upper left", frameon=False, fontsize=8)
    annotate_source(
        axes[1, 1],
        L(
            "Payoffs from the §8.1 formulas; premiums are example numbers, not market quotes.",
            "曲线由 §8.1 公式计算；权利金为示例数值，不是市场报价。",
        ),
        y=-0.42,
    )
    fig.tight_layout()
    return finalize(fig, spec)
