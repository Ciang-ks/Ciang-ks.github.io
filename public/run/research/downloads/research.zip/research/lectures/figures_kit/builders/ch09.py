"""Figures for chapter 09 (end-to-end research and interview communication)."""

from __future__ import annotations

from matplotlib.patches import FancyBboxPatch

from ..style import COLORS, L, annotate_source, figure, finalize, new_figure


@figure(
    "09",
    "ch09_pipeline_layers",
    section="§1.1 从问题到部署候选",
    kind="concept",
    title="研究管线的六层与每层的检查门",
    note="层与检查项对应两个项目的目录结构；箭头表示显式输入输出，不允许隐藏全局状态。",
    figsize=(11.0, 5.4),
)
def pipeline_layers(spec):
    fig, ax = new_figure(spec)
    layers = [
        (L("raw data + data contract", "原始数据 + 数据契约"), L("fields, units, timestamps, as-of rules", "字段、单位、时间戳、as-of 规则"), COLORS["price"]),
        (L("features", "特征"), L("only information visible at time t", "只使用 t 时刻可见的信息"), COLORS["accent"]),
        (L("signal / model", "信号 / 模型"), L("baseline first, then increments", "先 baseline，再谈增量"), COLORS["neutral"]),
        (L("portfolio / weights", "组合 / 权重"), L("caps, turnover, neutrality constraints", "上限、换手、中性化约束"), COLORS["positive"]),
        (L("execution + cost", "执行 + 成本"), L("spread, impact, borrow, capacity", "价差、冲击、借券、容量"), COLORS["negative"]),
        (L("metrics / memo", "指标 / 研究 memo"), L("benchmark, failure modes, next steps", "benchmark、失败模式、下一步"), COLORS["price"]),
    ]
    checks = [
        L("no look-ahead: shift audited", "无前视：shift 已审计"),
        L("point-in-time joins only", "只做 point-in-time 连接"),
        L("walk-forward / purged splits", "walk-forward / purged 切分"),
        L("weights sum & caps tested", "权重和与上限有测试"),
        L("cost monotonicity invariant", "成本单调性不变量"),
        L("manifest: seed, hashes, config", "manifest：seed、哈希、配置"),
    ]
    box_height = 0.62
    for i, ((title, subtitle, color), check) in enumerate(zip(layers, checks)):
        y = -i
        ax.add_patch(
            FancyBboxPatch(
                (0.0, y - box_height / 2), 4.2, box_height,
                boxstyle="round,pad=0.02,rounding_size=0.08",
                facecolor=color, alpha=0.85, edgecolor="white",
            )
        )
        ax.text(0.15, y + 0.12, title, fontsize=10, color="white", va="center")
        ax.text(0.15, y - 0.16, subtitle, fontsize=8, color="white", va="center", alpha=0.92)
        ax.text(4.5, y, "→  " + check, fontsize=8.5, color=COLORS["neutral"], va="center")
        if i < len(layers) - 1:
            ax.annotate("", xy=(2.1, y - 1 + box_height / 2 + 0.02), xytext=(2.1, y - box_height / 2 - 0.02),
                        arrowprops=dict(arrowstyle="-|>", color=COLORS["neutral"], lw=1.2))
    ax.set_xlim(-0.3, 9.4)
    ax.set_ylim(-len(layers) + 0.2, 0.7)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.set_title(
        L(
            "Six layers, one check gate each",
            "六层结构，每层一个检查门：任何一层不过关就不进入下一层",
        )
    )
    annotate_source(
        ax,
        L(
            "Concept sketch mirroring the two projects' src/ layout and tests.",
            "概念示意图，与两个项目的 src/ 分层和测试一一对应。",
        ),
        y=-0.02,
    )
    return finalize(fig, spec)


@figure(
    "09",
    "ch09_stage_gates",
    section="§补充二：从研究候选到生产候选的 Stage Gate",
    kind="concept",
    title="Stage gate 漏斗：100 个想法到最后 1 个生产候选",
    note="数量为示意比例，用于说明筛选强度；每个 gate 的通过标准写在右侧。",
    figsize=(10.6, 5.0),
)
def stage_gates(spec):
    stages = [
        (100, L("ideas / hypotheses", "想法 / 假设"), L("mechanism stated in one sentence", "一句话写清经济机制")),
        (30, L("in-sample signal", "样本内信号"), L("IC, decay, breadth checked", "IC、衰减、breadth 检查")),
        (12, L("out-of-sample validation", "样本外验证"), L("purged walk-forward, no re-tuning", "purged walk-forward，不再调参")),
        (5, L("cost & capacity pass", "成本与容量通过"), L("net of realistic costs, capacity ok", "扣除真实成本后仍成立")),
        (2, L("paper / shadow trading", "纸面 / 影子交易"), L("live data, no capital at risk", "实时数据，不占用资金")),
        (1, L("production candidate", "生产候选"), L("monitoring, rollback, owner", "监控、回滚、负责人")),
    ]
    fig, ax = new_figure(spec)
    max_value = stages[0][0]
    for i, (value, name, criterion) in enumerate(stages):
        width = value / max_value * 6.0
        left = (6.0 - width) / 2
        ax.barh(-i, width, left=left, height=0.62, color=COLORS["price"], alpha=0.55 + 0.07 * i, edgecolor="white")
        ax.text(6.05, -i, f"{value}", ha="right", va="center", fontsize=10, color=COLORS["price"])
        ax.text(-0.2, -i, name, ha="right", va="center", fontsize=9.5, color=COLORS["neutral"])
        ax.text(6.3, -i, "gate: " + criterion, ha="left", va="center", fontsize=8.5, color=COLORS["neutral"])
    ax.set_xlim(-4.6, 11.2)
    ax.set_ylim(-len(stages) + 0.4, 0.7)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.set_title(
        L(
            "Most ideas should die before capital is at risk",
            "大多数想法应该在占用资金之前被淘汰",
        )
    )
    annotate_source(
        ax,
        L(
            "Illustrative proportions, not a firm's actual funnel; the gates mirror the chapter's stage-gate list.",
            "比例仅为示意，不是任何公司的真实漏斗；gate 标准对应本章的 stage-gate 清单。",
        ),
        y=-0.02,
    )
    return finalize(fig, spec)
