"""Figures for financial econometrics and stochastic calculus."""
from __future__ import annotations

import numpy as np
from scipy import stats

from ..style import COLORS, L, annotate_source, figure, finalize, new_figure


def order_flow(seed=3107, n=1600):
    """The chapter's disclosed order-flow mechanism; all changes are in bp."""
    rng = np.random.default_rng(seed)
    demand, innovation, variance = np.zeros(n), np.zeros(n), np.ones(n)
    for t in range(1, n):
        demand[t] = 0.65 * demand[t - 1] + rng.normal()
        variance[t] = 0.08 + 0.12 * innovation[t - 1] ** 2 + 0.80 * variance[t - 1]
        innovation[t] = np.sqrt(variance[t]) * rng.normal()
    instrument = rng.normal(size=n)
    flow = 0.8 * instrument + 0.8 * demand + 0.4 * rng.normal(size=n)
    change = 0.6 * flow + 0.9 * demand + innovation
    return flow, change, instrument, innovation, variance


@figure("03", "ch03_endogeneity_iv", section='§2. 工具变量：只使用订单流中能解释清楚的那一部分', kind="synthetic",
        title="同一订单流样本中的 OLS 偏差与 IV 识别",
        note="固定种子；结构斜率为 0.6；工具有效性由生成机制保证。", figsize=(10.6, 4.8))
def endogeneity_iv(spec):
    q, y, z, _, _ = order_flow()
    slope, intercept = np.polyfit(q, y, 1)
    fig, (ax, axr) = new_figure(spec, 1, 2)
    ax.scatter(q, y, s=8, alpha=0.22, color=COLORS["price"], edgecolors="none")
    grid = np.linspace(q.min(), q.max(), 100)
    ax.plot(grid, intercept + slope * grid, color=COLORS["negative"], label=L(f"OLS slope = {slope:.2f}", f"OLS 斜率 = {slope:.2f}"))
    ax.plot(grid, 0.6 * grid, color=COLORS["price"], ls="--", label=L("structural slope = 0.6", "结构斜率 = 0.6"))
    ax.set(xlabel=L("signed order flow (fixed units)", "净买入量（固定单位）"), ylabel=L("price change (bp)", "价格变动（基点）"), title=L("Demand confounds the regression", "需求混入回归关系"))
    ax.legend(frameon=False)
    estimates = []
    for seed in range(400, 650):
        qi, yi, zi, _, _ = order_flow(seed, n=500)
        estimates.append((np.cov(qi, yi)[0, 1] / np.var(qi, ddof=1),
                          np.cov(zi, yi)[0, 1] / np.cov(zi, qi)[0, 1]))
    estimates = np.array(estimates)
    for j, label, color in [(0, "OLS", COLORS["negative"]), (1, "IV", COLORS["price"])]:
        axr.hist(estimates[:, j], bins=25, histtype="step", lw=1.8, density=True, label=label, color=color)
    axr.axvline(0.6, color=COLORS["neutral"], ls="--")
    axr.set(xlabel=L("estimated impact coefficient", "估计冲击系数"), ylabel=L("density", "密度"), title=L("250 repeated samples", "250 次重复样本"))
    axr.legend(frameon=False)
    annotate_source(ax, L("Synthetic order-flow mechanism; instruments are valid by construction, not by a statistical test.", "合成订单流机制；工具有效性由构造保证，不能据图推断现实工具有效。"))
    return finalize(fig, spec)


@figure("03", "ch03_hac_overlap", section='§3. 金融时序的误差：系数算对了，精度仍可能算错', kind="synthetic",
        title="重叠标签的相关性与标准误", note="独立日收益的五日滚动和；HAC 带宽为 8。", figsize=(10.0, 4.6))
def hac_overlap(spec):
    rng = np.random.default_rng(333)
    daily = rng.normal(size=3000)
    labels = np.convolve(daily, np.ones(5), mode="valid")
    demeaned = labels - labels.mean()
    lags = np.arange(11)
    corr = [1.0] + [np.corrcoef(labels[k:], labels[:-k])[0, 1] for k in lags[1:]]
    n = len(labels)
    iid = np.sqrt(np.dot(demeaned, demeaned)) / n
    long_sum = np.dot(demeaned, demeaned)
    for k in range(1, 9):
        long_sum += 2 * (1 - k / 9) * np.dot(demeaned[k:], demeaned[:-k])
    hac = np.sqrt(long_sum) / n
    fig, (ax, axr) = new_figure(spec, 1, 2)
    ax.bar(lags, corr, color=COLORS["price"])
    ax.set(xlabel=L("lag (days)", "滞后天数"), ylabel=L("sample autocorrelation", "样本自相关"), title=L("Five-day labels share four daily returns", "五日标签共享四日收益"))
    axr.bar(["iid", "HAC"], [iid, hac], color=[COLORS["negative"], COLORS["price"]])
    axr.set(ylabel=L("standard error of label mean", "标签均值标准误"), title=L("Dependence changes precision", "依赖改变精度估计"))
    annotate_source(ax, L("Fixed-seed iid daily noise, aggregated into overlapping five-day labels.", "固定种子的独立日噪声，形成重叠五日标签。"))
    return finalize(fig, spec)


@figure("03", "ch03_stationarity", section='§4. 平稳性、单位根与协整：不要让价格水平替你制造关系', kind="synthetic",
        title="独立随机游走与平稳价差", note="价差为系数 0.8 的自回归过程；未计成本。", figsize=(10.4, 4.6))
def stationarity(spec):
    rng = np.random.default_rng(59)
    paths = rng.normal(size=(600, 2)).cumsum(axis=0)
    spread = np.zeros(600)
    for t in range(1, len(spread)):
        spread[t] = 0.8 * spread[t - 1] + rng.normal()
    fig, (ax, axr) = new_figure(spec, 1, 2)
    ax.plot(paths[:, 0], label="A", color=COLORS["price"])
    ax.plot(paths[:, 1], label="B", color=COLORS["negative"])
    ax.legend(frameon=False)
    ax.set(xlabel=L("time", "时间"), ylabel=L("cumulative noise", "累积噪声"), title=L("Unrelated random walks", "无经济联系的随机游走"))
    axr.plot(spread, color=COLORS["price"], lw=1)
    axr.axhline(0, color=COLORS["neutral"], ls="--")
    axr.set(xlabel=L("time", "时间"), ylabel=L("spread", "价差"), title=L("A stationary spread by construction", "按构造平稳的价差"))
    annotate_source(ax, L("Synthetic processes; a plot is not a unit-root or cointegration test.", "合成过程；图形不替代单位根或协整检验。"))
    return finalize(fig, spec)


@figure("03", "ch03_conditional_vol", section='§5. 从 AR 到条件波动：分别预测方向和风险', kind="synthetic",
        title="GARCH 创新与条件波动", note="参数 omega=0.08、alpha=0.12、delta=0.80，与主线相同。", figsize=(10.0, 5.0))
def conditional_vol(spec):
    _, _, _, innovation, variance = order_flow()
    fig, (ax, axr) = new_figure(spec, 2, 1, sharex=True)
    ax.plot(innovation, lw=0.65, color=COLORS["negative"])
    ax.set(ylabel=L("innovation (bp)", "创新（基点）"), title=L("Innovations are noisy; conditional risk persists", "创新随机起伏，风险状态持续"))
    axr.plot(np.sqrt(variance), color=COLORS["price"], lw=1)
    axr.set(xlabel=L("day", "日期序号"), ylabel=L("conditional sd (bp)", "条件标准差（基点）"))
    annotate_source(axr, L("Synthetic GARCH innovations; this is not the volatility of total price changes.", "合成 GARCH 创新；不是总价格变动的条件波动。"))
    return finalize(fig, spec)


@figure("03", "ch03_ito_variation", section='§6. 随机微积分：为什么对数增长少了半个方差', kind="synthetic",
        title="简单收益与对数收益之差的二阶极限", note="同一布朗路径；年化 sigma=20%，期限一年。", figsize=(9.4, 4.6))
def ito_variation(spec):
    mu, sigma, steps = 0.08, 0.2, 8192
    rng = np.random.default_rng(97)
    dw = rng.normal(size=steps) / np.sqrt(steps)
    counts = np.array([32, 128, 512, 2048, 8192])
    differences = []
    for count in counts:
        increments = (mu - sigma ** 2 / 2) / count + sigma * dw.reshape(count, -1).sum(axis=1)
        differences.append((np.expm1(increments) - increments).sum())
    fig, ax = new_figure(spec)
    ax.plot(counts, differences, "o-", color=COLORS["price"], label=L("sum simple minus log", "简单收益之和减对数收益之和"))
    ax.axhline(sigma ** 2 / 2, color=COLORS["neutral"], ls="--", label=L("half integrated variance", "半个积分方差"))
    ax.set_xscale("log", base=2)
    ax.set_xticks(counts, [str(v) for v in counts])
    ax.set(xlabel=L("intervals in one year", "一年内分段数量"), ylabel=L("difference (return units)", "差值（小数收益）"), title=L("The second-order term survives finer sampling", "网格变细仍留下二阶项"))
    ax.legend(frameon=False)
    annotate_source(ax, L("Fixed-seed GBM teaching path; not calibrated to the order-flow sample.", "固定种子的 GBM 教学路径；未用订单流样本拟合。"))
    return finalize(fig, spec)


@figure("03", "ch03_multiple_testing", section='§8. 多重尝试与不确定性：模型之外还有研究者', kind="synthetic",
        title="20 个零信号策略中的最大绝对 t 值", note="4000 次模拟，每条策略 252 个独立标准正态收益。", figsize=(9.8, 4.8))
def multiple_testing(spec):
    rng = np.random.default_rng(404)
    best = []
    for _ in range(4000):
        samples = rng.normal(size=(20, 252))
        t = samples.mean(axis=1) / (samples.std(axis=1, ddof=1) / np.sqrt(252))
        best.append(np.abs(t).max())
    fig, ax = new_figure(spec)
    grid = np.linspace(0, 6, 200)
    ax.plot(grid, 2 * stats.t.pdf(grid, 251), color=COLORS["price"], label=L("one pre-specified null strategy", "一个预先指定的零信号策略"))
    ax.hist(best, bins=60, density=True, color=COLORS["negative"], alpha=0.45, label=L("best of 20 null strategies", "20 个零信号策略中的最佳值"))
    ax.axvline(2, color=COLORS["neutral"], ls=":")
    ax.set(xlabel=L("absolute t statistic", "绝对 t 统计量"), ylabel=L("density", "密度"), title=L("Selection creates apparently significant results", "筛选会制造表面显著结果"))
    ax.legend(frameon=False)
    annotate_source(ax, L("Fixed-seed null simulation; all strategies have zero expected return.", "固定种子的零假设模拟；所有策略期望收益为零。"))
    return finalize(fig, spec)
