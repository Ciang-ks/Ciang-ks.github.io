"""Figures for chapter 03 (probability, inference and regression)."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats

from .. import data as D
from ..style import COLORS, L, annotate_source, figure, finalize, new_figure, plain_log_ticks


@figure(
    "03",
    "ch03_fat_tails",
    section="§3.2 Normal 与 Student-t",
    kind="public_data",
    title="真实日收益的尾部比正态厚：对数刻度下的直方图对照",
    note="Yahoo Finance ^GSPC 本地快照；表中计数为样本内事实，不是未来概率。",
    figsize=(10.0, 5.2),
)
def fat_tails(spec):
    returns = D.real_market()["spx_log_return"].dropna().loc["2010":]
    mu, sd = returns.mean(), returns.std(ddof=1)
    grid = np.linspace(returns.min(), returns.max(), 400)

    fig, ax = new_figure(spec)
    ax.hist(returns, bins=140, density=True, histtype="step", linewidth=1.4, color="#7f9db9", label=L("real daily returns", "真实日收益"))
    ax.plot(grid, stats.norm.pdf(grid, mu, sd), color=COLORS["price"], lw=1.8, label=L("normal with same mean/sd", "同均值同方差的正态"))
    df_fit = 3.0
    scale = sd * np.sqrt((df_fit - 2) / df_fit)
    ax.plot(grid, stats.t.pdf(grid, df_fit, loc=mu, scale=scale), color=COLORS["negative"], lw=1.6, ls="--",
            label=L(f"Student-t (df = {df_fit:g}) with same sd", f"同方差的 Student-t（df = {df_fit:g}）"))
    ax.set_yscale("log")
    ax.set_ylim(bottom=1e-4)
    plain_log_ticks(ax, "y")
    ax.set_xlabel(L("daily log return", "日对数收益"))
    ax.set_ylabel(L("density (log scale)", "密度（对数刻度）"))
    ax.set_title(
        L(
            "Real return tails vs normal and Student-t",
            "真实收益尾部 vs 正态与 Student-t：对数刻度下差异被放大",
        )
    )
    ax.legend(loc="upper left", frameon=False, fontsize=8.5)

    observed = ((returns - mu).abs() > 3 * sd).mean()
    expected = 2 * stats.norm.sf(3)
    ax.text(
        0.98,
        0.97,
        L(
            f"P(|r - mean| > 3 sd): real {observed:.3%}\nnormal expectation {expected:.3%}\nratio {observed / expected:.1f}x",
            f"P(|r - mean| > 3σ)：真实 {observed:.3%}\n正态理论值 {expected:.3%}\n倍数 {observed / expected:.1f}×",
        ),
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=8.5,
        color=COLORS["neutral"],
        bbox=dict(boxstyle="round,pad=0.35", fc="white", ec="#bbbbbb", lw=0.7),
    )
    annotate_source(
        ax,
        L(
            "Public local snapshot: Yahoo Finance ^GSPC daily log returns, 2010 onward.",
            "公开数据本地快照：Yahoo Finance ^GSPC 日对数收益（2010 起）。",
        ),
    )
    return finalize(fig, spec)


@figure(
    "03",
    "ch03_lln_clt",
    section="§4.2 中心极限定理（CLT）",
    kind="synthetic",
    title="LLN：样本均值收敛到期望；CLT：标准化后的均值分布趋近正态",
    note="固定 seed 的合成日收益样本；左图带 ±2 标准误参考带，右图为 2000 次重复抽样。",
    figsize=(10.6, 4.8),
)
def lln_clt(spec):
    rng = np.random.default_rng(101)
    mu, sd = 0.0005, 0.012
    sample = mu + sd * (rng.exponential(size=2000) - 1)
    running = pd.Series(sample).expanding().mean()
    n = np.arange(1, len(sample) + 1)

    fig, (ax, axh) = new_figure(spec, 1, 2, width_ratios=[1.25, 1])
    ax.plot(n, running * 100, color=COLORS["price"], lw=1.3, label=L("running sample mean", "滚动样本均值"))
    ax.axhline(mu * 100, color=COLORS["neutral"], lw=1.0, ls=":", label=L("true mean μ", "真实均值 μ"))
    band = 2 * sd / np.sqrt(n) * 100
    ax.fill_between(n, (mu * 100 - band), (mu * 100 + band), color=COLORS["band"], alpha=0.9, label=L("±2σ/√n band", "±2 标准误参考带"))
    ax.set_xscale("log")
    plain_log_ticks(ax, "x")
    ax.set_xlabel(L("sample size n (log scale)", "样本量 n（对数刻度）"))
    ax.set_ylabel(L("mean (%)", "均值（%）"))
    ax.set_title(L("LLN: the mean settles down", "大数定律：样本均值逐渐稳定"))
    ax.legend(loc="upper right", frameon=False, fontsize=8.5)

    means = (mu + sd * (rng.exponential(size=(2000, 200)) - 1)).mean(axis=1)
    standardized = (means - mu) / (sd / np.sqrt(200))
    axh.hist(standardized, bins=40, density=True, color=COLORS["muted"], edgecolor="none", label=L("2000 standardized means", "2000 个标准化样本均值"))
    grid = np.linspace(-4, 4, 200)
    axh.plot(grid, stats.norm.pdf(grid), color=COLORS["negative"], lw=1.8, label=L("standard normal", "标准正态密度"))
    axh.set_xlabel(L("(mean - μ) / (σ/√n)", "（样本均值 − μ）/（σ/√n）"))
    axh.set_ylabel(L("density", "密度"))
    axh.set_title(L("CLT: the shape becomes normal", "中心极限定理：形状趋近正态"))
    axh.legend(loc="upper left", frameon=False, fontsize=8.5)
    annotate_source(
        axh,
        L(
            "Shifted exponential iid samples; the band is pointwise, not a simultaneous guarantee.",
            "合成 iid 平移指数样本；参考带不保证整条均值路径都在带内。",
        ),
        y=-0.24,
    )
    fig.get_layout_engine().execute(fig)
    return finalize(fig, spec)


@figure(
    "03",
    "ch03_ci_coverage",
    section="§5.1 置信区间的正确解释",
    kind="synthetic",
    title="95% 置信区间的含义：100 次重复里约 95 次覆盖真值",
    note="固定 seed 的 100 次独立抽样，总体均值为 0；未覆盖的区间标红。",
    figsize=(9.6, 5.4),
)
def ci_coverage(spec):
    rng = np.random.default_rng(202)
    mu, sd, n = 0.0, 1.0, 40
    reps = 100
    fig, ax = new_figure(spec)
    covered = 0
    for i in range(reps):
        sample = rng.normal(mu, sd, n)
        mean = sample.mean()
        half = stats.t.ppf(0.975, n - 1) * sample.std(ddof=1) / np.sqrt(n)
        hit = (mean - half) <= mu <= (mean + half)
        covered += int(hit)
        color = COLORS["positive"] if hit else COLORS["negative"]
        ax.hlines(i, mean - half, mean + half, color=color, lw=1.4, alpha=0.85)
        ax.plot([mean], [i], ".", color=color, ms=3)
    ax.axvline(mu, color=COLORS["neutral"], lw=1.2, ls=":")
    ax.text(mu + 0.02, reps * 0.985, L("true μ = 0", "总体均值为 0"), fontsize=9, color=COLORS["neutral"], va="top")
    ax.set_xlabel(L("95% confidence interval for the mean", "均值的 95% 置信区间"))
    ax.set_ylabel(L("repeated sample", "重复抽样编号"))
    ax.set_yticks([])
    ax.set_title(
        L(
            f"{covered} of {reps} intervals cover μ",
            f"{reps} 次重复中 {covered} 次覆盖真值 μ",
        )
    )
    annotate_source(
        ax,
        L(
            "Synthetic repeated sampling (fixed seed). The 95% refers to the procedure, not to one realized interval.",
            "合成重复抽样（固定 seed）。95% 描述的是方法的长期覆盖率，不是某一条已算出的区间。",
        ),
    )
    return finalize(fig, spec)


@figure(
    "03",
    "ch03_pvalue_null",
    section="§5.2 Null、alternative 和 p-value",
    kind="synthetic",
    title="p-value 的几何含义：零假设下比观测更极端的概率",
    note="零假设为均值 0、标准误 0.004；观测统计量 0.0078，双尾 p 由正态尾部面积计算。",
    figsize=(9.8, 4.8),
)
def pvalue_null(spec):
    se = 0.004
    observed = 0.0078
    grid = np.linspace(-4.5 * se, 4.5 * se, 600)
    pdf = stats.norm.pdf(grid, 0, se) / 100

    fig, ax = new_figure(spec)
    ax.plot(grid * 100, pdf, color=COLORS["price"], lw=1.8, label=L(r"null distribution $N(0,\mathrm{SE}^2)$", r"$H_0: N(0,\mathrm{SE}^2)$"))
    tail = (grid >= observed) | (grid <= -observed)
    ax.fill_between(grid * 100, 0, pdf, where=tail, color=COLORS["negative"], alpha=0.45, label=L("two-sided p-value area", "双尾 p-value 面积"))
    ax.axvline(observed * 100, color=COLORS["negative"], lw=1.4)
    ax.axvline(-observed * 100, color=COLORS["negative"], lw=1.4)
    p_value = 2 * stats.norm.sf(observed / se)
    ax.text(
        observed * 100 + 0.12,
        pdf.max() * 0.72,
        L(
            f"observed statistic = {observed * 100:.2f}%\nz = {observed / se:.2f}, two-sided p = {p_value:.4f}",
            f"观测统计量 = {observed * 100:.2f}%\nz = {observed / se:.2f}，双尾 p = {p_value:.4f}",
        ),
        fontsize=9,
        color=COLORS["negative"],
    )
    ax.text(
        0.0,
        pdf.max() * 0.35,
        L(
            "if H0 is true, values this extreme\nhappen with probability p",
            "若 H0 为真，出现这么极端的值\n的概率就是 p",
        ),
        ha="center",
        fontsize=8.5,
        color=COLORS["neutral"],
    )
    ax.set_xlabel(L("estimated mean (%)", "估计均值（%）"))
    ax.set_ylabel(L("density under H0", "H0 下的密度"))
    ax.set_title(L("What a p-value measures", "p-value 度量的到底是什么"))
    ax.legend(loc="upper left", frameon=False, fontsize=8.5)
    annotate_source(
        ax,
        L(
            "Numbers chosen for teaching; p is a tail probability under H0, not the probability that H0 is true.",
            "数值为教学设定；p 是 H0 下的尾部概率，不是 H0 为真的概率。",
        ),
    )
    return finalize(fig, spec)


@figure(
    "03",
    "ch03_ols_residuals",
    section="§6.3 R² 和残差",
    kind="synthetic",
    title="一元 OLS：拟合线、残差茎与残差—拟合值检查图",
    note="固定 seed 合成样本；R² 与残差统计由样本计算，用于说明解释与预测的区别。",
    figsize=(10.6, 4.8),
)
def ols_residuals(spec):
    rng = np.random.default_rng(303)
    n = 220
    x = rng.normal(0, 1, n)
    y = 0.6 * x + rng.normal(0, 0.9, n)
    slope, intercept = np.polyfit(x, y, 1)
    fitted = intercept + slope * x
    resid = y - fitted
    r2 = 1 - resid.var(ddof=1) / y.var(ddof=1)

    fig, (ax, axr) = new_figure(spec, 1, 2, width_ratios=[1.15, 1])
    ax.scatter(x, y, s=10, alpha=0.4, color=COLORS["price"], edgecolor="none", label=L("observations", "观测点"))
    grid = np.linspace(x.min(), x.max(), 50)
    ax.plot(grid, intercept + slope * grid, color=COLORS["negative"], lw=1.8, label=L(f"OLS fit: y = {intercept:.2f} + {slope:.2f} x", f"OLS 拟合：y = {intercept:.2f} + {slope:.2f} x"))
    for xi, yi, fi in list(zip(x, y, fitted))[::14]:
        ax.vlines(xi, fi, yi, color=COLORS["neutral"], lw=0.8, alpha=0.7)
    ax.set_xlabel(L("feature x", "特征 x"))
    ax.set_ylabel(L("outcome y", "结果 y"))
    ax.set_title(L(f"residual stems and R² = {r2:.2f}", f"残差茎与 R² = {r2:.2f}"))
    ax.legend(loc="upper left", frameon=False, fontsize=8.5)

    axr.scatter(fitted, resid, s=10, alpha=0.4, color=COLORS["accent"], edgecolor="none")
    axr.axhline(0, color=COLORS["neutral"], lw=1.0)
    order = np.argsort(fitted)
    smooth = pd.Series(resid[order]).rolling(30, center=True, min_periods=10).mean()
    axr.plot(fitted[order], smooth, color=COLORS["price"], lw=1.6, label=L("rolling mean of residuals", "按拟合值排序后的局部均值"))
    axr.set_xlabel(L("fitted value", "拟合值"))
    axr.set_ylabel(L("residual", "残差"))
    axr.set_title(L("residual check: no pattern left", "残差检查：不应留下结构"))
    axr.legend(loc="upper left", frameon=False, fontsize=8.5)
    annotate_source(
        axr,
        L(
            "Synthetic sample (fixed seed). A curved residual pattern would mean the linear model is misspecified.",
            "合成样本（固定 seed）。若残差出现弯曲结构，说明线性模型设定错误。",
        ),
        y=-0.24,
    )
    fig.get_layout_engine().execute(fig)
    return finalize(fig, spec)


@figure(
    "03",
    "ch03_multiple_testing",
    section="§10. Multiple testing 与研究者自由度",
    kind="synthetic",
    title="数据窥探：20 个纯噪声策略里最好的 t 统计量经常超过 2",
    note="固定 seed 的 4000 次模拟，每次 20 个独立零信号策略；比较单个 t 与最大 t 的分布。",
    figsize=(9.8, 4.8),
)
def multiple_testing(spec):
    rng = np.random.default_rng(404)
    sims, strategies, n = 4000, 20, 252
    single = []
    best = []
    for _ in range(sims):
        samples = rng.normal(0, 1, size=(strategies, n))
        t_stats = samples.mean(axis=1) / (samples.std(axis=1, ddof=1) / np.sqrt(n))
        single.append(t_stats[0])
        best.append(np.abs(t_stats).max())
    single = np.array(single)
    best = np.array(best)

    fig, ax = new_figure(spec)
    grid = np.linspace(0, 6, 200)
    ax.plot(grid, 2 * stats.t.pdf(grid, n - 1), color=COLORS["price"], lw=1.8,
            label=L("|t| of one null strategy", "单个零信号策略的 |t|"))
    ax.hist(best, bins=60, density=True, color=COLORS["negative"], alpha=0.45, edgecolor="none",
            label=L("max |t| over 20 null strategies", "20 个零信号策略中的最大 |t|"))
    ax.axvline(2.0, color=COLORS["neutral"], lw=1.3, ls=":")
    ax.text(2.05, ax.get_ylim()[1] * 0.9, L("naive threshold |t| = 2", "朴素阈值 |t| = 2"), fontsize=9, color=COLORS["neutral"], va="top")
    frac = (best > 2).mean()
    ax.text(
        0.98,
        0.62,
        L(
            f"P(max |t| > 2) = {frac:.1%}\nwith zero real signal anywhere",
            f"P(最大 |t| > 2) = {frac:.1%}\n而全部策略都没有真实信号",
        ),
        transform=ax.transAxes,
        ha="right",
        fontsize=9,
        color=COLORS["negative"],
        bbox=dict(boxstyle="round,pad=0.35", fc="#fdecea", ec=COLORS["negative"], lw=0.7),
    )
    ax.set_xlabel(L("|t-statistic|", "|t 统计量|"))
    ax.set_ylabel(L("density", "密度"))
    ax.set_title(L("Why the best of many backtests lies", "为什么许多回测里最好的那个会骗人"))
    ax.legend(loc="upper right", frameon=False, fontsize=8.5)
    annotate_source(
        ax,
        L(
            "Synthetic null simulation (fixed seed): every strategy has exactly zero expected return.",
            "合成零假设模拟（固定 seed）：每个策略的期望收益都恰好为 0。",
        ),
    )
    return finalize(fig, spec)
