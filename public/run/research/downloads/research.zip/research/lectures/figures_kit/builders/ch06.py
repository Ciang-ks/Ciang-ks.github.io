"""Figures for chapter 06 (portfolio construction, execution and risk)."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .. import data as D
from ..style import COLORS, L, annotate_source, figure, finalize, new_figure


@figure(
    "06",
    "ch06_vol_targeting",
    section="§2.1 Volatility targeting",
    kind="public_data",
    title="波动率目标如何自动去杠杆： realized vol 上升时仓位倍数下降",
    note="Yahoo Finance ^GSPC 本地快照；目标年化波动 10%，仓位倍数上限 2、下限 0.2。",
    figsize=(10.4, 5.2),
)
def vol_targeting(spec):
    market = D.real_market().dropna(subset=["spx_close"]).loc["2010":]
    returns = market["spx_return"].dropna()
    realized = returns.rolling(60).std() * np.sqrt(252)
    target = 0.10
    leverage = (target / realized).clip(0.2, 2.0).shift(1)

    fig, (ax, axl) = new_figure(spec, 2, 1, sharex=True, height_ratios=[1, 1.15])
    ax.plot(realized.index, realized * 100, color=COLORS["price"], lw=1.3, label=L("60d realized vol", "60 日 realized vol"))
    ax.axhline(target * 100, color=COLORS["negative"], lw=1.1, ls="--", label=L("target vol 10%", "目标波动 10%"))
    ax.set_ylabel(L("annualized vol (%)", "年化波动（%）"))
    ax.set_title(
        L(
            "Volatility targeting: size = target / realized",
            "波动率目标：仓位倍数 = 目标波动 ÷ realized 波动（滞后一天）",
        )
    )
    ax.legend(loc="upper left", frameon=False, fontsize=8.5)

    axl.fill_between(leverage.index, 0, leverage, color=COLORS["accent"], alpha=0.55, step="post")
    axl.step(leverage.index, leverage, where="post", color=COLORS["accent"], lw=1.2)
    axl.axhline(1.0, color=COLORS["neutral"], lw=0.9, ls=":")
    axl.set_ylim(0, 2.2)
    axl.set_ylabel(L("position multiplier", "仓位倍数"))
    axl.set_xlabel(L("date", "日期"))
    high_date, low_date = realized.idxmax(), realized.idxmin()
    extremes = [(high_date, realized.loc[high_date]), (low_date, realized.loc[low_date])]
    text = "\n".join(
        L(f"{date:%Y-%m}: vol {value:.1%} → next size {np.clip(target/value, 0.2, 2):.2f}",
          f"{date:%Y-%m}：波动 {value:.1%} → 次期倍数 {np.clip(target/value, 0.2, 2):.2f}")
        for date, value in extremes
    )
    axl.text(0.99, 0.95, text, transform=axl.transAxes, ha="right", va="top", fontsize=8.5,
             color=COLORS["neutral"], bbox=dict(boxstyle="round,pad=0.32", fc="white", ec="#bbbbbb", lw=0.7))
    annotate_source(
        axl,
        L(
            "Public local snapshot: Yahoo Finance ^GSPC. The multiplier uses yesterday's vol estimate, never today's.",
            "公开数据本地快照：Yahoo Finance ^GSPC。倍数只用昨天的波动估计，不用当天。",
        ),
        y=-0.42,
    )
    fig.get_layout_engine().execute(fig)
    return finalize(fig, spec)


@figure(
    "06",
    "ch06_risk_contribution",
    section="§2.2 Risk parity",
    kind="project_output",
    title="等权 vs 逆波动权重：权重份额与风险贡献份额的差别",
    note="项目 A 合成面板的样本协方差；每项风险贡献由权重与协方差向量的乘积除以组合方差得到。",
    figsize=(10.6, 4.9),
)
def risk_contribution(spec):
    bundle = D.project_a()
    returns = bundle["prices"].pct_change().dropna()
    cov = returns.cov() * 252
    vol = np.sqrt(np.diag(cov))
    equal = np.ones(len(vol)) / len(vol)
    inv_vol = (1 / vol) / (1 / vol).sum()

    def risk_share(w):
        mcr = cov.to_numpy() @ w
        rc = w * mcr
        return rc / rc.sum()

    fig, axes = new_figure(spec, 1, 2)
    x = np.arange(len(vol))
    width = 0.38
    for ax, title in (
        (axes[0], L("weight share", "权重份额")),
        (axes[1], L("risk-contribution share", "风险贡献份额")),
    ):
        values_equal = equal if ax is axes[0] else risk_share(equal)
        values_iv = inv_vol if ax is axes[0] else risk_share(inv_vol)
        ax.bar(x - width / 2, values_equal * 100, width, color=COLORS["neutral"], alpha=0.85, label=L("equal weight", "等权"))
        ax.bar(x + width / 2, values_iv * 100, width, color=COLORS["accent"], alpha=0.9, label=L("inverse-vol weight", "逆波动权重"))
        ax.set_xticks(x)
        ax.set_xticklabels(cov.columns, rotation=40, ha="right", fontsize=8)
        ax.set_ylabel("%")
        ax.set_title(title, fontsize=10.5)
        ax.legend(loc="upper right", frameon=False, fontsize=8.5)
    annotate_source(
        axes[1],
        L(
            "Deterministic synthetic panel from projects/alpha_research; sample covariance, not a forecast.",
            "projects/alpha_research 的确定性合成面板；使用样本协方差，不是预测协方差。",
        ),
        y=-0.42,
    )
    fig.get_layout_engine().execute(fig)
    return finalize(fig, spec)


@figure(
    "06",
    "ch06_book_walk",
    section="§4.2 订单簿和成交概率",
    kind="concept",
    title="大单吃穿订单簿：平均成交价为什么差于 mid",
    note="手写五档卖单；市价买单 6,000 股逐档成交，计算平均成交价与冲击。",
    figsize=(10.0, 4.9),
)
def book_walk(spec):
    asks = [(100.1, 2_000), (100.2, 1_400), (100.3, 900), (100.4, 500), (100.5, 3_000)]
    order = 6_000
    fills = []
    remaining = order
    for price, size in asks:
        qty = min(remaining, size)
        fills.append((price, qty))
        remaining -= qty
        if remaining == 0:
            break
    avg = sum(p * q for p, q in fills) / order
    mid = 100.0
    cum = np.cumsum([size for _, size in asks])

    fig, (ax, axc) = new_figure(spec, 1, 2, width_ratios=[1.25, 1])
    prices = [p for p, _ in asks]
    sizes = [s for _, s in asks]
    colors = [COLORS["negative"] if q > 0 else "#dddddd" for _, q in fills] + ["#dddddd"] * (len(asks) - len(fills))
    ax.barh(prices, sizes, height=0.06, color=colors, alpha=0.9)
    for (price, qty), size in zip(fills, sizes):
        ax.text(size + 60, price, f"fill {qty:,} @ {price:g}", va="center", fontsize=8.5, color=COLORS["negative"])
    ax.axvline(0, color="#333333", lw=0.8)
    ax.set_xlabel(L("size at price", "该价格挂单量"))
    ax.set_ylabel(L("ask price", "卖价"))
    ax.set_title(L("walking the ask side", "市价买单逐档吃穿卖单"))

    axc.step(np.r_[0, cum], [prices[0], *prices], where="pre", color=COLORS["price"], lw=1.6, label=L("marginal ask", "边际卖价"))
    axc.axvline(order, color=COLORS["negative"], lw=1.2, ls="--")
    axc.axhline(avg, color=COLORS["negative"], lw=1.2, ls=":")
    axc.axhline(mid, color=COLORS["neutral"], lw=1.0, ls=":")
    axc.text(order, max(prices) + 0.035, L(f"order {order:,}", f"订单 {order:,}"), fontsize=8.5, color=COLORS["negative"], ha="center", va="bottom")
    axc.set_ylim(mid-0.025, max(prices)+0.08)
    axc.text(
        0.98,
        0.06,
        L(
            f"avg fill {avg:.3f}\nmid {mid:.2f}\ncost vs mid {(avg - mid) / mid * 1e4:.1f} bp",
            f"平均成交 {avg:.3f}\nmid {mid:.2f}\n相对 mid 滑点 {(avg - mid) / mid * 1e4:.1f} bp",
        ),
        transform=axc.transAxes,
        ha="right",
        fontsize=8.5,
        color=COLORS["negative"],
        bbox=dict(boxstyle="round,pad=0.32", fc="#fdecea", ec=COLORS["negative"], lw=0.7),
    )
    axc.set_xlabel(L("cumulative shares", "累计股数"))
    axc.set_ylabel(L("price", "价格"))
    axc.set_title(L("Marginal ask and average fill", "边际卖价阶梯与平均成交价"))
    axc.legend(loc="upper left", frameon=False, fontsize=8.5)
    annotate_source(
        axc,
        L(
            "Concept sketch with hand-written quotes; real impact also depends on hidden liquidity and replenishment.",
            "概念示意图：报价为手写数值；真实冲击还取决于隐藏流动性和挂单回补速度。",
        ),
        y=-0.3,
    )
    fig.get_layout_engine().execute(fig)
    return finalize(fig, spec)


@figure(
    "06",
    "ch06_cost_monotonicity",
    section="§6.3 Cost-aware backtest",
    kind="project_output",
    title="成本单调性：同一策略在 0/10/25/50 bps 下的净值与 Sharpe",
    note="项目 A 固定 pipeline 在进程内重算；成本越高净值越低是必须通过的不变量。",
    figsize=(10.4, 5.2),
)
def cost_monotonicity(spec):
    bundle = D.project_a()
    fig, (ax, axm) = new_figure(spec, 2, 1, height_ratios=[2.0, 1], gridspec_kw=dict(hspace=0.28))
    palette = {0.0: COLORS["positive"], 10.0: COLORS["price"], 25.0: COLORS["accent"], 50.0: COLORS["negative"]}
    for cost, result in bundle["backtests"].items():
        ax.plot(result.index, result["equity"], color=palette[cost], lw=1.5, label=L(f"{cost:g} bp", f"{cost:g} bp"))
    ax.plot(bundle["benchmark"].index, bundle["benchmark"]["equity"], color=COLORS["neutral"], lw=1.2, ls="--",
            label=L("equal weight @10bp", "等权基准 @10bp"))
    ax.axhline(1.0, color="#999999", lw=0.8)
    ax.set_ylabel(L("net equity", "净净值"))
    ax.set_title(
        L(
            "Same signal, four cost assumptions",
            "同一信号、四种成本假设：净值随成本单调下降",
        )
    )
    ax.legend(loc="upper left", frameon=False, fontsize=8.5, ncol=3)

    names = [L(f"{c:g} bp", f"{c:g} bp") for c in bundle["config"]["costs_bps"]]
    sharpes = [bundle["metrics"][f"trend_{int(c)}bps"]["sharpe"] for c in bundle["config"]["costs_bps"]]
    bars = axm.bar(names, sharpes, color=[palette[c] for c in bundle["config"]["costs_bps"]], alpha=0.9)
    for bar, value in zip(bars, sharpes):
        offset = 0.02 if value >= 0 else -0.02
        axm.text(bar.get_x() + bar.get_width() / 2, value + offset, f"{value:.2f}",
                 ha="center", va="bottom" if value >= 0 else "top", fontsize=8.5)
    axm.axhline(0, color="#333333", lw=0.9)
    axm.margins(y=0.25)
    axm.set_ylabel(L("Sharpe (net)", "净 Sharpe"))
    axm.set_xlabel(L("one-way cost", "单边成本"))
    annotate_source(
        axm,
        L(
            "Deterministic Project A pipeline recomputed in-process; synthetic data, teaching result only.",
            "项目 A 确定性 pipeline 在进程内重算；合成数据，结果仅用于教学。",
        ),
        y=-0.62,
    )
    fig.get_layout_engine().execute(fig)
    return finalize(fig, spec)


@figure(
    "06",
    "ch06_pnl_decomposition",
    section="§7. PnL、风险归因与监控",
    kind="project_output",
    title="PnL 分解：毛收益、成本拖累与净收益三条累计曲线",
    note="项目 A 10 bps 成本情景；成本累计曲线单调向下，是会计正确性的检查项。",
    figsize=(10.2, 5.0),
)
def pnl_decomposition(spec):
    result = D.project_a()["backtests"][10.0]
    fig, ax = new_figure(spec)
    cum_gross = result["gross_return"].cumsum() * 100
    cum_cost = -result["cost"].cumsum() * 100
    cum_net = result["net_return"].cumsum() * 100
    ax.plot(result.index, cum_gross, color=COLORS["positive"], lw=1.5, label=L("cumulative gross", "累计毛收益"))
    ax.plot(result.index, cum_cost, color=COLORS["negative"], lw=1.5, label=L("cumulative cost (drag)", "累计成本（拖累）"))
    ax.plot(result.index, cum_net, color=COLORS["price"], lw=1.7, label=L("cumulative net", "累计净收益"))
    ax.fill_between(result.index, cum_net, cum_gross, color=COLORS["negative"], alpha=0.12)
    ax.axhline(0, color="#333333", lw=0.9)
    ax.set_ylabel(L("cumulative return (%)", "累计收益（%）"))
    ax.set_xlabel(L("date", "日期"))
    ax.set_title(
        L(
            "Gross - cost = net, path by path",
            "毛收益 − 成本 = 净收益：逐日可见的分解",
        )
    )
    ax.legend(loc="upper left", frameon=False, fontsize=8.5)
    annotate_source(
        ax,
        L(
            "Deterministic Project A pipeline at 10 bp; turnover cost is linear in |Δw| by design.",
            "项目 A 确定性 pipeline（10 bp）；换手成本按 |Δw| 线性计算，是刻意简化的教学模型。",
        ),
    )
    return finalize(fig, spec)
