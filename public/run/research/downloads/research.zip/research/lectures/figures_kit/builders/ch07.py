"""Figures for chapter 07 (machine learning for quant research)."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats

from .. import data as D
from ..style import COLORS, L, annotate_source, figure, finalize, new_figure


@figure(
    "07",
    "ch07_label_overlap",
    section="§3.4 Label horizon 与 overlap",
    kind="concept",
    title="重叠标签为什么需要 purge 与 embargo",
    note="标签为未来 5 日收益；相邻样本的标签窗口互相重叠。",
    figsize=(10.4, 4.6),
)
def label_overlap(spec):
    fig, ax = new_figure(spec)
    horizon = 5
    for row in range(6):
        y = 5 - row
        ax.barh(y, 1, left=row, height=0.42, color=COLORS["price"], alpha=0.85, edgecolor="white")
        ax.barh(y, horizon, left=row + 1, height=0.42, color=COLORS["accent"], alpha=0.55, edgecolor="white")
        ax.text(row + 0.5, y, f"x{row}", ha="center", va="center", fontsize=8, color="white")
        ax.text(row + 1 + horizon / 2, y, L(f"label: return t+1..t+{horizon}", f"标签：t+1..t+{horizon} 收益"),
                ha="center", va="center", fontsize=7.5, color=COLORS["neutral"])
    boundary = 3.0
    ax.axvline(boundary, color=COLORS["negative"], lw=1.6)
    ax.axvspan(boundary - horizon, boundary, color=COLORS["negative"], alpha=0.12)
    ax.text(
        boundary - horizon / 2,
        6.1,
        L("purge: labels that cross the boundary", "purge：标签跨越切分边界的样本"),
        ha="center",
        fontsize=8.5,
        color=COLORS["negative"],
    )
    ax.axvspan(boundary, boundary + 1.2, color=COLORS["accent"], alpha=0.18)
    ax.text(
        boundary + 0.6,
        -0.9,
        L("embargo gap", "embargo 间隔"),
        ha="center",
        fontsize=8.5,
        color=COLORS["accent"],
    )
    ax.set_xlim(-0.6, 11.6)
    ax.set_ylim(-1.4, 6.6)
    ax.set_yticks([])
    ax.set_xlabel(L("time (days) →", "时间（天）→"))
    ax.set_xticks([])
    for spine in ("left", "right", "top"):
        ax.spines[spine].set_visible(False)
    ax.set_title(
        L(
            "Forward labels overlap: neighbours share future returns",
            "前瞻标签互相重叠：相邻样本共享同一段未来收益",
        )
    )
    annotate_source(
        ax,
        L(
            "Concept sketch with a 5-day label horizon; Project B uses the same logic for its text and market labels.",
            "概念示意图（5 日标签 horizon）；项目 B 的文本与市场标签遵循同样逻辑。",
        ),
        y=-0.06,
    )
    return finalize(fig, spec)


@figure(
    "07",
    "ch07_bias_variance",
    section="§5. Bias-variance 与模型选择",
    kind="synthetic",
    title="模型复杂度与 train/test 误差：U 形曲线与过拟合区",
    note="固定 seed 合成数据，多项式阶数 1–12；test 误差最低点才是可选复杂度。",
    figsize=(9.8, 4.9),
)
def bias_variance(spec):
    rng = np.random.default_rng(808)
    n_train, n_test = 260, 400
    x_train = np.linspace(-2.5, 2.5, n_train)
    y_train = np.sin(1.6 * x_train) + 0.35 * x_train + rng.normal(0, 0.45, n_train)
    x_test = np.linspace(-2.5, 2.5, n_test)
    y_test = np.sin(1.6 * x_test) + 0.35 * x_test + rng.normal(0, 0.45, n_test)

    degrees = range(1, 13)
    train_err, test_err = [], []
    for degree in degrees:
        coef = np.polyfit(x_train, y_train, degree)
        train_err.append(np.mean((np.polyval(coef, x_train) - y_train) ** 2))
        test_err.append(np.mean((np.polyval(coef, x_test) - y_test) ** 2))
    best = int(np.argmin(test_err)) + 1

    fig, ax = new_figure(spec)
    ax.plot(list(degrees), train_err, "o-", color=COLORS["price"], lw=1.6, ms=4.5, label=L("train MSE", "训练 MSE"))
    ax.plot(list(degrees), test_err, "s-", color=COLORS["negative"], lw=1.6, ms=4.5, label=L("test MSE", "测试 MSE"))
    ax.axvline(best, color=COLORS["positive"], lw=1.2, ls=":")
    ax.text(best + 0.15, max(test_err) * 0.85, L(f"best test at degree {best}", f"test 误差最低：阶数 {best}"),
            fontsize=8.5, color=COLORS["positive"])
    ax.axvspan(best + 1, 12.4, color=COLORS["negative"], alpha=0.08)
    ax.text(10.0, max(test_err) * 0.45, L("overfitting region", "过拟合区"), fontsize=9, color=COLORS["negative"], ha="center")
    ax.set_yscale("log")
    from ..style import plain_log_ticks

    plain_log_ticks(ax, "y")
    ax.set_xlabel(L("polynomial degree (complexity)", "多项式阶数（复杂度）"))
    ax.set_ylabel(L("MSE (log scale)", "MSE（对数刻度）"))
    ax.set_title(L("The bias-variance trade-off, made visible", "偏差—方差权衡的可见形态"))
    ax.legend(loc="upper center", frameon=False, fontsize=8.5)
    annotate_source(
        ax,
        L(
            "Synthetic sample (fixed seed). In quant research the 'test' set must also be later in time, not random.",
            "合成样本（固定 seed）。量化研究中 test 还必须在时间上更晚，而不是随机抽取。",
        ),
    )
    return finalize(fig, spec)


@figure(
    "07",
    "ch07_calibration",
    section="§8. Calibration、uncertainty 与 position sizing",
    kind="synthetic",
    title="校准曲线：预测概率与实现频率是否一致",
    note="固定 seed 合成分类器输出；raw 模型过度自信，缩放后贴近对角线。",
    figsize=(9.4, 5.0),
)
def calibration(spec):
    rng = np.random.default_rng(909)
    n = 4000
    true_p = rng.beta(2, 2, n)
    y = (rng.uniform(size=n) < true_p).astype(int)
    raw = np.clip(true_p ** 2.2, 0.01, 0.99)          # over-confident distortion
    calibrated = np.clip(0.15 + 0.72 * raw ** 0.55, 0.0, 1.0)

    fig, ax = new_figure(spec)
    bins = np.linspace(0, 1, 11)
    for values, color, label in (
        (raw, COLORS["negative"], L("raw model probability", "原始模型概率")),
        (calibrated, COLORS["positive"], L("after calibration map", "校准映射之后")),
    ):
        idx = np.digitize(values, bins) - 1
        means, realized = [], []
        for b in range(len(bins) - 1):
            mask = idx == b
            if mask.sum() >= 30:
                means.append(values[mask].mean())
                realized.append(y[mask].mean())
        ax.plot(means, realized, "o-", color=color, lw=1.5, ms=5, label=label)
    ax.plot([0, 1], [0, 1], color=COLORS["neutral"], lw=1.2, ls=":", label=L("perfect calibration", "完美校准"))
    ax.set_xlabel(L("predicted probability", "预测概率"))
    ax.set_ylabel(L("realized frequency", "实现频率"))
    ax.set_title(L("Calibration: probabilities must mean something", "校准：概率必须有频率含义"))
    ax.legend(loc="upper left", frameon=False, fontsize=8.5)
    annotate_source(
        ax,
        L(
            "Synthetic classifier (fixed seed). Uncalibrated probabilities distort any position size built from them.",
            "合成分类器（固定 seed）。未校准的概率会让任何基于它的仓位缩放失真。",
        ),
    )
    return finalize(fig, spec)


@figure(
    "07",
    "ch07_feature_drift",
    section="§10. Drift、retraining 与 model governance",
    kind="synthetic",
    title="特征漂移：同一特征在不同年份的分布会移动",
    note="固定 seed 合成特征，2021 年起均值与方差同时变化；标注两年间 KS 统计量。",
    figsize=(10.0, 5.0),
)
def feature_drift(spec):
    rng = np.random.default_rng(1010)
    years = [2018, 2019, 2020, 2021, 2022, 2023]
    samples = {}
    for i, year in enumerate(years):
        shift = 0.0 if year <= 2020 else 0.8 + 0.25 * (year - 2020)
        scale = 1.0 if year <= 2020 else 1.5
        samples[year] = rng.normal(shift, scale, 900)

    fig, ax = new_figure(spec)
    grid = np.linspace(-4, 6, 300)
    palette = ["#9ecae1", "#6baed6", "#4292c6", "#fdae6b", "#f16913", "#a63603"]
    for offset, (year, color) in enumerate(zip(years, palette)):
        kde = stats.gaussian_kde(samples[year])
        ax.fill_between(grid, offset * 0.5, offset * 0.5 + kde(grid) * 1.6, color=color, alpha=0.75)
        ax.text(-3.9, offset * 0.5 + 0.12, str(year), fontsize=9, color=COLORS["neutral"])
    ks = stats.ks_2samp(samples[2019], samples[2023])
    ax.text(
        0.98,
        0.97,
        L(
            f"KS(2019 vs 2023) = {ks.statistic:.2f}\np-value {ks.pvalue:.1e}",
            f"KS(2019 vs 2023) = {ks.statistic:.2f}\np 值 {ks.pvalue:.1e}",
        ),
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=8.5,
        color=COLORS["negative"],
        bbox=dict(boxstyle="round,pad=0.32", fc="#fdecea", ec=COLORS["negative"], lw=0.7),
    )
    ax.set_yticks([])
    ax.set_xlabel(L("feature value", "特征取值"))
    ax.set_title(L("Ridgeline: the same feature, different regimes", "山脊图：同一个特征在不同年份的分布"))
    annotate_source(
        ax,
        L(
            "Synthetic feature (fixed seed). Drift monitoring compares such distributions over rolling windows.",
            "合成特征（固定 seed）。漂移监控就是在滚动窗口上比较这类分布。",
        ),
    )
    return finalize(fig, spec)


@figure(
    "07",
    "ch07_importance_stability",
    section="§9. Feature importance 与可解释性",
    kind="synthetic",
    title="特征重要性要带误差棒：重抽样下的不稳定排序会误导归因",
    note="固定 seed 合成模型，30 次 bootstrap 重算 importance；误差棒为 ±1 标准差。",
    figsize=(9.8, 4.9),
)
def importance_stability(spec):
    rng = np.random.default_rng(1111)
    names = ["mom_60", "vol_60", "carry", "reversal_5", "text_tone", "size"]
    truth = np.array([0.42, 0.30, 0.16, 0.08, 0.03, 0.01])
    draws = rng.normal(truth, np.array([0.05, 0.06, 0.05, 0.04, 0.03, 0.02]), size=(30, len(names)))
    draws = np.abs(draws)
    mean = draws.mean(axis=0)
    std = draws.std(axis=0, ddof=1)
    order = np.argsort(mean)[::-1]

    fig, ax = new_figure(spec)
    x = np.arange(len(names))
    ax.bar(x, mean[order], yerr=std[order], capsize=4, color=COLORS["price"], alpha=0.85, ecolor=COLORS["negative"])
    ax.set_xticks(x)
    ax.set_xticklabels([names[i] for i in order], fontsize=9)
    ax.set_ylabel(L("permutation importance", "permutation importance"))
    ax.set_title(L("Importance with resampling error bars", "带重抽样误差棒的重要性"))
    ax.text(
        0.98,
        0.95,
        L(
            "text_tone vs reversal_5:\nerror bars overlap → order is not identified",
            "text_tone 与 reversal_5：\n误差棒重叠 → 排序未被识别",
        ),
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=8.5,
        color=COLORS["neutral"],
        bbox=dict(boxstyle="round,pad=0.32", fc="white", ec="#bbbbbb", lw=0.7),
    )
    annotate_source(
        ax,
        L(
            "Synthetic model outputs (fixed seed). A single importance number without uncertainty is not evidence.",
            "合成模型输出（固定 seed）。没有不确定度的单一重要性数字不构成证据。",
        ),
    )
    return finalize(fig, spec)
