"""Figures for chapter 05 (strategies, alpha and signal research)."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .. import data as D
from ..style import COLORS, L, annotate_source, figure, finalize, new_figure


@figure(
    "05",
    "ch05_trend_real_spx",
    section="§3.1 经济直觉",
    kind="public_data",
    title="真实 S&P 500 上的 12 个月趋势规则：信号只用过去价格，仓位滞后一天",
    note="Yahoo Finance ^GSPC 本地快照；教学示例规则，不构成投资建议。",
    figsize=(10.6, 5.6),
)
def trend_real_spx(spec):
    market = D.real_market().dropna(subset=["spx_close"]).loc["2010":]
    close = market["spx_close"]
    momentum = close / close.shift(252) - 1.0
    position = np.sign(momentum).shift(1).fillna(0.0)

    fig, (ax, axp) = new_figure(spec, 2, 1, sharex=True, height_ratios=[2.1, 1], gridspec_kw=dict(hspace=0.08))
    up_mask = position > 0
    ax.fill_between(close.index, close.min() * 0.92, close.max() * 1.05, where=up_mask, color=COLORS["band"], alpha=0.9,
                    label=L("12m momentum > 0 (rule is long)", "12 个月动量 > 0（规则持多）"))
    ax.plot(close.index, close, color=COLORS["price"], lw=1.4, label=L("S&P 500 close", "S&P 500 收盘"))
    switches = position.diff().abs().fillna(0) > 0
    ax.plot(close.index[switches], close[switches], "|", color=COLORS["negative"], ms=9, mew=1.2,
            label=L("position change (next-day execution)", "仓位切换（次日执行）"))
    ax.set_ylabel(L("index level", "指数点位"))
    ax.set_title(
        L(
            "A 12-month trend rule on real prices",
            "真实价格上的 12 个月趋势规则：背景色 = 规则仓位状态",
        )
    )
    ax.legend(loc="upper left", frameon=False, fontsize=8.5)

    axp.step(position.index, position, where="post", color=COLORS["negative"], lw=1.3)
    axp.fill_between(position.index, 0, position, step="post", color=COLORS["negative"], alpha=0.25)
    axp.set_ylim(-1.4, 1.4)
    axp.set_yticks([-1, 0, 1])
    axp.set_ylabel(L("position", "仓位"))
    axp.set_xlabel(L("date", "日期"))
    strategy_return = (position * market["spx_log_return"]).dropna()
    buyhold = market["spx_log_return"].dropna()
    axp.text(
        0.99,
        0.9,
        L(
            f"rule: annualized vol {strategy_return.std() * np.sqrt(252):.1%}\n"
            f"buy & hold: annualized vol {buyhold.std() * np.sqrt(252):.1%}\n"
            f"time in market {position.abs().mean():.0%}",
            f"规则：年化波动 {strategy_return.std() * np.sqrt(252):.1%}\n"
            f"买入持有：年化波动 {buyhold.std() * np.sqrt(252):.1%}\n"
            f"持仓时间占比 {position.abs().mean():.0%}",
        ),
        transform=axp.transAxes,
        ha="right",
        va="top",
        fontsize=8.5,
        color=COLORS["neutral"],
        bbox=dict(boxstyle="round,pad=0.32", fc="white", ec="#bbbbbb", lw=0.7),
    )
    annotate_source(
        axp,
        L(
            "Public local snapshot: Yahoo Finance ^GSPC. The rule only sees past prices and trades next day; teaching example, not advice.",
            "公开数据本地快照：Yahoo Finance ^GSPC。规则只看过去价格且次日执行；教学示例，不构成投资建议。",
        ),
        y=-0.55,
    )
    fig.tight_layout()
    return finalize(fig, spec)


@figure(
    "05",
    "ch05_signal_heatmap",
    section="§3.2 关键设计",
    kind="project_output",
    title="项目 A 合成面板上的 60 日动量信号：状态持续与资产差异",
    note="由 projects/alpha_research 的固定 seed 面板在进程内重算，不读取 outputs 目录。",
    figsize=(10.4, 5.0),
)
def signal_heatmap(spec):
    bundle = D.project_a()
    momentum = bundle["features"]["momentum"]
    scaled = momentum / bundle["features"]["volatility"].replace(0.0, np.nan)

    fig, ax = new_figure(spec)
    weekly = scaled.resample("W-FRI").mean().dropna(how="all")
    data = weekly.T
    ax.grid(False)
    im = ax.imshow(
        data.to_numpy(),
        aspect="auto",
        cmap="RdBu_r",
        vmin=-2.2,
        vmax=2.2,
        interpolation="nearest",
        extent=[0, len(weekly), len(weekly.columns), 0],
    )
    ax.set_yticks(np.arange(len(weekly.columns)) + 0.5)
    ax.set_yticklabels(weekly.columns, fontsize=8.5)
    step = max(len(weekly) // 8, 1)
    ticks = np.arange(0, len(weekly), step)
    ax.set_xticks(ticks)
    ax.set_xticklabels([weekly.index[i].strftime("%Y-%m") for i in ticks], fontsize=8)
    ax.set_xlabel(L("date", "日期"))
    ax.set_title(
        L(
            "Weekly momentum / volatility signal by asset",
            "各资产、各周的动量/波动信号（项目 A 合成面板，周频平均）",
        )
    )
    cbar = fig.colorbar(im, ax=ax, pad=0.015)
    cbar.set_label(L("signal (momentum ÷ vol)", "信号（动量 ÷ 波动）"), fontsize=9)
    annotate_source(
        ax,
        L(
            "Deterministic synthetic panel from projects/alpha_research (seed fixed); not real market history.",
            "projects/alpha_research 的确定性合成面板（seed 固定），不是真实市场历史。",
        ),
        y=-0.18,
    )
    return finalize(fig, spec)


@figure(
    "05",
    "ch05_rebalance_weights",
    section="§4. Cross-Sectional Momentum（截面动量）",
    kind="project_output",
    title="一次再平衡日：截面排序如何变成带约束的权重",
    note="项目 A 合成面板；权重 = 信号/|信号|之和，再按 ±25% 截断。",
    figsize=(10.0, 4.8),
)
def rebalance_weights(spec):
    bundle = D.project_a()
    weights = bundle["weights"]
    momentum = bundle["features"]["momentum"]
    rebalance_dates = weights.index[weights.diff().abs().sum(axis=1) > 0]
    date = rebalance_dates[len(rebalance_dates) // 2]
    w = weights.loc[date].sort_values()
    signal = momentum.loc[date].reindex(w.index)

    fig, (ax, axw) = new_figure(spec, 1, 2, width_ratios=[1, 1.1])
    order = signal.sort_values()
    colors = [COLORS["positive"] if v >= 0 else COLORS["negative"] for v in order]
    ax.barh(order.index, order.values, color=colors, alpha=0.85)
    ax.axvline(0, color="#333333", lw=0.9)
    ax.set_xlabel(L("60d momentum on rebalance date", "再平衡日的 60 日动量"))
    ax.set_title(L(f"cross-section at {date.date()}", f"{date.date()} 的截面排序"))

    axw.barh(w.index, w.values, color=[COLORS["positive"] if v >= 0 else COLORS["negative"] for v in w], alpha=0.85)
    axw.axvline(0.25, color=COLORS["neutral"], lw=1.0, ls=":")
    axw.axvline(-0.25, color=COLORS["neutral"], lw=1.0, ls=":")
    axw.text(0.255, 0.2, L("cap ±25%", "权重上限 ±25%"), fontsize=8.5, color=COLORS["neutral"], rotation=90, va="bottom")
    axw.set_xlabel(L("target weight", "目标权重"))
    axw.set_title(L("capped, gross-normalized weights", "截断并归一化后的目标权重"))
    annotate_source(
        axw,
        L(
            "Deterministic synthetic panel from projects/alpha_research; one rebalance date shown as an example.",
            "projects/alpha_research 的确定性合成面板；此处只展示一个再平衡日作为例子。",
        ),
        y=-0.22,
    )
    fig.tight_layout()
    return finalize(fig, spec)


@figure(
    "05",
    "ch05_mean_reversion_zscore",
    section="§5.1 直觉和风险",
    kind="synthetic",
    title="均值回归的 z-score 与 ±2 触发带：价差会回归，也可能不回归",
    note="固定 seed 合成价差：前段围绕均值波动，后段加入结构性漂移以展示失败模式。",
    figsize=(10.2, 5.0),
)
def mean_reversion_zscore(spec):
    rng = np.random.default_rng(707)
    n = 700
    spread = np.zeros(n)
    for t in range(1, n):
        drift = 0.0 if t < 450 else 0.004
        spread[t] = spread[t - 1] - 0.06 * spread[t - 1] + rng.normal(0, 0.5) + drift
    series = pd.Series(spread)
    rolling_mean = series.rolling(60, min_periods=30).mean()
    rolling_std = series.rolling(60, min_periods=30).std()
    z = (series - rolling_mean) / rolling_std

    fig, (ax, axz) = new_figure(spec, 2, 1, sharex=True, height_ratios=[1, 1.3])
    ax.plot(series.index, series, color=COLORS["price"], lw=1.2, label=L("spread", "价差"))
    ax.plot(rolling_mean.index, rolling_mean, color=COLORS["neutral"], lw=1.2, ls="--", label=L("60d rolling mean", "60 日滚动均值"))
    ax.axvline(450, color=COLORS["negative"], lw=1.0, ls=":")
    ax.text(455, series.max() * 0.85, L("regime break: drift appears", "状态改变：出现结构性漂移"), fontsize=8.5, color=COLORS["negative"])
    ax.set_ylabel(L("spread", "价差"))
    ax.set_title(L("A mean-reverting spread that later breaks", "先均值回归、后结构断裂的价差"))
    ax.legend(loc="upper left", frameon=False, fontsize=8.5)

    axz.plot(z.index, z, color=COLORS["price"], lw=1.1)
    axz.axhline(2, color=COLORS["negative"], lw=1.0, ls="--")
    axz.axhline(-2, color=COLORS["negative"], lw=1.0, ls="--")
    axz.axhline(0, color=COLORS["neutral"], lw=0.9)
    axz.fill_between(z.index, -2, 2, color=COLORS["band"], alpha=0.6)
    axz.text(10, 2.25, L("short spread when z > +2", "z > +2 做空价差"), fontsize=8.5, color=COLORS["negative"])
    axz.text(10, -2.75, L("long spread when z < -2", "z < -2 做多价差"), fontsize=8.5, color=COLORS["positive"])
    axz.set_ylabel(L("z-score", "z-score"))
    axz.set_xlabel(L("day", "交易日"))
    annotate_source(
        axz,
        L(
            "Synthetic spread (fixed seed). After day 450 the 'reversion' assumption is wrong: losses accumulate instead of converging.",
            "合成价差（固定 seed）。第 450 天后“会回归”的假设失效：亏损累积而不是收敛。",
        ),
        y=-0.42,
    )
    fig.tight_layout()
    return finalize(fig, spec)


@figure(
    "05",
    "ch05_ic_horizon_decay",
    section="§10. Step 3：测量 signal quality",
    kind="project_output",
    title="信号质量随持有期衰减：rank IC 与 horizon 的关系",
    note="项目 A 合成面板上计算：信号为 60 日动量/波动，标签为未来 h 日收益。",
    figsize=(9.6, 4.8),
)
def ic_horizon_decay(spec):
    bundle = D.project_a()
    prices = bundle["prices"]
    signal = bundle["features"]["momentum"] / bundle["features"]["volatility"].replace(0.0, np.nan)
    horizons = (1, 5, 10, 20, 40, 60)
    ics = {}
    for horizon in horizons:
        forward = prices.pct_change(horizon).shift(-horizon)
        daily = []
        for date in signal.index[::20]:
            row_signal = signal.loc[date].dropna()
            row_forward = forward.loc[date].reindex(row_signal.index).dropna()
            common = row_signal.index.intersection(row_forward.index)
            if len(common) >= 5:
                daily.append(np.corrcoef(row_signal[common].rank(), row_forward[common].rank())[0, 1])
        ics[horizon] = float(np.mean(daily)) if daily else float("nan")

    fig, ax = new_figure(spec)
    values = [ics[h] for h in horizons]
    bars = ax.bar([str(h) for h in horizons], values, color=COLORS["price"], alpha=0.85)
    for bar, value in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, value + 0.004, f"{value:.3f}", ha="center", fontsize=8.5)
    ax.axhline(0, color="#333333", lw=0.9)
    ax.set_xlabel(L("forward horizon h (business days)", "前瞻持有期 h（交易日）"))
    ax.set_ylabel(L("mean cross-sectional rank IC", "平均截面 rank IC"))
    ax.set_title(
        L(
            "Signal quality decays with the horizon",
            "信号质量随持有期衰减：选择持有期必须看这条曲线",
        )
    )
    annotate_source(
        ax,
        L(
            "Computed in-process from the deterministic Project A panel; labels are shifted forward, no look-ahead.",
            "在项目内从确定性项目 A 面板计算；标签已前移，无前视。",
        ),
    )
    return finalize(fig, spec)


@figure(
    "05",
    "ch05_score_to_weight",
    section="§10. Step 5：从分数到仓位",
    kind="concept",
    title="从 raw score 到最终权重：标准化、截断、归一化三步",
    note="六个示例分数为手写数值，用于展示约束如何改变权重。",
    figsize=(10.4, 4.8),
)
def score_to_weight(spec):
    names = ["A", "B", "C", "D", "E", "F"]
    raw = np.array([3.0, 1.5, 0.5, -0.5, -1.5, -6.0])
    z = (raw - raw.mean()) / raw.std(ddof=1)
    capped = np.clip(z, -1.5, 1.5)
    weight = capped / np.abs(capped).sum()

    fig, axes = new_figure(spec, 1, 3, sharey=False)
    steps = [
        (axes[0], raw, L("raw score", "原始分数"), COLORS["neutral"]),
        (axes[1], z, L("cross-sectional z-score", "截面 z-score"), COLORS["price"]),
        (axes[2], weight * 100, L("capped + normalized weight (%)", "截断 + 归一化权重（%）"), COLORS["positive"]),
    ]
    for ax, values, title, color in steps:
        colors = [COLORS["positive"] if v >= 0 else COLORS["negative"] for v in values]
        ax.bar(names, values, color=colors, alpha=0.85)
        ax.axhline(0, color="#333333", lw=0.9)
        ax.set_title(title, fontsize=10.5)
        ax.set_xticklabels(names, fontsize=9)
    axes[2].axhline(100 * 1.5 / np.abs(capped).sum(), color=COLORS["neutral"], lw=0.9, ls=":")
    axes[2].axhline(-100 * 1.5 / np.abs(capped).sum(), color=COLORS["neutral"], lw=0.9, ls=":")
    axes[2].text(
        5.4,
        100 * 1.5 / np.abs(capped).sum() + 1.2,
        L("cap after normalization", "归一化后的单资产上限"),
        fontsize=8,
        color=COLORS["neutral"],
        ha="right",
    )
    annotate_source(
        axes[2],
        L(
            "Concept sketch: the extreme score F is clipped, so one view cannot dominate the book.",
            "概念示意图：极端分数 F 被截断，因此单一观点不能主导整个组合。",
        ),
        y=-0.32,
    )
    fig.tight_layout()
    return finalize(fig, spec)
