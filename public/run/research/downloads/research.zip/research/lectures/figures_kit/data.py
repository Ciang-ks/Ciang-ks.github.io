"""Data loaders used by the lecture figures.

Three provenance classes are kept strictly separate:

* ``real_market`` — the public snapshots committed under
  ``sources/external/data`` (Yahoo Finance ``^GSPC`` / ``^TNX`` daily OHLCV and
  the public VIX daily series). Read-only, never re-downloaded by figures.
* ``synthetic`` — small deterministic series generated here with a fixed seed.
  They exist to show a mechanism (trend, mean reversion, fat tails), not to
  imitate any real asset.
* ``project_a`` — the reproducible pipeline of ``projects/alpha_research``
  (synthetic cross-asset prices -> momentum signal -> capped weights ->
  cost-aware backtest), imported instead of reading ``outputs/`` so figures do
  not depend on a previous run.
"""

from __future__ import annotations

import sys
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd

from .style import DATA_DIR, PROJECTS_DIR, REPO_ROOT

if str(REPO_ROOT / "lectures") not in sys.path:
    sys.path.insert(0, str(REPO_ROOT / "lectures"))

import notebook_helpers  # noqa: E402  (local module, same directory as figures_kit)


# --------------------------------------------------------------------------
# Public local snapshots
# --------------------------------------------------------------------------

@lru_cache(maxsize=1)
def real_market() -> pd.DataFrame:
    """S&P 500 close, 10Y yield index and VIX joined on date."""

    return notebook_helpers.load_real_market_data(REPO_ROOT)


@lru_cache(maxsize=1)
def sp500_ohlcv() -> pd.DataFrame:
    """Raw ``^GSPC`` daily OHLCV snapshot exactly as committed."""

    frame = pd.read_csv(DATA_DIR / "yahoo_sp500.csv", parse_dates=["date"])
    frame["date"] = pd.to_datetime(frame["date"], errors="coerce").dt.normalize()
    frame = frame.dropna(subset=["date"]).set_index("date").sort_index()
    return frame[["open", "high", "low", "close", "volume"]]


@lru_cache(maxsize=1)
def treasury_yield() -> pd.DataFrame:
    frame = pd.read_csv(DATA_DIR / "yahoo_tnx.csv", parse_dates=["date"])
    frame["date"] = pd.to_datetime(frame["date"], errors="coerce").dt.normalize()
    frame = frame.dropna(subset=["date"]).set_index("date").sort_index()
    return frame[["close"]].rename(columns={"close": "tnx_yield"})


@lru_cache(maxsize=1)
def vix_daily() -> pd.DataFrame:
    frame = pd.read_csv(DATA_DIR / "vix_daily.csv", parse_dates=["date"])
    frame["date"] = pd.to_datetime(frame["date"], errors="coerce").dt.normalize()
    frame = frame.dropna(subset=["date"]).set_index("date").sort_index()
    return frame.rename(columns={"vix_close": "vix"})[["vix"]]


def spx_window(start: str, end: str) -> pd.DataFrame:
    """OHLCV slice with derived daily returns, used for teaching windows."""

    frame = sp500_ohlcv().loc[start:end].copy()
    frame["log_return"] = np.log(frame["close"]).diff()
    return frame


# --------------------------------------------------------------------------
# Deterministic synthetic teaching series
# --------------------------------------------------------------------------

def synthetic_price(
    days: int = 500,
    *,
    seed: int = 11,
    drift: float = 0.0004,
    vol: float = 0.011,
    start: float = 100.0,
    start_date: str = "2020-01-01",
    fat_tail: float = 0.0,
) -> pd.DataFrame:
    """One synthetic daily price path with simple return and OHLC columns."""

    rng = np.random.default_rng(seed)
    innovations = rng.normal(0.0, vol, days)
    if fat_tail > 0:
        # Student-t style tails: scale a few observations instead of clipping,
        # so the reader sees large moves without an unrealistic hard limit.
        shocks = rng.standard_t(df=3, size=days) / np.sqrt(3.0)
        innovations = innovations + fat_tail * vol * shocks
    returns = drift + innovations
    close = start * np.exp(np.cumsum(returns))
    index = pd.bdate_range(start_date, periods=days, name="date")
    intra = np.abs(rng.normal(0.0, vol * 0.6, days))
    high = close * (1 + intra)
    low = close * (1 - intra)
    open_ = np.empty(days)
    open_[0] = start
    open_[1:] = close[:-1] * (1 + rng.normal(0.0, vol * 0.25, days - 1))
    frame = pd.DataFrame(
        {"open": open_, "high": np.maximum.reduce([open_, high, close]),
         "low": np.minimum.reduce([open_, low, close]), "close": close},
        index=index,
    )
    frame["simple_return"] = frame["close"].pct_change()
    frame["log_return"] = np.log(frame["close"]).diff()
    frame.loc[frame.index[0], ["simple_return", "log_return"]] = returns[0]
    return frame


def synthetic_assets(
    days: int = 750,
    *,
    seed: int = 23,
    start_date: str = "2019-01-01",
) -> pd.DataFrame:
    """Five labelled synthetic assets with different intended behaviour."""

    rng = np.random.default_rng(seed)
    index = pd.bdate_range(start_date, periods=days, name="date")
    t = np.arange(days)
    common = rng.normal(0.0, 0.008, days)

    trend = np.cumsum(0.0012 + 0.9 * common + rng.normal(0.0, 0.004, days))
    revert = np.zeros(days)
    for i in range(1, days):
        revert[i] = revert[i - 1] - 0.08 * revert[i - 1] + rng.normal(0.0, 0.01)
    equity = np.cumsum(0.0006 + common + rng.normal(0.0, 0.006, days))
    bond = np.cumsum(0.0002 - 0.35 * common + rng.normal(0.0, 0.003, days))
    noisy = np.cumsum(rng.normal(0.0, 0.02, days))

    frame = pd.DataFrame(
        {
            "TREND": 100 * np.exp(trend),
            "MEAN_REVERT": 100 + 12 * revert,
            "EQUITY": 100 * np.exp(equity),
            "BOND": 100 * np.exp(bond),
            "NOISY": 100 * np.exp(noisy),
        },
        index=index,
    )
    return frame


# --------------------------------------------------------------------------
# Project A pipeline (synthetic cross-asset, reproducible)
# --------------------------------------------------------------------------

def _import_project_a():
    project = PROJECTS_DIR / "alpha_research"
    if str(project) not in sys.path:
        sys.path.insert(0, str(project))
    from src import backtest as backtest_module  # noqa: E402
    from src import data as data_module  # noqa: E402
    from src import features as features_module  # noqa: E402
    from src import metrics as metrics_module  # noqa: E402

    return data_module, features_module, backtest_module, metrics_module


@lru_cache(maxsize=1)
def project_a(lookback: int = 60, rebalance_every: int = 20) -> dict:
    """Run the pinned Project A baseline in-process and return its parts."""

    data_module, features_module, backtest_module, metrics_module = _import_project_a()
    prices = data_module.make_prices(data_module.DataConfig())
    features = features_module.make_features(prices, lookback=lookback)
    weights = features_module.signal_to_weights(
        features["momentum"],
        features["volatility"],
        rebalance_every=rebalance_every,
    )
    costs = (0.0, 10.0, 25.0, 50.0)
    backtests = {
        cost: backtest_module.run_backtest(prices, weights, cost_bps=cost) for cost in costs
    }
    equal_weights = pd.DataFrame(1.0 / weights.shape[1], index=weights.index, columns=weights.columns)
    benchmark = backtest_module.run_backtest(prices, equal_weights, cost_bps=10.0)
    metrics = {
        f"trend_{int(cost)}bps": metrics_module.summarize(backtests[cost]["net_return"])
        for cost in costs
    }
    metrics["equal_weight_10bps"] = metrics_module.summarize(benchmark["net_return"])
    return {
        "prices": prices,
        "features": features,
        "weights": weights,
        "backtests": backtests,
        "benchmark": benchmark,
        "metrics": metrics,
        "config": {"lookback": lookback, "rebalance_every": rebalance_every, "costs_bps": costs},
    }


def project_b_outputs() -> dict[str, pd.DataFrame] | None:
    """Optional Project B artifacts; ``None`` when the project has not run."""

    directory = PROJECTS_DIR / "ml_llm_research" / "outputs"
    predictions = directory / "predictions.csv"
    ablation = directory / "ablation.csv"
    if not predictions.exists() or not ablation.exists():
        return None
    return {
        "predictions": pd.read_csv(predictions),
        "ablation": pd.read_csv(ablation),
    }


def data_window_summary() -> dict[str, str]:
    """Human readable as-of ranges, used inside figure captions."""

    market = real_market()
    spx = market["spx_close"].dropna()
    vix = market["vix"].dropna()
    tnx = market["tnx_yield"].dropna()
    return {
        "spx": f"{spx.index[0].date()} – {spx.index[-1].date()} ({len(spx)} obs)",
        "tnx": f"{tnx.index[0].date()} – {tnx.index[-1].date()} ({len(tnx)} obs)",
        "vix": f"{vix.index[0].date()} – {vix.index[-1].date()} ({len(vix)} obs)",
    }
