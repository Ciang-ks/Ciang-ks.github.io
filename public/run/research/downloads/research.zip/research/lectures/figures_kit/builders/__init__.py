"""Per-chapter figure builders. Importing this package registers all figures."""

from __future__ import annotations

from . import ch01, ch02, ch03, ch04, ch05, ch06, ch07, ch08, ch09  # noqa: F401

CHAPTERS = ("ch01", "ch02", "ch03", "ch04", "ch05", "ch06", "ch07", "ch08", "ch09")
