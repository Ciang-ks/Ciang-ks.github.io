"""Figures for chapter 02 (returns, risk, portfolios and performance)."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .. import data as D
from ..style import COLORS, L, annotate_source, figure, finalize, new_figure, plain_log_ticks


@figure(
    "02",
    "ch02_simple_vs_log",
    section="§1.2 Log return（对数收益）",
    kind="synthetic",
    title="同一段价格路径：simple return 相加会错，log return 相加才对",
    note="合成路径：100 → 50 → 100，两段 simple return 之和为 +50%，但财富没有变化。",
    figsize=(9.6, 4.8),
)
def simple_vs_log(spec):
    close = pd.Series([100.0, 50.0, 100.0], index=pd.RangeIndex(3, name="t"))
    simple = close.pct_change().fillna(0.0)
    log = np.log(close).diff().fillna(0.0)

    fig, (ax, axc) = new_figure(spec, 2, 1, height_ratios=[1.1, 1], sharex=True)
    ax.plot(close.index, close, "o-", color=COLORS["price"], lw=2.0, ms=7)
    for t, value in close.items():
        ax.annotate(f"{value:g}", (t, value), xytext=(t + 0.06, value + 4), fontsize=9, color=COLORS["neutral"])
    ax.set_ylabel(L("price", "价格"))
    ax.set_title(
        L(
            "A round trip: 100 -> 50 -> 100",
            "一段往返路径：100 → 50 → 100（财富最终没有变化）",
        )
    )

    width = 0.36
    axc.bar(close.index - width / 2, simple.cumsum() * 100, width, color=COLORS["negative"], alpha=0.8,
            label=L("cumulative simple return", "simple return 累加"))
    axc.bar(close.index + width / 2, log.cumsum() * 100, width, color=COLORS["positive"], alpha=0.8,
            label=L("cumulative log return", "log return 累加"))
    axc.axhline(0, color="#333333", lw=0.9)
    axc.annotate(
        L(
            "simple: -50% + 100% = +50%\nbut wealth is unchanged",
            "simple：-50% + 100% = +50%\n但财富其实没变（错误）",
        ),
        (1, 50),
        xytext=(0.35, 78),
        fontsize=8.5,
        color=COLORS["negative"],
        arrowprops=dict(arrowstyle="->", color=COLORS["negative"], lw=0.9),
    )
    axc.annotate(
        L(
            "log: -69.3% + 69.3% = 0\nmatches the round trip",
            "log：-69.3% + 69.3% = 0\n与往返事实一致（可加）",
        ),
        (2, 0),
        xytext=(1.15, 30),
        fontsize=8.5,
        color=COLORS["positive"],
        arrowprops=dict(arrowstyle="->", color=COLORS["positive"], lw=0.9),
    )
    axc.set_xticks(close.index)
    axc.set_xticklabels([f"t = {t}" for t in close.index])
    axc.set_ylabel(L("cumulative (%)", "累加收益（%）"))
    axc.legend(loc="lower left", frameon=False, fontsize=8.5)
    annotate_source(
        axc,
        L(
            "Synthetic three-point path chosen to expose the additivity difference.",
            "合成三点路径，专门用于暴露两种收益口径的可加性差异。",
        ),
        y=-0.5,
    )
    fig.get_layout_engine().execute(fig)
    return finalize(fig, spec)


@figure(
    "02",
    "ch02_vol_drag",
    section="§2. 复利、财富曲线和路径",
    kind="synthetic",
    title="同样的平均日收益、不同的波动：复利终点不同（波动拖累）",
    note="两条合成路径的算术平均日收益相同，高波动路径终点财富更低，小幅收益近似下，对数增长率每天约少一半日收益方差。",
    figsize=(9.8, 5.0),
)
def vol_drag(spec):
    days = 750
    rng = np.random.default_rng(41)
    drift = 0.0009
    index = pd.RangeIndex(days, name="day")
    paths = {}
    for name, vol in (("low vol", 0.004), ("high vol", 0.022)):
        returns = rng.normal(0, vol, days)
        returns += drift - returns.mean()
        paths[name] = pd.Series((1 + returns).cumprod(), index=index)
        paths[name + "_vol"] = vol

    fig, (ax, axr) = new_figure(spec, 2, 1, height_ratios=[2.1, 1])
    ax.plot(index, paths["low vol"], color=COLORS["positive"], lw=1.6, label=L("low vol path", "低波动路径"))
    ax.plot(index, paths["high vol"], color=COLORS["negative"], lw=1.4, alpha=0.85, label=L("high vol path", "高波动路径"))
    ax.set_yscale("log")
    plain_log_ticks(ax, "y")
    ax.set_ylabel(L("wealth (log scale)", "财富（对数刻度）"))
    ax.set_title(
        L(
            "Same arithmetic mean daily return, different volatility",
            "算术平均日收益相同、波动不同：复利终点不同",
        )
    )
    ax.legend(loc="upper left", frameon=False)
    ax.set_xlabel(L("day", "交易日"))
    gap = paths["low vol"].iloc[-1] / paths["high vol"].iloc[-1]
    ax.annotate(
        L(
            f"terminal ratio = {gap:.2f}x\nequal sample means; different compound growth",
            f"终点财富比 = {gap:.2f} 倍\n样本均值相同，复利增长不同",
        ),
        (days - 1, paths["high vol"].iloc[-1]),
        xytext=(days * 0.50, paths["high vol"].min() * 0.70),
        fontsize=8.5,
        color=COLORS["negative"],
        arrowprops=dict(arrowstyle="->", color=COLORS["negative"], lw=0.9),
    )

    for name, color in (("low vol", COLORS["positive"]), ("high vol", COLORS["negative"])):
        wealth = paths[name]
        daily = wealth.pct_change()
        daily.iloc[0] = wealth.iloc[0] - 1.0
        axr.hist(daily, bins=60, color=color, alpha=0.55, label=f"{name}: mean {daily.mean():.4f}, sd {daily.std():.4f}")
    axr.set_xlabel(L("daily return", "日收益"))
    axr.set_ylabel(L("count", "频数"))
    axr.legend(loc="upper center", frameon=False, fontsize=8)
    annotate_source(
        axr,
        L(
            "Synthetic paths, fixed seed; illustrates geometric vs arithmetic mean, not a market history.",
            "合成路径（固定 seed），说明几何平均与算术平均的差别，不是市场历史。",
        ),
        y=-0.62,
    )
    fig.get_layout_engine().execute(fig)
    return finalize(fig, spec)


@figure(
    "02",
    "ch02_vol_clustering",
    section="§3.2 年化波动的条件",
    kind="public_data",
    title="真实 S&P 500 日收益与 60 日滚动年化波动：波动是聚集的",
    note="Yahoo Finance ^GSPC 本地快照；教学用途，不构成投资建议。",
    figsize=(10.4, 5.4),
)
def vol_clustering(spec):
    market = D.real_market().dropna(subset=["spx_close"])
    returns = market["spx_log_return"].dropna()
    vol = returns.rolling(60).std() * np.sqrt(252)

    fig, (ax, axv) = new_figure(spec, 2, 1, sharex=True, height_ratios=[1.15, 1])
    colors = np.where(returns < 0, COLORS["negative"], COLORS["positive"])
    ax.vlines(returns.index, 0, returns * 100, color=colors, lw=0.55, alpha=0.8)
    ax.axhline(0, color="#333333", lw=0.8)
    ax.set_ylabel(L("daily log return (%)", "日对数收益（%）"))
    ax.set_title(
        L(
            "Real daily returns and 60-day rolling annualized volatility",
            "真实日收益与 60 日滚动年化波动：平静期与危机期交替",
        )
    )

    axv.plot(vol.index, vol * 100, color=COLORS["price"], lw=1.3)
    axv.axhline(vol.median() * 100, color=COLORS["neutral"], lw=0.9, ls=":")
    axv.text(
        vol.index[10],
        vol.median() * 100 + 1.2,
        L(f"median {vol.median():.1%}", f"中位数 {vol.median():.1%}"),
        fontsize=8.5,
        color=COLORS["neutral"],
    )
    for date, tag in (("2020-03-23", "2020-03"), ("2008-11-20", "2008-11")):
        ts = pd.Timestamp(date)
        if ts in vol.index:
            axv.annotate(
                tag,
                (ts, vol.loc[ts] * 100),
                xytext=(ts, vol.loc[ts] * 100 + 12),
                fontsize=8.5,
                color=COLORS["negative"],
                arrowprops=dict(arrowstyle="->", color=COLORS["negative"], lw=0.8),
            )
    axv.set_ylabel(L("60d annualized vol (%)", "60 日年化波动（%）"))
    axv.set_xlabel(L("date", "日期"))
    annotate_source(
        axv,
        L(
            "Public local snapshot: Yahoo Finance ^GSPC. Volatility clustering means one annualized number hides regimes.",
            "公开数据本地快照：Yahoo Finance ^GSPC。波动聚集意味着单个年化数字会掩盖状态差异。",
        ),
        y=-0.42,
    )
    fig.get_layout_engine().execute(fig)
    return finalize(fig, spec)


@figure(
    "02",
    "ch02_correlation_diversification",
    section="§4.2 组合收益与协方差矩阵",
    kind="synthetic",
    title="相关性如何决定分散化：散点与组合波动随权重的变化",
    note="左图为固定 seed 的二元正态样本；右图由两资产波动与相关系数公式直接计算。",
    figsize=(10.6, 4.9),
)
def correlation_diversification(spec):
    rng = np.random.default_rng(77)
    n = 900
    rho = 0.6
    z1 = rng.normal(size=n)
    z2 = rho * z1 + np.sqrt(1 - rho**2) * rng.normal(size=n)
    ra, rb = 0.0006 + 0.012 * z1, 0.0004 + 0.009 * z2

    fig, (ax, axw) = new_figure(spec, 1, 2, width_ratios=[1, 1.15])
    ax.scatter(ra * 100, rb * 100, s=7, alpha=0.35, color=COLORS["price"], edgecolor="none")
    slope = np.polyfit(ra, rb, 1)[0]
    grid = np.linspace(ra.min(), ra.max(), 50)
    ax.plot(grid * 100, (slope * grid) * 100, color=COLORS["negative"], lw=1.4)
    ax.set_xlabel(L("asset A daily return (%)", "资产 A 日收益（%）"))
    ax.set_ylabel(L("asset B daily return (%)", "资产 B 日收益（%）"))
    sample_rho = np.corrcoef(ra, rb)[0, 1]
    ax.set_title(L(f"sample correlation = {sample_rho:.2f}", f"样本相关系数 = {sample_rho:.2f}"))

    w = np.linspace(0, 1, 101)
    sa, sb = ra.std(), rb.std()
    for rho_case, color in ((0.9, COLORS["negative"]), (0.6, COLORS["accent"]), (0.0, COLORS["neutral"]), (-0.5, COLORS["positive"])):
        port_vol = np.sqrt((w * sa) ** 2 + ((1 - w) * sb) ** 2 + 2 * w * (1 - w) * rho_case * sa * sb)
        axw.plot(w, port_vol * np.sqrt(252) * 100, color=color, lw=1.6, label=f"ρ = {rho_case:+.1f}")
    axw.axhline(sa * np.sqrt(252) * 100, color="#bbbbbb", lw=0.8, ls=":")
    axw.axhline(sb * np.sqrt(252) * 100, color="#bbbbbb", lw=0.8, ls=":")
    axw.set_xlabel(L("weight on asset A", "资产 A 的权重 w"))
    axw.set_ylabel(L("portfolio annualized vol (%)", "组合年化波动（%）"))
    axw.set_title(L("diversification depends on ρ", "分散化效果取决于相关系数 ρ"))
    axw.legend(loc="upper right", frameon=False, fontsize=8.5)
    annotate_source(
        axw,
        L(
            "Synthetic bivariate sample (fixed seed); right panel is the §4.2 portfolio-variance formula.",
            "左图为固定 seed 的合成二元样本；右图由 §4.2 的组合方差公式直接计算。",
        ),
        y=-0.24,
    )
    fig.get_layout_engine().execute(fig)
    return finalize(fig, spec)


@figure(
    "02",
    "ch02_drawdown_real",
    section="§6. 回撤（Drawdown）与恢复",
    kind="public_data",
    title="真实 S&P 500 财富曲线与水下曲线：最大回撤与恢复时间",
    note="Yahoo Finance ^GSPC 本地快照（2010–2025）；教学用途，不构成投资建议。",
    figsize=(10.4, 5.6),
)
def drawdown_real(spec):
    market = D.real_market().dropna(subset=["spx_close"]).loc["2010":]
    close = market["spx_close"]
    wealth = close / close.iloc[0]
    drawdown = wealth / wealth.cummax() - 1

    fig, (ax, axd) = new_figure(spec, 2, 1, sharex=True, height_ratios=[1.5, 1])
    ax.plot(wealth.index, wealth, color=COLORS["price"], lw=1.5)
    ax.plot(wealth.cummax().index, wealth.cummax(), color="#bbbbbb", lw=1.0, ls="--", label=L("running peak (high-water mark)", "历史峰值（high-water mark）"))
    trough = drawdown.idxmin()
    peak = wealth.loc[:trough].idxmax()
    recovery = drawdown.loc[trough:]
    recovered = recovery[recovery >= -1e-12]
    recovery_date = recovered.index[0] if len(recovered) else None
    ax.plot([peak, trough], [wealth.loc[peak], wealth.loc[trough]], "o", color=COLORS["negative"], ms=5)
    ax.text(
        0.02, 0.72,
        L(f"peak {peak.date()} → trough {trough.date()}\nmax drawdown {drawdown.min():.1%}",
          f"峰值 {peak.date()} → 谷底 {trough.date()}\n最大回撤 {drawdown.min():.1%}"),
        transform=ax.transAxes, ha="left", va="top", fontsize=9,
        color=COLORS["neutral"], bbox=dict(boxstyle="round,pad=0.4", fc="white", ec="#e2e8f0"),
    )
    ax.set_ylabel(L("wealth (rebased)", "财富（再基准化）"))
    ax.set_title(
        L(
            "Wealth curve and underwater curve of the S&P 500",
            "S&P 500 的财富曲线与水下曲线（underwater curve）",
        )
    )
    ax.legend(loc="upper left", frameon=False, fontsize=8.5)

    axd.fill_between(drawdown.index, drawdown * 100, 0, color=COLORS["negative"], alpha=0.35)
    axd.plot(drawdown.index, drawdown * 100, color=COLORS["negative"], lw=0.8)
    if recovery_date is not None:
        axd.axvline(recovery_date, color=COLORS["positive"], lw=1.0, ls=":")
        axd.text(
            recovery_date,
            -4,
            L(f"  recovered {recovery_date.date()}", f"  恢复于 {recovery_date.date()}"),
            fontsize=8.5,
            color=COLORS["positive"],
        )
    axd.set_ylabel(L("drawdown (%)", "回撤（%）"))
    axd.set_xlabel(L("date", "日期"))
    annotate_source(
        axd,
        L(
            "Public local snapshot: Yahoo Finance ^GSPC close, daily log returns. Teaching only.",
            "公开数据本地快照：Yahoo Finance ^GSPC 收盘价、日对数收益；仅用于教学。",
        ),
        y=-0.42,
    )
    fig.get_layout_engine().execute(fig)
    return finalize(fig, spec)


@figure(
    "02",
    "ch02_var_cvar",
    section="§8. VaR、CVaR 与压力测试",
    kind="public_data",
    title="真实日收益分布上的 5% VaR 与 CVaR（尾部平均损失）",
    note="Yahoo Finance ^GSPC 本地快照；历史 VaR 不是未来承诺，尾部还会更坏。",
    figsize=(9.8, 5.0),
)
def var_cvar(spec):
    returns = D.real_market()["spx_return"].dropna().loc["2010":] * 100
    var = returns.quantile(0.05)
    cvar = returns[returns <= var].mean()

    fig, ax = new_figure(spec)
    ax.hist(returns, bins=120, color=COLORS["muted"], edgecolor="none")
    ax.axvline(var, color=COLORS["negative"], lw=1.6)
    ax.axvline(cvar, color=COLORS["accent"], lw=1.6, ls="--")
    tail = returns[returns <= var]
    ax.hist(tail, bins=40, color=COLORS["negative"], alpha=0.55, edgecolor="none")
    ax.text(
        var + 0.15,
        ax.get_ylim()[1] * 0.72,
        L(f"95% loss VaR = {-var:.2f}%/day", f"95% 损失 VaR = {-var:.2f}%/天"),
        color=COLORS["negative"],
        fontsize=9,
    )
    ax.text(
        cvar - 0.15,
        ax.get_ylim()[1] * 0.55,
        L(f"95% loss ES = {-cvar:.2f}%/day\n(return cutoff {var:.2f}%)", f"95% 损失 ES = {-cvar:.2f}%/天\n（收益阈值 {var:.2f}%）"),
        color=COLORS["accent"],
        fontsize=9,
        ha="right",
    )
    ax.set_xlabel(L("daily simple return (%)", "日简单收益（%）"))
    ax.set_ylabel(L("days", "天数"))
    ax.set_title(
        L(
            "Historical VaR / CVaR on real daily returns",
            "历史损失风险：收益阈值与尾部均值",
        )
    )
    annotate_source(
        ax,
        L(
            "Public local snapshot: Yahoo Finance ^GSPC. Historical quantiles describe the past sample only.",
            "公开数据本地快照：Yahoo Finance ^GSPC。历史分位数只描述过去样本，不是未来风险承诺。",
        ),
    )
    return finalize(fig, spec)
