"""Lecture figure kit: deterministic, self-contained teaching figures.

Importing this package registers every builder in ``figures_kit.builders``.
Run ``python lectures/make_figures.py`` to (re)generate the PNG files.
"""

from __future__ import annotations

from .style import (  # noqa: F401
    COLORS,
    FIG_DIR,
    KINDS,
    L,
    REGISTRY,
    FigureSpec,
    all_specs,
    annotate_source,
    figure,
    finalize,
    new_figure,
    render,
    setup,
    spec_to_manifest_entry,
)

from . import builders  # noqa: E402,F401  (import registers all figures)

__all__ = [
    "COLORS",
    "FIG_DIR",
    "KINDS",
    "L",
    "REGISTRY",
    "FigureSpec",
    "all_specs",
    "annotate_source",
    "figure",
    "finalize",
    "new_figure",
    "render",
    "setup",
    "spec_to_manifest_entry",
]
