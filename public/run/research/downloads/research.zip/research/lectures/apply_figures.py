"""Insert the registered lecture figures into `.md` and `.ipynb` files.

Usage::

    .venv/bin/python lectures/apply_figures.py            # apply to md + ipynb
    .venv/bin/python lectures/apply_figures.py --check    # verify without writing

The script is idempotent: a figure block whose alt text already exists in the
target file is left untouched. Anchors must match exactly one paragraph in the
Markdown lecture; the same anchor is then located inside the matching notebook
markdown cell, so both readers see the figure in the same place.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from figure_insertions import INSERTIONS, block  # noqa: E402

CHAPTER_FILES = {
    "01": "01-markets-assets",
    "02": "02-returns-risk",
    "03": "03-probability-statistics",
    "04": "04-data-pipeline",
    "05": "05-strategies-alpha",
    "06": "06-portfolio-execution",
    "07": "07-machine-learning",
    "08": "08-language-models",
    "09": "09-research-communication",
}

BLOCK_SPLIT = re.compile(r"\n\n+")


def split_blocks(text: str) -> list[str]:
    return [part for part in BLOCK_SPLIT.split(text) if part.strip()]


def insert_into_text(text: str, anchor: str, blocks: list[str]) -> tuple[str, int]:
    """Insert ``blocks`` after the paragraph containing ``anchor``.

    The rest of the document is preserved byte-for-byte: the insertion point is
    the blank line that terminates the anchor paragraph.
    """

    pending = [blk for blk in blocks if blk.splitlines()[0] not in text]
    if not pending:
        return text, 0
    occurrences = text.count(anchor)
    if occurrences != 1:
        raise ValueError(f"anchor matched {occurrences} times (expected 1): {anchor[:40]}...")
    position = text.index(anchor)
    end = text.find("\n\n", position)
    joined = "\n\n".join(pending)
    if end == -1:
        text = text.rstrip("\n") + "\n\n" + joined + "\n"
    else:
        text = text[:end] + "\n\n" + joined + text[end:]
    return text, len(pending)


def remove_from_text(text: str, entry_block: str) -> str:
    """Delete a previously inserted figure block (used by --revert)."""

    for pattern in (f"\n\n{entry_block}\n\n", f"\n\n{entry_block}", f"{entry_block}\n\n"):
        if pattern in text:
            return text.replace(pattern, "\n\n" if pattern == f"\n\n{entry_block}\n\n" else "", 1)
    return text.replace(entry_block, "", 1)


def apply_markdown(chapter: str, entries: list[str], check: bool) -> tuple[int, list[str]]:
    path = HERE / f"{CHAPTER_FILES[chapter]}.md"
    text = path.read_text(encoding="utf-8")
    updated = text
    # group by anchor, preserving registration order
    grouped: list[tuple[str, list[str]]] = []
    for anchor, blk in entries:
        if grouped and grouped[-1][0] == anchor:
            grouped[-1][1].append(blk)
        else:
            grouped.append((anchor, [blk]))
    problems = []
    total = 0
    for anchor, blocks in grouped:
        try:
            updated, inserted = insert_into_text(updated, anchor, blocks)
            total += inserted
        except ValueError as exc:
            problems.append(str(exc))
    if total and not check:
        path.write_text(updated, encoding="utf-8")
    return total, problems


def apply_notebook(chapter: str, entries: list[tuple[str, str]], check: bool) -> tuple[int, list[str]]:
    path = HERE / f"{CHAPTER_FILES[chapter]}.ipynb"
    notebook = json.loads(path.read_text(encoding="utf-8"))
    problems: list[str] = []
    total = 0
    for anchor, blk in entries:
        first_line = blk.splitlines()[0]
        placed = False
        for cell in notebook["cells"]:
            if cell["cell_type"] != "markdown":
                continue
            source = "".join(cell["source"])
            if anchor not in source or first_line in source:
                continue
            updated, inserted = insert_into_text(source, anchor, [blk])
            lines = updated.splitlines(keepends=True)
            if lines and lines[-1].endswith("\n"):
                lines[-1] = lines[-1][:-1]
            cell["source"] = lines
            total += inserted
            placed = True
            break
        if not placed and first_line not in "".join(
            "".join(c["source"]) for c in notebook["cells"] if c["cell_type"] == "markdown"
        ):
            problems.append(f"notebook anchor not placed: {anchor[:40]}...")
    if total and not check:
        path.write_text(json.dumps(notebook, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    return total, problems


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="only verify anchors and report what would change")
    parser.add_argument("--revert", action="store_true", help="remove previously inserted figure blocks")
    parser.add_argument("--chapter", nargs="*", default=None)
    args = parser.parse_args(argv)

    chapters = args.chapter or sorted(CHAPTER_FILES)
    if args.revert:
        from figure_insertions import INSERTIONS as _entries, block as _block

        for chapter in chapters:
            for target in ("md", "ipynb"):
                path = HERE / f"{CHAPTER_FILES[chapter]}.{target}"
                if target == "md":
                    text = path.read_text(encoding="utf-8")
                    for entry in _entries:
                        if entry.chapter != chapter:
                            continue
                        text = remove_from_text(text, _block(entry))
                    path.write_text(text, encoding="utf-8")
                else:
                    notebook = json.loads(path.read_text(encoding="utf-8"))
                    for cell in notebook["cells"]:
                        if cell["cell_type"] != "markdown":
                            continue
                        source = "".join(cell["source"])
                        for entry in _entries:
                            if entry.chapter != chapter:
                                continue
                            source = remove_from_text(source, _block(entry))
                        lines = source.splitlines(keepends=True)
                        if lines and lines[-1].endswith("\n"):
                            lines[-1] = lines[-1][:-1]
                        cell["source"] = lines
                    path.write_text(json.dumps(notebook, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
            print(f"[{chapter}] reverted")
        return 0
    failures = 0
    for chapter in chapters:
        entries = [
            (entry.anchor, block(entry))
            for entry in INSERTIONS
            if entry.chapter == chapter
        ]
        md_count, md_problems = apply_markdown(chapter, entries, args.check)
        nb_count, nb_problems = apply_notebook(chapter, entries, args.check)
        verb = "would insert" if args.check else "inserted"
        print(f"[{chapter}] md {verb} {md_count}, notebook {verb} {nb_count}")
        for problem in md_problems + nb_problems:
            print(f"    ! {problem}")
            failures += 1
    if failures:
        print(f"\n{failures} placement problem(s); nothing was written for those entries.")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
