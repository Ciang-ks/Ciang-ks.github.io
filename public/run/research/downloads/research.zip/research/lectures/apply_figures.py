"""Insert registered figures into the canonical lecture notebooks.

Usage::

    .venv/bin/python lectures/apply_figures.py            # apply to notebooks
    .venv/bin/python lectures/apply_figures.py --check    # verify without writing

The script is idempotent: a figure block whose alt text already exists in the
target file is left untouched. Anchors must match exactly one paragraph in the
notebook Markdown cell.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from figure_insertions import INSERTIONS, block  # noqa: E402

CHAPTER_FILES = {
    "01": "01-markets-assets",
    "02": "02-returns-risk",
    "03": "03-probability-statistics",
    "04": "04-data-pipeline",
    "05": "05-strategies-alpha",
    "06": "06-portfolio-execution",
    "07": "07-machine-learning",
    "08": "08-language-models",
    "09": "09-research-communication",
}

def insert_into_text(text: str, anchor: str, blocks: list[str]) -> tuple[str, int]:
    """Insert ``blocks`` after the paragraph containing ``anchor``.

    The rest of the document is preserved byte-for-byte: the insertion point is
    the blank line that terminates the anchor paragraph.
    """

    pending = [blk for blk in blocks if blk.splitlines()[0] not in text]
    if not pending:
        return text, 0
    occurrences = text.count(anchor)
    if occurrences != 1:
        raise ValueError(f"anchor matched {occurrences} times (expected 1): {anchor[:40]}...")
    position = text.index(anchor)
    end = text.find("\n\n", position)
    joined = "\n\n".join(pending)
    if end == -1:
        text = text.rstrip("\n") + "\n\n" + joined + "\n"
    else:
        text = text[:end] + "\n\n" + joined + text[end:]
    return text, len(pending)


def remove_from_text(text: str, entry_block: str) -> str:
    """Delete a previously inserted figure block (used by --revert)."""

    for pattern in (f"\n\n{entry_block}\n\n", f"\n\n{entry_block}", f"{entry_block}\n\n"):
        if pattern in text:
            return text.replace(pattern, "\n\n" if pattern == f"\n\n{entry_block}\n\n" else "", 1)
    return text.replace(entry_block, "", 1)


def apply_notebook(chapter: str, entries: list[tuple[str, str]], check: bool) -> tuple[int, list[str]]:
    path = HERE / f"{CHAPTER_FILES[chapter]}.ipynb"
    notebook = json.loads(path.read_text(encoding="utf-8"))
    problems: list[str] = []
    total = 0
    grouped: dict[str, list[str]] = {}
    for anchor, figure_block in entries:
        grouped.setdefault(anchor, []).append(figure_block)
    for anchor, blocks in grouped.items():
        for cell in notebook["cells"]:
            if cell["cell_type"] != "markdown":
                continue
            source = "".join(cell["source"])
            if anchor not in source:
                continue
            updated, inserted = insert_into_text(source, anchor, blocks)
            cell["source"] = updated.splitlines(keepends=True)
            total += inserted
            break
        text = "\n\n".join("".join(c["source"]) for c in notebook["cells"] if c["cell_type"] == "markdown")
        if any(figure_block.splitlines()[0] not in text for figure_block in blocks):
            problems.append(f"notebook anchor not placed: {anchor[:40]}...")
    if total and not check:
        path.write_text(json.dumps(notebook, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    return total, problems


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="only verify anchors and report what would change")
    parser.add_argument("--revert", action="store_true", help="remove previously inserted figure blocks")
    parser.add_argument("--chapter", nargs="*", default=None)
    args = parser.parse_args(argv)

    chapters = args.chapter or sorted(CHAPTER_FILES)
    if args.revert:
        from figure_insertions import INSERTIONS as _entries, block as _block

        for chapter in chapters:
            path = HERE / f"{CHAPTER_FILES[chapter]}.ipynb"
            notebook = json.loads(path.read_text(encoding="utf-8"))
            for cell in notebook["cells"]:
                if cell["cell_type"] != "markdown":
                    continue
                source = "".join(cell["source"])
                for entry in _entries:
                    if entry.chapter == chapter:
                        source = remove_from_text(source, _block(entry))
                cell["source"] = source.splitlines(keepends=True)
            path.write_text(json.dumps(notebook, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
            print(f"[{chapter}] reverted")
        return 0
    failures = 0
    for chapter in chapters:
        entries = [
            (entry.anchor, block(entry))
            for entry in INSERTIONS
            if entry.chapter == chapter
        ]
        nb_count, nb_problems = apply_notebook(chapter, entries, args.check)
        verb = "would insert" if args.check else "inserted"
        print(f"[{chapter}] notebook {verb} {nb_count}")
        for problem in nb_problems:
            print(f"    ! {problem}")
            failures += 1
    if failures:
        print(f"\n{failures} placement problem(s); nothing was written for those entries.")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
