"""Regenerate the lecture figures, manifest and figure README.

Usage (from the repository root or ``research/``)::

    .venv/bin/python lectures/make_figures.py                 # all chapters
    .venv/bin/python lectures/make_figures.py --chapter 01 02  # subset
    .venv/bin/python lectures/make_figures.py --list           # registry only
    .venv/bin/python lectures/make_figures.py --lang en        # English labels

The script never touches the network: real charts read the committed snapshots
under ``sources/external/data``, project charts recompute Project A in-process,
and everything else is a fixed-seed synthetic teaching series or a hand-drawn
concept sketch. Rendering is deterministic, so re-running rewrites byte-equal
PNG files and only the manifest/README change if the registry changes.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import matplotlib  # noqa: E402

import figures_kit  # noqa: E402  (import registers every builder)
from figures_kit import data as D  # noqa: E402
from figures_kit.style import FIG_DIR, KINDS, REGISTRY, all_specs, render, setup, spec_to_manifest_entry  # noqa: E402

CHAPTER_TITLES = {
    "01": "市场、资产与交易对象",
    "02": "收益、风险、组合与绩效",
    "03": "金融计量、时序建模与随机微积分",
    "04": "数据、偏差与量化研究管线",
    "05": "策略、Alpha 与信号研究",
    "06": "组合构建、执行与风险控制",
    "07": "机器学习用于量化研究",
    "08": "LLM4Quant 与文本研究",
    "09": "全链路项目、岗位能力与面试表达",
}


def build(chapters: list[str] | None, lang: str, dpi: int, verbose: bool) -> list[dict]:
    state = setup(lang=lang, dpi=dpi)
    specs = all_specs(chapters)
    entries: list[dict] = []
    for spec in specs:
        path = render(spec)
        entry = spec_to_manifest_entry(spec, path)
        entries.append(entry)
        if verbose:
            print(
                f"[{spec.chapter}] {path.name:<34} {spec.kind:<14} "
                f"{entry['bytes'] / 1024:6.1f} KiB  {entry['sha256'][:12]}  {spec.section}"
            )
    if verbose:
        print(
            f"\n{len(entries)} figures → {FIG_DIR}\n"
            f"lang={state.resolved_lang} (requested={state.lang}, cjk_font={state.cjk_font}) "
            f"style={state.style_name} dpi={state.dpi} matplotlib={matplotlib.__version__}"
        )
    return entries


def write_manifest(entries: list[dict], lang: str, dpi: int) -> Path:
    state = setup(lang=lang, dpi=dpi)
    payload = {
        "description": "讲义插图的生成清单：每张图的章节位置、数据类型、字节数与 SHA-256。",
        "generator": "lectures/make_figures.py",
        "environment": {
            "python": sys.version.split()[0],
            "matplotlib": matplotlib.__version__,
            "style": state.style_name,
            "requested_lang": state.lang,
            "resolved_lang": state.resolved_lang,
            "cjk_font": state.cjk_font,
            "dpi": state.dpi,
        },
        "kinds": KINDS,
        "public_data_windows": D.data_window_summary(),
        "figures": entries,
    }
    path = FIG_DIR / "manifest.json"
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path


def write_readme(entries: list[dict], lang: str, dpi: int) -> Path:
    state = setup(lang=lang, dpi=dpi)
    windows = D.data_window_summary()
    lines: list[str] = []
    add = lines.append

    add("# 讲义插图目录")
    add("")
    add(
        "本目录里的每张图都由 `lectures/make_figures.py` 或章节 notebook 在本仓库内生成。"
        "**没有引用任何第三方图片**，因此不存在转载许可问题；如果你要加入教材或百科的截图，"
        "必须新建 `SOURCES.md` 记录来源、作者、许可和访问日期，并把原图保存到本地而不是外链。"
    )
    add("")
    add("## 重新生成")
    add("")
    add("```bash")
    add("cd research")
    add(".venv/bin/python lectures/make_figures.py            # 全部章节")
    add(".venv/bin/python lectures/make_figures.py --chapter 01 02")
    add(".venv/bin/python lectures/make_figures.py --list      # 只列出注册表")
    add(".venv/bin/python lectures/check_figures.py            # 校验引用、清单与可复现性")
    add("```")
    add("")
    add(
        f"当前渲染环境：matplotlib {matplotlib.__version__}，style `{state.style_name}`，"
        f"dpi {state.dpi}，图内文字语言 `{state.resolved_lang}`"
        + (f"（CJK 字体 `{state.cjk_font}`）" if state.cjk_font else "（未检测到 CJK 字体，自动退回英文标签）")
        + "。缺少中文字体时脚本不会报错，只会改用英文标签，因此图在任何机器上都能生成。"
    )
    add("")
    add("## 四种数据类型（每张图都必须归入其中一种）")
    add("")
    add("| kind | 含义 |")
    add("|---|---|")
    for kind, explained in KINDS.items():
        add(f"| `{kind}` | {explained} |")
    add("")
    add(
        "图内和图注都必须写清数据类型：概念示意图不是行情，合成数据不是历史，"
        "项目输出不是真实交易结果，任何图都不构成投资建议。"
    )
    add("")
    add("## 脚本生成的插图")
    add("")
    add("| 文件 | 章节 | 位置 | 类型 | 说明 | 附注 | SHA-256（前 12 位） |")
    add("|---|---|---|---|---|---|---|")
    by_chapter: dict[str, list[dict]] = {}
    for entry in entries:
        by_chapter.setdefault(entry["chapter"], []).append(entry)
    for chapter in sorted(by_chapter):
        for entry in by_chapter[chapter]:
            add(
                f"| `{entry['file']}` | {chapter} {CHAPTER_TITLES.get(chapter, '')} | {entry['section']} "
                f"| `{entry['kind']}` | {entry['title']} | {entry['note'] or '—'} | `{entry['sha256'][:12]}` |"
            )
    add("")
    add("## 公开数据快照的时间范围")
    add("")
    add("真实行情图只读 `sources/external/data/` 的本地快照，不在生成图片时联网：")
    add("")
    add("| 序列 | 本地快照覆盖区间 |")
    add("|---|---|")
    add(f"| S&P 500 (`^GSPC`) 收盘/OHLCV | {windows['spx']} |")
    add(f"| 10 年期美债收益率指数 (`^TNX`) | {windows['tnx']} |")
    add(f"| VIX 日线 | {windows['vix']} |")
    add("")
    add(
        "字段、下载端点和 SHA-256 见 [`sources/external/data/README.md`](../../sources/external/data/README.md)。"
        "重新下载数据时必须保存新快照并更新本表，否则图注中的区间会失真。"
    )
    add("")
    add("## 已知的取舍")
    add("")
    add(
        "- 目前只有三条真实公开序列（股票指数、利率、波动率指数）。跨资产的“各类资产日线”用"
        "`projects/alpha_research` 的合成面板绘制，并在图注中明确标注为合成数据；接入真实多资产快照"
        "（黄金、原油、外汇、加密、信用、REITs）是明确的扩展点，需要先补齐许可、复权和时间对齐说明。"
    )
    add(
        "- 图内文字默认中文，但坐标轴与图例仍保留英文术语（如 `bid/ask`、`drawdown`、`rank IC`），"
        "以便读者把讲义、代码字段和行业资料对应起来。"
    )
    add("")

    path = FIG_DIR / "README.md"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--chapter", nargs="*", default=None, help="只生成指定章节，例如 --chapter 01 05")
    parser.add_argument("--lang", choices=("auto", "zh", "en"), default="auto", help="图内文字语言")
    parser.add_argument("--dpi", type=int, default=150, help="输出分辨率，默认 150")
    parser.add_argument("--list", action="store_true", help="只列出注册的图，不渲染")
    parser.add_argument("--no-docs", action="store_true", help="不重写 manifest.json 与 README.md")
    args = parser.parse_args(argv)

    if args.list:
        setup(lang=args.lang, dpi=args.dpi)
        for spec in all_specs(args.chapter):
            print(f"{spec.chapter}  {spec.name:<34} {spec.kind:<14} {spec.section:<28} {spec.title}")
        print(f"\ntotal {len(all_specs(args.chapter))} figures; chapters: {sorted(REGISTRY)}")
        return 0

    entries = build(args.chapter, args.lang, args.dpi, verbose=True)
    if args.no_docs:
        return 0
    if args.chapter:
        # Partial run: merge with the existing manifest instead of dropping entries.
        manifest_path = FIG_DIR / "manifest.json"
        if manifest_path.exists():
            previous = json.loads(manifest_path.read_text(encoding="utf-8"))
            registered = {spec.name for spec in all_specs()}
            merged = {entry["name"]: entry for entry in previous.get("figures", [])
                      if entry["name"] in registered}
            merged.update({entry["name"]: entry for entry in entries})
            entries = [merged[name] for name in sorted(merged)]
    manifest = write_manifest(entries, args.lang, args.dpi)
    readme = write_readme(entries, args.lang, args.dpi)
    print(f"manifest → {manifest}\nREADME   → {readme}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
