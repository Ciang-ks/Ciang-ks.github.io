"""Models and chronological evaluation helpers."""

from __future__ import annotations

import numpy as np
import pandas as pd


def split_dates(frame: pd.DataFrame, train_fraction: float = 0.6, validation_fraction: float = 0.2) -> tuple[pd.Timestamp, pd.Timestamp]:
    dates = sorted(pd.to_datetime(frame["decision_date"]).unique())
    train_end = dates[max(0, int(len(dates) * train_fraction) - 1)]
    validation_end = dates[max(0, int(len(dates) * (train_fraction + validation_fraction)) - 1)]
    return pd.Timestamp(train_end), pd.Timestamp(validation_end)


def chronological_masks(frame: pd.DataFrame, train_end: pd.Timestamp, validation_end: pd.Timestamp) -> dict[str, pd.Series]:
    dates = pd.to_datetime(frame["decision_date"])
    return {
        "train": dates <= train_end,
        "validation": (dates > train_end) & (dates <= validation_end),
        "test": dates > validation_end,
    }


def fit_predict(
    train: pd.DataFrame,
    evaluation: pd.DataFrame,
    feature_columns: list[str],
    model_name: str,
) -> np.ndarray:
    if model_name == "mean":
        return np.full(len(evaluation), float(train["future_excess_return"].mean()))
    if model_name != "ridge":
        raise ValueError(f"unknown model: {model_name}")
    # A tiny Ridge implementation keeps the teaching project runnable with
    # only numpy/pandas. The intercept is not penalized; feature scaling uses
    # training-window statistics only.
    mean = train[feature_columns].mean()
    scale = train[feature_columns].std(ddof=0).replace(0.0, 1.0)
    x_train = ((train[feature_columns] - mean) / scale).to_numpy(float)
    x_eval = ((evaluation[feature_columns] - mean) / scale).to_numpy(float)
    y_train = train["future_excess_return"].to_numpy(float)
    x_train = np.column_stack([np.ones(len(x_train)), x_train])
    x_eval = np.column_stack([np.ones(len(x_eval)), x_eval])
    penalty = np.eye(x_train.shape[1])
    penalty[0, 0] = 0.0
    coefficients = np.linalg.solve(x_train.T @ x_train + penalty, x_train.T @ y_train)
    return x_eval @ coefficients
