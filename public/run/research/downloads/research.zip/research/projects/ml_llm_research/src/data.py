"""Deterministic panel and filing-like text for the ML/LLM project."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


ASSETS = tuple(f"STOCK_{i:02d}" for i in range(1, 13))


@dataclass(frozen=True)
class DataConfig:
    start: str = "2014-01-01"
    periods: int = 132
    seed: int = 19


def make_panel(config: DataConfig | None = None) -> pd.DataFrame:
    """Create a monthly panel with market features, labels and dated text."""

    config = config or DataConfig()
    try:
        dates = pd.date_range(config.start, periods=config.periods, freq="ME", name="decision_date")
    except ValueError:  # pandas < 2.2 uses the older alias
        dates = pd.date_range(config.start, periods=config.periods, freq="M", name="decision_date")
    rng = np.random.default_rng(config.seed)
    rows: list[dict] = []
    persistent = np.zeros(len(ASSETS))

    for date_index, decision_date in enumerate(dates):
        common = rng.normal(0.0, 1.0)
        market_return = 0.02 * common + rng.normal(0.0, 0.01)
        persistent = 0.65 * persistent + rng.normal(0.0, 0.55, len(ASSETS))
        for asset_index, asset in enumerate(ASSETS):
            momentum = 0.35 * persistent[asset_index] + 0.25 * common + rng.normal(0, 0.25)
            volatility = abs(rng.normal(0.8, 0.18))
            volume_change = rng.normal(0.0, 1.0)
            beta = 0.5 + 0.08 * asset_index + rng.normal(0.0, 0.04)
            text_signal = 0.55 * momentum - 0.20 * volatility + rng.normal(0.0, 0.20)
            future_excess = 0.012 * momentum - 0.006 * volatility + 0.008 * text_signal + rng.normal(0, 0.045)
            published_at = decision_date - pd.Timedelta(2, unit="D")
            if text_signal > 0.25:
                text = "results are strong and outlook is improving, with lower uncertainty"
            elif text_signal < -0.25:
                text = "risk is elevated and outlook is weakening, with higher uncertainty"
            else:
                text = "results are mixed and the outlook remains uncertain"
            rows.append(
                {
                    "decision_date": decision_date,
                    "asset": asset,
                    "momentum": momentum,
                    "volatility": volatility,
                    "volume_change": volume_change,
                    "beta": beta,
                    "market_return": market_return,
                    "published_at": published_at,
                    "text": text,
                    "future_excess_return": future_excess,
                    "synthetic_text_signal": text_signal,
                    "date_index": date_index,
                }
            )
    return pd.DataFrame(rows)
