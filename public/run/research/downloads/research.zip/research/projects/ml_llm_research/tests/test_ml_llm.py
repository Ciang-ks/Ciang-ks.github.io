from __future__ import annotations

import json
import numpy as np
import pandas as pd
from pathlib import Path
from tempfile import TemporaryDirectory

from src.data import DataConfig, make_panel
from src.models import chronological_masks, split_dates
from src.run import main
from src.text_features import lexical_features


def test_panel_is_reproducible() -> None:
    assert make_panel(DataConfig()).equals(make_panel(DataConfig()))


def test_text_is_available_before_decision() -> None:
    panel = make_panel(DataConfig(periods=12))
    assert (pd.to_datetime(panel["published_at"]) < pd.to_datetime(panel["decision_date"])).all()


def test_splits_are_ordered_and_disjoint() -> None:
    panel = make_panel(DataConfig(periods=20))
    train_end, validation_end = split_dates(panel)
    masks = chronological_masks(panel, train_end, validation_end)
    assert masks["train"].sum() + masks["validation"].sum() + masks["test"].sum() == len(panel)
    assert train_end < validation_end
    assert not (masks["train"] & masks["test"]).any()


def test_lexical_features_are_finite() -> None:
    panel = make_panel(DataConfig(periods=8))
    features = lexical_features(panel["text"])
    assert np.isfinite(features.select_dtypes(include="number").to_numpy()).all()
    assert (features["text_length"] > 0).all()


def test_runner_keeps_validation_and_test_artifacts() -> None:
    with TemporaryDirectory() as directory:
        output_dir = Path(directory)
        main(output_dir=output_dir, data_config=DataConfig(periods=30))
        manifest = json.loads((output_dir / "run_manifest.json").read_text(encoding="utf-8"))
        predictions = pd.read_csv(output_dir / "predictions.csv")
        assert manifest["project"] == "ml_llm_research"
        assert {"validation", "test"}.issubset(set(predictions["split"]))
        assert (output_dir / "validation_metrics.json").exists()
