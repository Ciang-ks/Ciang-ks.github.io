# 项目 B：ML4Quant + LLM4Quant 增量研究

本项目模拟一个研究员把“市场特征 + 有发布时间的公司文本”转成横截面预测，并回答一个比“LLM 能不能预测股价”更可检验的问题：

> 在同一时间切分、标签、组合规则和交易成本下，文本特征是否在 market-only baseline 之外提供稳定的 out-of-sample 增量？

项目故意分层：先做均值和 market-only Ridge，再加入透明 lexical features，最后才运行本地 FinBERT semantic adapter。默认 panel 和 filing-like 文本是确定性合成数据，不是现实公司的披露或交易建议。

## 架构：从样本到交易指标

```text
src/data.py          → monthly panel、decision_date、published_at、future label
src/text_features.py → lexical schema、optional local HuggingFace adapter
src/models.py        → chronological split、train-only scaling、mean/Ridge
src/evaluate.py      → rank IC、top-bottom portfolio、turnover/cost/drawdown
src/run.py           → ablation orchestration and outputs/
tests/               → seed、time split、as-of text、model/metric invariants
reports/             → annotation sheet and research memo
```

四个模型使用同一训练/验证/测试边界和相同 top-bottom 规则：

1. `mean`：训练期标签均值；
2. `market_ridge`：momentum、volatility、volume_change、beta、market_return；
3. `market_lexical_ridge`：market + 情绪/风险/不确定性/文本长度；
4. `market_semantic_ridge`：market + lexical + FinBERT signed score（可选）。

评价顺序是 `rank IC → top-bottom gross/net → turnover/cost → drawdown/exposure → coverage/latency`。MSE 只作预测诊断，不能单独决定交易价值。

## 环境、依赖和运行

```bash
cd research
uv pip install -r projects/ml_llm_research/requirements.txt
source .venv/bin/activate
cd projects/ml_llm_research
python -m src.run
python tests/run_tests.py
python -m pytest -q
```

交互式入口是 [`project_lab.ipynb`](project_lab.ipynb)，使用 `qbasic-venv` kernel。它会画 test equity、成本敏感性，并检查 `published_at < decision_date`；示例图保存在 `reports/`。默认 lab 不调用语义模型。

也可以把结果写入一个全新的目录，避免覆盖默认输出：

```bash
python -m src.run --output-dir /tmp/ml-baseline
cat /tmp/ml-baseline/run_manifest.json
```

默认运行不访问网络，不加载模型。requirements 包含 `numpy`、`pandas`、`pytest`、`scikit-learn` 和 `transformers`；项目仍用透明 numpy Ridge，scikit-learn 供后续 milestone 对照。CPU 版 PyTorch 不写在普通 requirements 中，避免误装多 GB CUDA wheel；本地语义实验可使用：

```bash
uv pip install torch --index-url https://download.pytorch.org/whl/cpu
HF_HOME=../../.hf_cache \
TRANSFORMERS_CACHE=../../.hf_cache \
python -m src.run --semantic
```

可选语义分支支持 `ProsusAI/finbert`。缓存目录应加入 gitignore，不能把模型权重提交到仓库。当前合成文本上的重要结论是：semantic ridge 没有超过 lexical baseline；这是一个需要保留的负结果，不是失败的运行。

默认输出：

- `outputs/panel.csv`：decision date、asset、market features、text、label；
- `outputs/predictions.csv`：validation 与 test 的预测，`split` 列标明窗口；
- `outputs/metrics.json`：test 的 rank IC、平均 net、波动、回撤、换手；
- `outputs/validation_metrics.json`：同一模型在 validation 的摘要；
- `outputs/ablation.csv`：模型消融表；
- `outputs/run_manifest.json`：配置、切分边界和各产物 SHA-256。

Project B 现在确实保留 validation：模型只在 train fit，validation 用于研究选择，test 用于最后报告。项目与 Qlib/LEAN/vectorbt 的边界见 [`../ARCHITECTURE.md`](../ARCHITECTURE.md)。

## 标签和时间约束

每月 `t` 的 label 是未来一个月收益减去同日横截面均值：

```text
label(i,t) = future_return(i,t→t+1) - mean_i(future_return(i,t→t+1))
```

`published_at < decision_date` 的文本才可进入 `t` 的 feature。`period_of_report` 不等于 `published_at`；真实 SEC 适配时必须保留 accession/document hash、发布日期、修订版本和实体 ID。任何 embedding、词表、标准化、缺失填补都只能在训练窗口拟合。

## 六个 milestone（第二个项目日之后仍需完成验收）

### Milestone 0 — 任务合同与 label audit（30–45 分钟）

**上下文**：ML 项目最容易把“预测未来”写成一个训练集列名。先固定目标、horizon、决策时点和 primary trading metric。

**[STUDENT ACTION]**

1. 写出 market-only、lexical、semantic 三个 hypothesis，并明确每个的增量定义。
2. 手算一个资产、两个日期的 `future_excess_return` 和横截面去均值。
3. 画 `published_at → decision_date → future window → evaluation` 时间线。
4. 列出标签重叠、末月缺失、未来修订、重复文本和实体映射五个泄漏风险。

**[AGENT ACTION]**

- 逐列解释 `data.py` 的字段和合成机制，指出哪些列只能作为教学诊断，不能作为特征。
- 检查 label 是否严格在 decision date 之后，解释为什么不能用 `period_of_report` 代替发布时间。
- 帮助写测试，但要求学习者口头说明测试保护的经济含义。

**完成证据**：label data dictionary、时间线、泄漏清单和一项手工计算。

### Milestone 1 — Market-only baseline（45–60 分钟）

**上下文**：没有 baseline，就无法知道文本层是否提供增量；先用最简单模型建立地板。

**[STUDENT ACTION]**

1. 运行默认实验，确认 `mean` 和 `market_ridge` 都出现在 outputs。
2. 检查训练/验证/测试日期严格递增，报告各段日期和样本数。
3. 解释训练窗口均值/标准差为何只能用 train 拟合；手工构造一个全样本 scaling 的泄漏例子。
4. 比较 rank IC、top-bottom gross/net、turnover、drawdown；不要先看 MSE。
5. 设计一个 lagged momentum 或 cross-sectional rank 的单变量 baseline。

**[AGENT ACTION]**

- 检查 `split_dates`、`chronological_masks`、`fit_predict` 的边界和缺失处理。
- 解释 Ridge 的 bias–variance tradeoff 和 intercept 不惩罚的选择。
- 如果 baseline 很差，先排查标签、尺度和成本，不立即建议更复杂模型。

**完成证据**：baseline 表、日期边界审计、一个简单替代 baseline。

### Milestone 2 — Lexical text adapter（45–60 分钟）

**上下文**：词典特征可解释、快、容易审计，是语义模型不可跳过的对照。

**[STUDENT ACTION]**

1. 阅读 `text_features.py`，写出 positive/negative/uncertainty/length 每个字段的 schema、单位和缺失行为。
2. 随机抽样至少 20 条文本，人工核对计数和 signed sentiment；记录 false positive/false negative。
3. 比较 market-only 与 market+lexical 的 coverage、rank IC、成本后结果和分组稳定性。
4. 加入一个不会使用未来信息的文本变化特征（例如首次出现的风险词），明确其 as-of 规则。
5. 做 lexical ablation：去掉 uncertainty、只保留 sentiment、只保留长度。

**[AGENT ACTION]**

- 帮助确认文本处理是确定性、可缓存、可复现的；不直接把自然语言输出转成买卖指令。
- 检查同一文本是否跨 train/test 重复，解释为什么 document hash/事件去重重要。
- 审阅每个新增字段是否有经济理由和可执行的缺失策略。

**完成证据**：人工标注表、lexical schema、ablation 表和覆盖率统计。

### Milestone 3 — Semantic provider and model card（45–60 分钟）

**上下文**：FinBERT/Transformer 只是特征提供器，不能替代研究问题。要把模型、tokenizer、缓存、截断和标签映射固定下来。

**[STUDENT ACTION]**

1. 先不运行 semantic，写出预期增量、可能失败原因和资源预算。
2. 准备 CPU torch 和本地 HF cache，运行 `python -m src.run --semantic`。
3. 保存模型名、版本/缓存、推理设备、文本最大长度、耗时、失败文本数量和 label mapping。
4. 比较 semantic 的分类输出与人工 lexical 审计；检查 neutral、截断和空文本。
5. 解释为什么 semantic ridge 没有提高 rank IC 仍是有价值的研究结论。

**[AGENT ACTION]**

- 先确认默认路径仍可离线运行；模型下载失败必须显式报错，不能静默伪造结果。
- 审阅模型卡/许可证边界、cache 位置和输出 schema；不把模型置信度描述成收益概率。
- 运行相同切分、成本和 top-bottom 代码，确认语义实验只增加 feature。

**完成证据**：semantic run log、模型卡、一份 lexical vs semantic 人工对照和负结论段落。

### Milestone 4 — 时间序列验证、消融和稳健性（60–90 分钟）

**上下文**：文本模型常因覆盖率、重复事件和选择偏差看起来有效；只有严格 ablation 才能说明增量。

**[STUDENT ACTION]**

1. 固定 primary split，比较四个模型；再做一个滚动 train/test 或扩展窗口实验。
2. 对每个模型报告按日期的 IC、top-bottom spread、cost sensitivity 和 coverage。
3. 检查文本覆盖率低时是否只剩选择性样本；按文本缺失、行业/资产和波动状态分组。
4. 对重复文本做 hash 去重或事件聚合，比较去重前后结果。
5. 设定 deployment gate，例如 net spread 为正、IC 在多个窗口稳定、覆盖率超过阈值且成本压力下不消失。

**[AGENT ACTION]**

- 检查模型是否使用了测试期反复调参；若是，建议重新留出测试或做 paper-forward。
- 审阅指标是否同时包含预测与交易两层，指出 rank IC 和收益结论不一致的可能原因。
- 帮助把每个失败模式变成可运行的检查，而不是一句泛泛的 limitation。

**完成证据**：完整 ablation/稳健性矩阵、覆盖率图、deployment gate。

### Milestone 5 — 研究 memo、复现和面试表达（60–90 分钟）

**上下文**：成熟团队交付的是可复核的证据包：别人能按命令重建、知道你试过什么、理解负结果边界。

**[STUDENT ACTION]**

1. 完成 `reports/memo_template.md`：问题、数据、标签、模型、切分、结果、成本、风险、失败、合规和下一步。
2. 保存运行命令、seed、依赖版本、模型 cache、输出 hash 和未实现事项。
3. 写两个结论版本：文本有增量时怎样说，文本没有增量时怎样说；都必须带证据边界。
4. 用 90 秒讲清楚为什么 lexical 是必要 baseline、semantic 为什么不能直接替代它。
5. 设计一个真实 SEC/新闻数据扩展，只写 adapter/data contract，不把外部数据直接混入默认项目。

**[AGENT ACTION]**

- 检查每个 memo 数字是否可追溯到 `outputs/*.csv` 或 `metrics.json`。
- 做代码和研究审阅：时间、版本、异常、依赖、可复现性和失败结果是否完整。
- 给出面试追问和反例，要求学习者回答“如果成本翻倍/覆盖率下降/模型更新怎么办”。

**完成证据**：最终 memo、可复现命令、模型卡、失败分析和 90 秒讲稿。

## 行业资料映射：表达式审计和模型增量

WorldQuant BRAIN 公开界面中的 `field / universe / delay / decay / neutralization / coverage / turnover` 不是只适用于公式 alpha。对项目 B 的每个新增 feature/model，也要记录：

- 数据发布日期、修订版本和覆盖率（相当于 point-in-time field contract）；
- rolling/embedding/词表的训练窗口（相当于 transform/decay 配置）；
- 行业/市场 beta 中性化前后 IC、top-bottom net、turnover 和 exposure；
- stand-alone 与加入 market-only baseline 后的 marginal IC、marginal turnover 和压力结果。

这组记录与 Man AHL 的 data-to-production 视角、AQR 的跨资产分散视角和 Quant Wiki 的样本外/成本提醒相连。不要把平台特定的 `fitness` 当成通用目标函数，也不要把 semantic model 的置信度当成收益概率。表达式审计与模型增量见[机器学习讲义](../../lectures/07-machine-learning.ipynb)，交付边界见[研究表达](../../lectures/09-research-communication.ipynb)。

## 验收标准

- [ ] 默认路径不需要网络即可运行，`tests/run_tests.py` 和 `pytest` 通过；
- [ ] mean、market-only、lexical、semantic（若启用）使用同一时间切分和交易规则；
- [ ] 文本发布时间、测试隔离、train-only scaling、重复文本和 missing coverage 有证据；
- [ ] 同时报告预测指标和成本后交易指标；
- [ ] semantic 运行记录模型、版本、缓存、耗时和负结果，绝不把模型置信度当作收益概率；
- [ ] memo 不把合成文本或回测结果包装成真实公司/真实策略业绩。

## 推荐提高顺序

1. 增加 TF-IDF（只在 train fit vocabulary）并与词典特征比较；
2. 增加 purged/embargo split，处理重叠 horizon；
3. 真实公开 SEC 文本：先做 accession/hash/entity/time contract，再做特征；
4. 用小型 embedding 或事件 schema，保留 evidence span 和 unknown；
5. 最后才比较 LightGBM、PyTorch 或微调，且保持同一交易评价。
