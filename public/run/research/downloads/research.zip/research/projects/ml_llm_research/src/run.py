"""Command-line entry point for Project B."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from dataclasses import asdict
from pathlib import Path

import pandas as pd

from .data import DataConfig, make_panel
from .evaluate import summarize
from .models import chronological_masks, fit_predict, split_dates
from .text_features import OptionalHuggingFaceProvider, lexical_features, semantic_score


ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = ROOT / "outputs"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main(
    use_semantic: bool = False,
    *,
    output_dir: Path = OUTPUTS,
    data_config: DataConfig | None = None,
) -> dict[str, dict[str, float]]:
    """Run the pinned baseline and write test, validation, and manifest artifacts."""

    output_dir.mkdir(parents=True, exist_ok=True)
    data_config = data_config or DataConfig()
    panel = make_panel(data_config)
    text = lexical_features(panel["text"])
    panel = pd.concat([panel.reset_index(drop=True), text.reset_index(drop=True)], axis=1)
    if use_semantic:
        semantic = OptionalHuggingFaceProvider().transform(panel["text"])
        panel = pd.concat([panel.reset_index(drop=True), semantic.reset_index(drop=True)], axis=1)
        panel["semantic_feature"] = semantic_score(semantic).to_numpy()
    panel.to_csv(output_dir / "panel.csv", index=False)

    train_end, validation_end = split_dates(panel)
    masks = chronological_masks(panel, train_end, validation_end)
    train = panel.loc[masks["train"]].copy()
    validation = panel.loc[masks["validation"]].copy()
    test = panel.loc[masks["test"]].copy()

    market_features = ["momentum", "volatility", "volume_change", "beta", "market_return"]
    text_features = market_features + ["lexical_sentiment", "uncertainty_count", "text_length"]
    all_predictions: list[pd.DataFrame] = []
    metrics: dict[str, dict[str, float]] = {}
    validation_metrics: dict[str, dict[str, float]] = {}

    model_specs = [
        ("mean", market_features, "mean"),
        ("market_ridge", market_features, "ridge"),
        ("market_lexical_ridge", text_features, "ridge"),
    ]
    if use_semantic:
        model_specs.append(("market_semantic_ridge", text_features + ["semantic_feature"], "ridge"))

    for name, columns, model_name in model_specs:
        for split_name, split_frame in (("validation", validation), ("test", test)):
            predictions = fit_predict(train, split_frame, columns, model_name)
            evaluation = split_frame[["decision_date", "asset", "future_excess_return"]].copy()
            evaluation["split"] = split_name
            evaluation["model"] = name
            evaluation["prediction"] = predictions
            all_predictions.append(evaluation)
            if split_name == "validation":
                validation_metrics[name] = summarize(evaluation, cost_bps=10.0)
            else:
                metrics[name] = summarize(evaluation, cost_bps=10.0)

    predictions_frame = pd.concat(all_predictions, ignore_index=True)
    predictions_frame.to_csv(output_dir / "predictions.csv", index=False)
    pd.DataFrame(metrics).T.to_csv(output_dir / "ablation.csv", index_label="model")
    metrics_path = output_dir / "metrics.json"
    validation_metrics_path = output_dir / "validation_metrics.json"
    metrics_path.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    validation_metrics_path.write_text(json.dumps(validation_metrics, indent=2), encoding="utf-8")
    artifact_paths = [
        output_dir / "panel.csv",
        output_dir / "predictions.csv",
        output_dir / "ablation.csv",
        metrics_path,
        validation_metrics_path,
    ]
    manifest = {
        "project": "ml_llm_research",
        "config": {"data": asdict(data_config), "semantic": use_semantic, "cost_bps": 10.0},
        "split": {
            "train_end": str(train_end.date()),
            "validation_end": str(validation_end.date()),
            "test_start": str(pd.to_datetime(test["decision_date"]).min().date()),
        },
        "runtime": {"python": sys.version, "platform": platform.platform()},
    }
    manifest["artifacts"] = {
        path.name: {"bytes": path.stat().st_size, "sha256": _sha256(path)}
        for path in artifact_paths
    }
    (output_dir / "run_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))
    return metrics


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run the ML4Quant/LLM4Quant teaching experiment")
    parser.add_argument(
        "--semantic",
        action="store_true",
        help="use the optional local HuggingFace provider; default run stays network-free",
    )
    parser.add_argument("--output-dir", type=Path, default=OUTPUTS)
    parser.add_argument("--seed", type=int, default=DataConfig.seed)
    parser.add_argument("--start", default=DataConfig.start)
    parser.add_argument("--periods", type=int, default=DataConfig.periods)
    args = parser.parse_args()
    try:
        main(
            use_semantic=args.semantic,
            output_dir=args.output_dir,
            data_config=DataConfig(start=args.start, periods=args.periods, seed=args.seed),
        )
    except RuntimeError as error:
        print(f"语义层未运行：{error}", file=sys.stderr)
        raise SystemExit(2) from error
