"""Prediction and simple top-bottom portfolio metrics."""

from __future__ import annotations

import numpy as np
import pandas as pd


def rank_ic(frame: pd.DataFrame) -> float:
    grouped = frame.groupby("decision_date")
    values = []
    for _, group in grouped:
        if len(group) >= 3 and group["prediction"].nunique() > 1:
            # Ranking first avoids requiring scipy just to calculate Spearman
            # correlation; Pearson correlation of ranks is the same statistic.
            prediction_rank = group["prediction"].rank(method="average")
            outcome_rank = group["future_excess_return"].rank(method="average")
            values.append(prediction_rank.corr(outcome_rank))
    valid = [value for value in values if pd.notna(value)]
    return float(np.mean(valid)) if valid else 0.0


def top_bottom_returns(frame: pd.DataFrame, cost_bps: float = 10.0) -> pd.DataFrame:
    rows = []
    previous_weights: dict[str, float] = {}
    for date, group in frame.groupby("decision_date", sort=True):
        group = group.sort_values("prediction")
        half = max(1, len(group) // 3)
        short = group.head(half)
        long = group.tail(half)
        weights = {asset: 1.0 / len(long) for asset in long["asset"]}
        weights.update({asset: -1.0 / len(short) for asset in short["asset"]})
        turnover = sum(abs(weights.get(asset, 0.0) - previous_weights.get(asset, 0.0)) for asset in set(weights) | set(previous_weights))
        gross = float(long["future_excess_return"].mean() - short["future_excess_return"].mean())
        net = gross - turnover * cost_bps / 10_000.0
        rows.append({"decision_date": date, "gross": gross, "turnover": turnover, "net": net})
        previous_weights = weights
    return pd.DataFrame(rows)


def summarize(frame: pd.DataFrame, cost_bps: float = 10.0) -> dict[str, float]:
    portfolio = top_bottom_returns(frame, cost_bps=cost_bps)
    if portfolio.empty:
        return {"rank_ic": 0.0, "average_net": 0.0, "net_vol": 0.0, "max_drawdown": 0.0}
    equity = (1.0 + portfolio["net"]).cumprod()
    drawdown = equity / equity.cummax().clip(lower=1.0) - 1.0
    return {
        "rank_ic": rank_ic(frame),
        "average_net": float(portfolio["net"].mean()),
        "net_vol": float(portfolio["net"].std(ddof=1)) if len(portfolio) > 1 else 0.0,
        "max_drawdown": float(drawdown.min()),
        "average_turnover": float(portfolio["turnover"].mean()),
    }
