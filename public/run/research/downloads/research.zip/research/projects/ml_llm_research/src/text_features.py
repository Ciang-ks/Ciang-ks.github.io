"""Transparent text features plus an optional local semantic adapter."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


POSITIVE = {"strong", "improving", "lower"}
NEGATIVE = {"risk", "elevated", "weakening", "higher"}
UNCERTAINTY = {"uncertain", "uncertainty", "mixed"}


def lexical_features(texts: pd.Series) -> pd.DataFrame:
    """Extract deterministic features that are easy to audit."""

    def score(text: str, words: set[str]) -> int:
        tokens = set(str(text).lower().replace(",", "").split())
        return len(tokens & words)

    result = pd.DataFrame(index=texts.index)
    result["positive_count"] = texts.map(lambda value: score(value, POSITIVE))
    result["negative_count"] = texts.map(lambda value: score(value, NEGATIVE))
    result["uncertainty_count"] = texts.map(lambda value: score(value, UNCERTAINTY))
    result["text_length"] = texts.fillna("").map(lambda value: len(str(value).split()))
    result["lexical_sentiment"] = result["positive_count"] - result["negative_count"]
    return result


@dataclass
class OptionalHuggingFaceProvider:
    """Optional adapter boundary; never required for the default experiment."""

    model_name: str = "ProsusAI/finbert"

    def transform(self, texts: pd.Series) -> pd.DataFrame:
        try:
            from transformers import pipeline
        except ImportError as error:  # pragma: no cover - optional dependency
            raise RuntimeError(
                "可选语义层需要安装 transformers，并在本地准备模型；默认实验请先使用 lexical_features。"
            ) from error

        classifier = pipeline("text-classification", model=self.model_name)
        outputs = classifier(texts.tolist(), truncation=True)
        return pd.DataFrame(
            {
                "semantic_label": [item["label"] for item in outputs],
                "semantic_score": [float(item["score"]) for item in outputs],
            },
            index=texts.index,
        )


def semantic_score(frame: pd.DataFrame) -> pd.Series:
    """Map a classifier's structured label/score to a signed feature."""

    signs = frame["semantic_label"].str.lower().map(
        lambda label: 1.0 if "positive" in label else (-1.0 if "negative" in label else 0.0)
    )
    return signs * frame["semantic_score"].astype(float)
