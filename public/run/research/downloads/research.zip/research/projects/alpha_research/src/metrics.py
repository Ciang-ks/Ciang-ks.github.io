"""Small metrics module kept deliberately transparent."""

from __future__ import annotations

import numpy as np
import pandas as pd


def summarize(returns: pd.Series) -> dict[str, float]:
    """Summarize a daily return series with finite, JSON-friendly numbers."""

    returns = returns.dropna().astype(float)
    if returns.empty:
        return {"annual_return": 0.0, "annual_volatility": 0.0, "sharpe": 0.0, "max_drawdown": 0.0}
    periods = len(returns)
    equity = (1.0 + returns).cumprod()
    years = periods / 252.0
    annual_return = float(equity.iloc[-1] ** (1.0 / years) - 1.0) if years > 0 else 0.0
    annual_vol = float(returns.std(ddof=1) * np.sqrt(252)) if periods > 1 else 0.0
    sharpe = annual_return / annual_vol if annual_vol > 0 else 0.0
    drawdown = equity / equity.cummax() - 1.0
    return {
        "annual_return": annual_return,
        "annual_volatility": annual_vol,
        "sharpe": float(sharpe),
        "max_drawdown": float(drawdown.min()),
        "average_daily_return": float(returns.mean()),
    }
