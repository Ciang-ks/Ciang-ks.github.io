from __future__ import annotations

import json
import numpy as np
import pandas as pd
from pathlib import Path
from tempfile import TemporaryDirectory

from src.backtest import run_backtest
from src.data import DataConfig, make_prices
from src.features import make_features, signal_to_weights
from src.run import main
from src.metrics import summarize


def test_data_is_reproducible() -> None:
    assert make_prices(DataConfig()).equals(make_prices(DataConfig()))


def test_weights_respect_single_asset_cap() -> None:
    prices = make_prices(DataConfig(end="2012-12-31"))
    features = make_features(prices)
    weights = signal_to_weights(features["momentum"], features["volatility"])
    assert float(weights.abs().max().max()) <= 0.25 + 1e-12


def test_previous_period_weights_prevent_same_day_signal() -> None:
    prices = make_prices(DataConfig(end="2012-12-31"))
    features = make_features(prices)
    weights = signal_to_weights(features["momentum"], features["volatility"])
    result = run_backtest(prices, weights, cost_bps=0.0)
    assert np.isfinite(result["net_return"]).all()
    assert result.iloc[0]["gross_return"] == 0.0


def test_more_cost_cannot_improve_net_equity() -> None:
    prices = make_prices(DataConfig(end="2012-12-31"))
    features = make_features(prices)
    weights = signal_to_weights(features["momentum"], features["volatility"])
    low = run_backtest(prices, weights, cost_bps=10.0)
    high = run_backtest(prices, weights, cost_bps=50.0)
    assert high["net_return"].sum() <= low["net_return"].sum() + 1e-12


def test_initial_purchase_is_not_free() -> None:
    dates = pd.date_range("2020-01-01", periods=2)
    prices = pd.DataFrame({"asset": [100.0, 100.0]}, index=dates)
    weights = pd.DataFrame({"asset": [1.0, 1.0]}, index=dates)
    result = run_backtest(prices, weights, cost_bps=10)
    assert np.isclose(result["net_return"].iloc[0], -0.001)
    assert result["turnover"].iloc[1] == 0


def test_first_loss_counts_as_drawdown_from_initial_capital() -> None:
    metrics = summarize(pd.Series([-0.10, 0.0]))
    assert np.isclose(metrics["max_drawdown"], -0.10)


def test_zero_compound_return_can_have_positive_arithmetic_sharpe() -> None:
    # Losing half and then doubling recovers capital, with positive arithmetic mean.
    metrics = summarize(pd.Series([-0.5, 1.0]))
    assert np.isclose(metrics["annual_return"], 0.0)
    assert metrics["sharpe"] > 0


def test_runner_writes_auditable_manifest() -> None:
    with TemporaryDirectory() as directory:
        output_dir = Path(directory)
        main(output_dir=output_dir, data_config=DataConfig(end="2011-12-31"))
        manifest = json.loads((output_dir / "run_manifest.json").read_text(encoding="utf-8"))
        assert manifest["project"] == "alpha_research"
        assert "prices.csv" in manifest["artifacts"]
        assert (output_dir / "metrics.json").exists()
