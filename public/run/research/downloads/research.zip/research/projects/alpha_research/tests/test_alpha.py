from __future__ import annotations

import json
import numpy as np
from pathlib import Path
from tempfile import TemporaryDirectory

from src.backtest import run_backtest
from src.data import DataConfig, make_prices
from src.features import make_features, signal_to_weights
from src.run import main


def test_data_is_reproducible() -> None:
    assert make_prices(DataConfig()).equals(make_prices(DataConfig()))


def test_weights_respect_single_asset_cap() -> None:
    prices = make_prices(DataConfig(end="2012-12-31"))
    features = make_features(prices)
    weights = signal_to_weights(features["momentum"], features["volatility"])
    assert float(weights.abs().max().max()) <= 0.25 + 1e-12


def test_previous_period_weights_prevent_same_day_signal() -> None:
    prices = make_prices(DataConfig(end="2012-12-31"))
    features = make_features(prices)
    weights = signal_to_weights(features["momentum"], features["volatility"])
    result = run_backtest(prices, weights, cost_bps=0.0)
    assert np.isfinite(result["net_return"]).all()
    assert result.iloc[0]["gross_return"] == 0.0


def test_more_cost_cannot_improve_net_equity() -> None:
    prices = make_prices(DataConfig(end="2012-12-31"))
    features = make_features(prices)
    weights = signal_to_weights(features["momentum"], features["volatility"])
    low = run_backtest(prices, weights, cost_bps=10.0)
    high = run_backtest(prices, weights, cost_bps=50.0)
    assert high["net_return"].sum() <= low["net_return"].sum() + 1e-12


def test_runner_writes_auditable_manifest() -> None:
    with TemporaryDirectory() as directory:
        output_dir = Path(directory)
        main(output_dir=output_dir, data_config=DataConfig(end="2011-12-31"))
        manifest = json.loads((output_dir / "run_manifest.json").read_text(encoding="utf-8"))
        assert manifest["project"] == "alpha_research"
        assert "prices.csv" in manifest["artifacts"]
        assert (output_dir / "metrics.json").exists()
