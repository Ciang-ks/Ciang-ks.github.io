"""Command-line entry point for Project A."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
from pathlib import Path
import sys
from dataclasses import asdict

from .backtest import run_backtest
from .data import DataConfig, make_prices
from .features import make_features, signal_to_weights
from .metrics import summarize


ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = ROOT / "outputs"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main(
    *,
    output_dir: Path = OUTPUTS,
    data_config: DataConfig | None = None,
    lookback: int = 60,
    rebalance_every: int = 20,
    max_abs_weight: float = 0.25,
) -> dict[str, dict[str, float]]:
    """Run the pinned teaching baseline and write an auditable output bundle."""

    output_dir.mkdir(parents=True, exist_ok=True)
    data_config = data_config or DataConfig()
    prices = make_prices(data_config)
    features = make_features(prices, lookback=lookback)
    weights = signal_to_weights(
        features["momentum"],
        features["volatility"],
        rebalance_every=rebalance_every,
        max_abs_weight=max_abs_weight,
    )

    strategies: dict[str, dict] = {}
    for cost_bps in (0.0, 10.0, 25.0, 50.0):
        result = run_backtest(prices, weights, cost_bps=cost_bps)
        result.to_csv(output_dir / f"portfolio_{int(cost_bps)}bps.csv", index_label="date")
        strategies[f"trend_{int(cost_bps)}bps"] = summarize(result["net_return"])

    benchmark_weights = weights.copy()
    benchmark_weights.loc[:, :] = 1.0 / len(benchmark_weights.columns)
    benchmark = run_backtest(prices, benchmark_weights, cost_bps=10.0)
    strategies["equal_weight_10bps"] = summarize(benchmark["net_return"])

    prices.to_csv(output_dir / "prices.csv", index_label="date")
    weights.to_csv(output_dir / "weights.csv", index_label="date")
    benchmark.to_csv(output_dir / "benchmark_10bps.csv", index_label="date")
    metrics_path = output_dir / "metrics.json"
    metrics_path.write_text(json.dumps(strategies, indent=2), encoding="utf-8")
    artifact_paths = [
        output_dir / "prices.csv",
        output_dir / "weights.csv",
        output_dir / "benchmark_10bps.csv",
        *(output_dir / f"portfolio_{int(cost_bps)}bps.csv" for cost_bps in (0.0, 10.0, 25.0, 50.0)),
        metrics_path,
    ]

    manifest = {
        "project": "alpha_research",
        "config": {
            "data": asdict(data_config),
            "lookback": lookback,
            "rebalance_every": rebalance_every,
            "max_abs_weight": max_abs_weight,
            "cost_bps": [0.0, 10.0, 25.0, 50.0],
            "benchmark_cost_bps": 10.0,
        },
        "runtime": {"python": sys.version, "platform": platform.platform()},
        "metrics_file": metrics_path.name,
    }
    manifest["artifacts"] = {
        path.name: {"bytes": path.stat().st_size, "sha256": _sha256(path)}
        for path in artifact_paths
    }
    (output_dir / "run_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print(json.dumps(strategies, indent=2))
    return strategies


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run the deterministic Project A baseline")
    parser.add_argument("--output-dir", type=Path, default=OUTPUTS)
    parser.add_argument("--seed", type=int, default=DataConfig.seed)
    parser.add_argument("--start", default=DataConfig.start)
    parser.add_argument("--end", default=DataConfig.end)
    parser.add_argument("--lookback", type=int, default=60)
    parser.add_argument("--rebalance-every", type=int, default=20)
    parser.add_argument("--max-abs-weight", type=float, default=0.25)
    args = parser.parse_args()
    main(
        output_dir=args.output_dir,
        data_config=DataConfig(start=args.start, end=args.end, seed=args.seed),
        lookback=args.lookback,
        rebalance_every=args.rebalance_every,
        max_abs_weight=args.max_abs_weight,
    )
