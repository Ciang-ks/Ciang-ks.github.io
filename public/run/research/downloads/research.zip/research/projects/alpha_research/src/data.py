"""Deterministic teaching data for the cross-asset project.

The generator deliberately has simple, inspectable dynamics. It is not a
historical market data replacement.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


ASSETS = (
    "EQUITY",
    "BOND",
    "INFLATION",
    "GOLD",
    "COMMODITY",
    "REAL_ESTATE",
    "USD",
    "CRYPTO",
)


@dataclass(frozen=True)
class DataConfig:
    start: str = "2010-01-01"
    end: str = "2024-12-31"
    seed: int = 7


def make_prices(config: DataConfig | None = None) -> pd.DataFrame:
    """Create reproducible business-day prices for teaching and tests."""

    config = config or DataConfig()
    dates = pd.bdate_range(config.start, config.end, name="date")
    rng = np.random.default_rng(config.seed)
    n = len(dates)

    # A slowly changing common state creates interpretable regimes. The
    # previous return term gives the trend signal something to inspect.
    state = np.sign(np.sin(np.arange(n) / 170.0))
    market = 0.00018 * state + rng.normal(0.0, 0.007, n)
    rates = rng.normal(0.0, 0.004, n) - 0.00012 * state
    real_assets = rng.normal(0.0, 0.006, n) + 0.00008 * state
    factors = np.column_stack([market, rates, real_assets])

    betas = np.array(
        [
            [1.00, -0.10, 0.40],
            [-0.25, -0.80, -0.10],
            [0.00, -0.45, 0.15],
            [0.15, 0.05, 0.80],
            [0.35, 0.10, 0.70],
            [0.80, -0.25, 0.35],
            [-0.10, 0.45, -0.20],
            [1.20, 0.00, 0.55],
        ]
    )
    noise_scale = np.array([0.006, 0.003, 0.0035, 0.008, 0.009, 0.007, 0.003, 0.018])
    drift = np.array([0.00020, 0.00010, 0.00008, 0.00012, 0.00014, 0.00015, 0.00003, 0.00035])

    returns = np.empty((n, len(ASSETS)))
    previous = np.zeros(len(ASSETS))
    for t in range(n):
        innovation = drift + factors[t] @ betas.T + rng.normal(0.0, noise_scale)
        # A small autoregressive term is transparent and creates a non-trivial
        # but not guaranteed trend signal.
        previous = 0.12 * previous + innovation
        returns[t] = previous

    prices = 100.0 * np.exp(np.cumsum(returns, axis=0))
    return pd.DataFrame(prices, index=dates, columns=ASSETS)
