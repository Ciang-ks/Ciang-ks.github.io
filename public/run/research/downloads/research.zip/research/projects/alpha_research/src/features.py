"""Feature and target-weight construction."""

from __future__ import annotations

import numpy as np
import pandas as pd


def make_features(prices: pd.DataFrame, lookback: int = 60) -> dict[str, pd.DataFrame]:
    """Return lagged momentum, daily returns, and rolling annualized volatility."""

    returns = prices.pct_change()
    momentum = prices.pct_change(lookback)
    volatility = returns.rolling(lookback, min_periods=lookback).std() * np.sqrt(252)
    return {"returns": returns, "momentum": momentum, "volatility": volatility}


def signal_to_weights(
    momentum: pd.DataFrame,
    volatility: pd.DataFrame,
    rebalance_every: int = 20,
    max_abs_weight: float = 0.25,
) -> pd.DataFrame:
    """Convert a signal into capped target weights.

    The function only creates a new target on rebalance dates. The returned
    weights are the positions held during each date; the backtest shifts them
    once more before applying that day's returns.
    """

    scaled = momentum / volatility.replace(0.0, np.nan)
    scaled = scaled.replace([np.inf, -np.inf], np.nan)
    targets = pd.DataFrame(np.nan, index=momentum.index, columns=momentum.columns)

    for row_number in range(0, len(momentum), rebalance_every):
        raw = scaled.iloc[row_number].dropna()
        if raw.empty or float(raw.abs().sum()) == 0.0:
            continue
        weights = (raw / raw.abs().sum()).clip(-max_abs_weight, max_abs_weight)
        targets.loc[momentum.index[row_number], weights.index] = weights

    # No position before the first valid target; after a target, hold it until
    # the next rebalance. Holding is explicit so the execution rule is visible.
    return targets.ffill().fillna(0.0)
