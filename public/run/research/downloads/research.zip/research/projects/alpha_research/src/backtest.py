"""Simple, explicit portfolio accounting."""

from __future__ import annotations

import pandas as pd


def run_backtest(
    prices: pd.DataFrame,
    weights: pd.DataFrame,
    cost_bps: float = 10.0,
) -> pd.DataFrame:
    """Compute gross/net returns with previous-period weights and turnover cost."""

    asset_returns = prices.pct_change().fillna(0.0)
    held_weights = weights.shift(1).fillna(0.0)
    gross = (held_weights * asset_returns).sum(axis=1)
    turnover = weights.diff().abs().sum(axis=1)
    if not weights.empty:
        # The account starts in cash, so its initial target is also a trade.
        turnover.iloc[0] = weights.iloc[0].abs().sum()
    cost = turnover * (cost_bps / 10_000.0)
    net = gross - cost

    result = pd.DataFrame(index=prices.index)
    result["gross_return"] = gross
    result["turnover"] = turnover
    result["cost"] = cost
    result["net_return"] = net
    result["equity"] = (1.0 + net).cumprod()
    result["gross_equity"] = (1.0 + gross).cumprod()
    return result
