# 项目 A：跨资产 Alpha 与组合研究

本项目模拟一名量化研究员从一个可解释假设出发，完成 `data → feature → signal → portfolio → execution → risk → report` 的最小全链路。它专门训练 quant research/trading 面试中最常被追问的部分：信息何时可得、预测如何变成仓位、成本如何改变结论、收益到底来自哪里。

默认数据是八个教学资产的确定性合成日频价格（股票、债券、通胀债、黄金、商品、房地产、美元、加密的风险代理），不是历史行情，也不是投资建议。默认路径不访问网络、不需要 API key；真实数据扩展必须另建适配器并保留本项目的时间和会计不变量。

## 研究问题和明确假设

> 只使用过去价格的跨资产趋势信号，能否相对同一 universe 的等权 benchmark 提供样本外、成本后的增量？它在哪些市场状态失败？

默认假设：

- 观察窗口：60 个交易日 momentum；
- 交易频率：每 20 个交易日重新计算一次目标权重；
- 风险缩放：`momentum / rolling_volatility`，再做绝对权重上限；
- 执行：信号在日期 `t` 形成，`t+1` 才使用该目标权重获得收益；
- 成本：`turnover × cost_bps`，比较 0、10、25、50 bps；
- benchmark：同一资产集合的等权持有；
- primary metrics：net return、annualized volatility、Sharpe、maximum drawdown、turnover；gross 结果只作诊断。

这组假设是教学起点，不是“正确答案”。每次改变都必须写成一项实验，说明为什么改变、改变了哪一层、预期影响是什么。

## 架构和文件职责

```text
src/data.py       → 可复现价格和 DataConfig
src/features.py   → returns、momentum、rolling volatility、target weights
src/backtest.py   → previous-period weights、gross/net、turnover、equity
src/metrics.py    → annual return/volatility、Sharpe、drawdown
src/run.py        → 编排实验并写入 outputs/
tests/             → 研究不变量（时间、权重、成本、seed）
reports/           → 学习者 memo 和图表
```

不要把所有逻辑移入 `run.py`。数据、特征、交易会计和指标拆开，是为了让面试官可以逐层检查，也让一个 bug 有明确归属。

## 环境和运行

```bash
cd research
uv venv --python 3.13 .venv   # 已有环境可跳过
uv pip install -r projects/alpha_research/requirements.txt
source .venv/bin/activate
cd projects/alpha_research
python -m src.run
python tests/run_tests.py
python -m pytest -q
```

交互式入口是 [`project_lab.ipynb`](project_lab.ipynb)，使用 `qbasic-venv` kernel。它会生成 equity、cost sensitivity 和 exposure 图，并把一次完整 baseline 写到 `reports/lab_alpha_outputs/`；这些运行产物可删除后重新生成。

也可以把结果写入一个全新的目录，避免覆盖默认输出：

```bash
python -m src.run --output-dir /tmp/alpha-baseline
cat /tmp/alpha-baseline/run_manifest.json
```

项目当前共享的 `research/.venv` 已安装 `numpy`、`pandas`、`pytest`。如果重建环境，requirements 会显式安装它们。默认输出：

- `outputs/prices.csv`：价格；
- `outputs/weights.csv`：每天记录的 target/held schedule；收益计算在 `backtest.py` 中再使用上一期权重；
- `outputs/portfolio_0bps.csv`、`portfolio_10bps.csv`、`portfolio_25bps.csv`、`portfolio_50bps.csv`：gross/net、换手、成本和净值；
- `outputs/benchmark_10bps.csv`：等权 benchmark；
- `outputs/metrics.json`：所有策略的摘要；
- `outputs/run_manifest.json`：本次配置、运行时和各产物 SHA-256。

`run.py` 的输出目录和关键参数都可以通过 CLI 改变；默认参数仍然固定，便于面试前复现。项目与 Qlib/LEAN/vectorbt 的边界见 [`../ARCHITECTURE.md`](../ARCHITECTURE.md)。

## 六个 milestone（项目用两天完成，但必须逐项留下证据）

### Milestone 0 — 研究合同和手工验算（30–45 分钟）

**上下文**：成熟团队在写代码前先冻结研究问题、交易时点、benchmark 和主指标。否则运行结果出来后会无意识地改问题。

**[STUDENT ACTION]**

1. 在 `reports/memo.md` 开头写出研究问题、经济直觉、universe、horizon、decision time、benchmark、成本区间和 primary metric。
2. 画一条时间线：`prices through t → signal at t → target weight at t → fill/hold at t+1 → PnL`。
3. 手算三资产、两期的 turnover 和成本，并写出如果删除 `weights.shift(1)` 会产生什么前视偏差。
4. 选择 daily/weekly/monthly rebalance 之一，写出响应速度、噪声、成本的取舍。

**[AGENT ACTION]**

- 解释 `src/` 中每个模块的输入/输出和不变量，不替学习者选参数。
- 检查 memo 是否把 signal、target position、order、fill 混为同一概念。
- 只指出需要验证的风险；不要根据默认结果替学习者宣布策略成功。

**完成证据**：一页研究合同 + 手工 turnover 计算 + 时间线图或文字图。

### Milestone 1 — 数据、单位和特征审计（45–60 分钟）

**上下文**：合成数据虽简单，但真实研究最常见的错误就是收益单位、交易日、缺失窗口和价格调整。

**[STUDENT ACTION]**

1. 阅读 `data.py` 和 `features.py`，列出每个字段的单位、频率和可见时点。
2. 检查 seed 相同是否逐字节复现；检查价格是否正、日期是否单调、列名是否唯一。
3. 对 60 日窗口回答：第一个有效 momentum/volatility 日期是哪天？窗口不足时为什么不能用未来填补？
4. 画一张价格（建议对数轴）、一张日收益和一张滚动波动图；标记波动状态变化。
5. 记录至少三个真实数据会失效的假设：复权、退市、期货换月、时区、停牌或流动性。

**[AGENT ACTION]**

- 运行现有测试并解释每个断言保护的研究不变量。
- 审查是否存在 `bfill`、全样本均值或未来收益进入 feature 的路径。
- 帮助定位 shape/index 错误，但要求学习者说明修复后的经济含义。

**完成证据**：data dictionary、三张图、seed/日期/缺失审计笔记。

### Milestone 2 — 信号、权重和暴露（45–60 分钟）

**上下文**：同一 alpha 分数可以经过不同标准化、波动缩放和权重约束，变成完全不同的交易组合。

**[STUDENT ACTION]**

1. 逐行解释 `momentum / volatility → normalized weights → cap → forward fill`。
2. 检查每个日期的单名权重是否满足 `|w_i|≤0.25`，gross exposure、net exposure 和资产集中度如何变化。
3. 比较 raw momentum、横截面 rank 和 inverse-vol 三种 mapping；一次只改一个因素。
4. 对 `rebalance_every=20` 和 `60` 做 ablation，报告信号变化、换手和成本后的结果。
5. 画目标权重、gross/net exposure 和各资产平均绝对权重。

**[AGENT ACTION]**

- 用小型三资产例子演示 cap 为什么可能改变权重和总 gross exposure。
- 检查 `weights` 是 target/held position 还是 order，确认回测中的 shift 与定义一致。
- 审阅实验是否保留了相同日期、资产和成本，避免“同时改了三件事”。

**完成证据**：`weights` 审计表 + 两个窗口的对照表 + 暴露图。

### Milestone 3 — 回测会计与成本压力（45–60 分钟）

**上下文**：研究收益只有在说明成交时点、换手和成本后才具有交易含义。

**[STUDENT ACTION]**

1. 运行四种成本；确认成本提高不能提高净收益，且成本差异等于 turnover 乘 bps。
2. 同时报告 gross/net return、equity、最大回撤、恢复时间、平均和 P95 turnover。
3. 写出 market order、limit order、TWAP、VWAP、POV、implementation shortfall 的适用条件。
4. 增加一个简单的 `order/ADV` 非线性成本实验（可在新模块中实现），比较线性 bps 的偏差。
5. 解释 `turnover` 首日为何不是零，以及初始化仓位会怎样影响首期成本。

**[AGENT ACTION]**

- 逐项检查 `backtest.py` 的 previous-period weights、asset returns、cost 和 equity 公式。
- 用 Almgren–Chriss 的临时/永久冲击直觉解释实验，不把线性成本称为最优执行。
- 若结果异常，先检查索引、单位和交易时点，再讨论模型改进。

**完成证据**：成本敏感性表、净值/回撤图、执行假设段落。

### Milestone 4 — Benchmark、归因和失败状态（45–60 分钟）

**上下文**：高 Sharpe 可能只是市场 beta、某个资产、某一年或低成本假设的产物。

**[STUDENT ACTION]**

1. 把趋势组合和等权 benchmark 放在同一张图和同一张指标表。
2. 按年份、资产、趋势状态和波动状态拆分收益；报告每组样本量。
3. 对策略净收益回归或相关分析至少两个简单风险因子，讨论 beta 与 alpha 的区别。
4. 设计三个失败解释：趋势反转、流动性冲击、资产相关性上升；为每个解释写一个可执行的检查。
5. 写出“结果不支持部署”的条件，例如成本超过 25 bps、回撤超过阈值或只剩单一资产贡献。

**[AGENT ACTION]**

- 防止把合成数据中的设定机制误写成真实市场规律。
- 帮助区分 benchmark-relative alpha、absolute return 和风险溢价。
- 审阅分组是否事后挑选；要求保留完整的失败分组。

**完成证据**：benchmark/归因表、失败样本、停止/继续规则。

### Milestone 5 — 稳健性矩阵与研究 memo（60–90 分钟）

**上下文**：成熟研究交付需要别人能复现“你尝试过什么”，而不只是看到最后一张漂亮曲线。

**[STUDENT ACTION]**

1. 固定一个 primary specification，再做 lookback、rebalance、cap、cost、资产子集的二维或三维矩阵。
2. 记录每一次实验的配置、运行命令、输出文件和结论；不要删除不好的结果。
3. 完成 `reports/memo_template.md`：问题、数据、方法、结果、成本、风险、失败、局限和下一步。
4. 用 90 秒回答：为什么这个 signal 可能存在？为什么你的回测没有前视？结果在哪些成本和状态下成立？
5. 把所有随机性、版本和未实现的真实数据工程列入 limitations。

**[AGENT ACTION]**

- 检查 memo 中每个数字是否能追溯到一个 CSV/JSON 输出。
- 做代码审阅：模块边界、命名、异常输入、测试覆盖和可复现命令。
- 提供面试追问清单，但不替学习者写经济结论。

**完成证据**：最终 memo、稳健性矩阵、可复现运行记录和 90 秒口述稿。

## 行业资料映射：只增加四个可运行检查

这些检查把 Man AHL、AQR、WorldQuant BRAIN 和 Quant Wiki 的公开启发落到项目中，不要求复刻任何公司的内部系统：

1. **Alpha decay**：对 20/60/120 日 momentum 计算不同持有期的 IC 和 top-bottom spread，画衰减曲线；固定 primary horizon，不能挑最好的一条曲线。
2. **Breadth/相关性**：计算各资产 signal-return correlation、组合有效下注数和压力期相关性；解释为什么 8 个资产不等于 8 个独立机会。
3. **TCA**：把 `turnover × bps` 拆成 spread、fee、impact、delay/opportunity cost 的教学表，并增加 `order/ADV` 压力情景；原有线性成本保留为单元测试 baseline。
4. **Production gate**：在 memo 中增加 `data → signal → portfolio → replay → paper/shadow → monitoring` 的 gate 表，写出成本翻倍、覆盖率下降、相关性上升时的停止条件。

对应概念的定义和资料边界见仓库根目录的 `sources/external/text/industry_workflow_notes.md`。

## 验收标准

- [ ] `python tests/run_tests.py` 和 `python -m pytest -q` 通过；
- [ ] seed、日期、权重上限、上一期持仓和成本单调性有测试或手工证据；
- [ ] 至少 2 个窗口/信号变体、4 个成本、1 个 benchmark；
- [ ] 报告同时包含 gross/net、turnover、drawdown、exposure、样本外/分组结果；
- [ ] 不把合成数据、简化成本或历史回测写成真实可投资结论。

## 推荐提高顺序

1. 用同样接口接入公开 ETF 数据，先写 schema、时区、复权和缺失审计；
2. 加入非线性冲击和容量近似，比较 `order/ADV`；
3. 做行业/市场 beta 中性化和 factor attribution；
4. 加入 purged/embargo 时间验证和滚动训练；
5. 只有在 baseline 和成本审计完成后，才尝试更复杂的 portfolio optimizer。
