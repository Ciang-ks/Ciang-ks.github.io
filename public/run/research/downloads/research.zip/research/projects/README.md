# 教学项目：把讲义中的小例子接成研究实验

讲义用少量数据解释一件事，项目则要求你让多个步骤同时成立。两个项目都遵循“数据 → 特征 → 预测或信号 → 权重 → 成本 → 报告”，每一步保留显式输入输出。你可以沿同一个日期和资产逐列追踪，判断结果变化来自数据、模型、交易还是指标。

| 项目 | 主线问题 | 默认数据 | 建议先读 |
|---|---|---|---|
| [项目 A：跨资产 Alpha](alpha_research/README.md) | 过去价格形成的趋势信号，经过风险缩放和成本后还剩什么？ | 八个教学资产的合成日频价格 | 第一至六章 |
| [项目 B：ML/LLM 增量](ml_llm_research/README.md) | 同样的标签与交易规则下，文本能否超过市场特征？ | 十二只教学股票的合成月度表与模板公告 | 第三、四、七、八章 |

先运行固定基线，再选一行手工复算，最后只改变一个研究选择。例如项目 A 把再平衡从每 20 日改为每 5 日，应先预期信号反应和换手怎样变化，再查看成本后的结果；项目 B 加入文本时，应先冻结样本、日期和组合规则，避免把覆盖率变化误认为模型增量。

两个项目的 `project_lab.ipynb` 把这些过程展开成连续实验，手工题附折叠答案。README 说明默认实现、近似与进一步的工程选择。合成数据中存在的机制由生成器设定，不能作为现实 alpha 的证据。

## 环境与批量运行

从仓库根目录执行：

```bash
uv venv --python 3.13 research/.venv
uv pip install --python research/.venv/bin/python -r research/requirements-notebooks.txt -r research/projects/alpha_research/requirements.txt -r research/projects/ml_llm_research/requirements.txt
research/.venv/bin/python research/projects/run_all.py --output-root /tmp/research-baseline
```

已有环境可以跳过创建。命令将两个项目的 CSV、指标与配置写入各自输出目录；单独运行仍是定位问题最方便的方式。Notebook 负责逐步探索，`src/` 保存可复用函数，`tests/` 保护时间、权重与成本等研究不变量。报告只使用能够从这些产物复算的数字。

[工程架构与扩展顺序](ARCHITECTURE.md)解释这些小模块怎样对应更完整的研究和交易系统。先把真实数据的可见时间、标签成熟与会计做可靠，再扩展框架或模型。
