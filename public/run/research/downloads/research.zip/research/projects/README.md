# 教学项目总览

两个项目共享“数据 → 特征/信号 → 组合 → 成本 → 报告”的研究语言，但刻意采用不同层面的输入。项目架构与成熟框架的对应关系见 [`ARCHITECTURE.md`](ARCHITECTURE.md)。

| 项目 | 两个完整项目日 | 主要学习内容 | 默认数据 |
|---|---:|---|---|
| `alpha_research` | Day 7–8 | 传统 alpha、跨资产、再平衡、权重约束、成本、回撤和失败分析 | 确定性合成资产价格 |
| `ml_llm_research` | Day 11–12 | 时间切分、Ridge baseline、rank IC、文本对齐、词典/可选语义增量 | 确定性合成 panel 和 filing 文本 |

先完成每个项目 README 中的概念思考和手动工程选择，再运行默认代码。默认结果可能不好看，这正是为了让学习者练习 benchmark、成本和失败分析，而不是追逐一条漂亮曲线。

项目使用小而透明的实现，不复制 Qlib、Lean、vectorbt 或其他框架。完成基础版本后，再根据 README 的提高方向接入真实公开数据或更复杂模型。

## 一次运行两个稳定 baseline

在 `research/.venv` 中执行：

```bash
cd research
uv pip install -r projects/alpha_research/requirements.txt
uv pip install -r projects/ml_llm_research/requirements.txt
research/.venv/bin/python projects/run_all.py --output-root /tmp/qbasic-baseline
```

命令会创建 `/tmp/qbasic-baseline/alpha_research/` 和 `ml_llm_research/`，每个目录包含 CSV、JSON 和 `run_manifest.json`。后者保存配置、Python/runtime 信息和每个产物的 SHA-256，可用来检查两次运行是否真的一致。单独运行项目仍然是推荐的调试方式。

## 互动实验入口

- [`alpha_research/project_lab.ipynb`](alpha_research/project_lab.ipynb)：趋势 alpha、成本敏感性、暴露和 benchmark；示例图在 [示例图](alpha_research/reports/lab_alpha_equity.png)。
- [`ml_llm_research/project_lab.ipynb`](ml_llm_research/project_lab.ipynb)：validation/test、文本增量、成本压力和 \(as-of\) 审计；示例图在 [示例图](ml_llm_research/reports/lab_ml_test_equity.png)。

每个 lab 都要求先运行固定 baseline，再只改变一个参数，运行前写预期，运行后把证据写进 memo。这样 notebook 负责互动探索，`src/` 负责可复用逻辑，`tests/` 负责不变量，manifest 负责复现。
