# 两个项目的研究工程架构对照

这两个项目现在是**可复现的 teaching baseline**：它们可以稳定生成同一组数据、权重/预测、成本敏感性和指标，并且能用测试保护研究中最容易犯的时间与会计错误。它们还不是可直接连接券商的生产系统。这个边界必须保留，因为面试时清楚说明“已经实现什么、还缺什么”比把一个小回测包装成 production platform 更可信。

## 1. 从成熟框架反推研究链路

| 研究层 | 本仓库的教学组件 | Qlib 的对应物 | QuantConnect LEAN 的对应物 | 仍然缺少的生产能力 |
|---|---|---|---|---|
| Data contract / point-in-time | `src/data.py`、`DataConfig`、`panel.csv` | Data Handler / Dataset | Security subscriptions、data feeds | 真实 corporate actions、历史 point-in-time 数据、实体/版本主键 |
| Feature / alpha | `features.py`、`text_features.py` | Expression / Processor | Alpha / Insight | 特征注册表、离线缓存、缺失与覆盖率监控 |
| Model / signal | `models.py`、`signal_to_weights` | Model / Forecast | Alpha model | 模型 registry、滚动训练、漂移检测 |
| Portfolio / sizing | `weights`、top-bottom portfolio | Portfolio / Risk model | Portfolio construction / Risk management | 组合优化、融资融券、保证金、容量约束 |
| Execution / accounting | `backtest.py`、`evaluate.py` | Backtest / Exchange simulator | Transaction / Execution / Brokerage | order lifecycle、部分成交、队列、真实 TCA、交易所规则 |
| Evaluation | `metrics.py`、rank IC、成本矩阵 | Recorder / Analysis | Statistics / Reports | 多重检验、purged/embargo、真实 benchmark、归因服务 |
| Lineage / reproducibility | `run_manifest.json`、固定 seed、CSV/JSON | Recorder / experiment record | Object store / backtest results | MLflow/DVC、远程 artifact store、CI、权限与审计 |
| Monitoring / deployment | README 中的 production gates | production extensions | live algorithm / monitoring | paper/shadow/live、告警、回滚、kill switch |

参考入口（均为公开资料）：

- [Microsoft Qlib](https://github.com/microsoft/qlib)：data handler、dataset、model、strategy、backtest、recorder 的完整研究框架；
- [QuantConnect LEAN](https://github.com/QuantConnect/Lean)：algorithm、data、portfolio、transaction、execution、brokerage 的事件驱动系统；
- [vectorbt](https://github.com/polakowo/vectorbt)：适合快速向量化研究和参数矩阵，不等于真实交易撮合器；
- [MLflow Tracking](https://mlflow.org/docs/latest/ml/tracking/) 与 [DVC](https://dvc.org/doc)：分别对应实验记录与数据/产物版本管理；
- [Hydra](https://hydra.cc/) / [Pydantic](https://docs.pydantic.dev/)：成熟项目常用的配置组合和 schema 校验思路。

项目没有复制这些框架；上表用于回答“一个小项目在大系统中的位置是什么”，也用于决定下一步学习顺序。

## 2. 当前项目已经能稳定保证什么

默认路径不访问网络，seed、日期区间、窗口、成本和模型开关都进入配置。每次运行会在输出目录写入：

- 数据/预测/回测 CSV；
- `metrics.json`（Project A 的多成本摘要，Project B 的 test 摘要）；
- Project B 的 `validation_metrics.json` 和带 `split` 列的 `predictions.csv`；
- `run_manifest.json`：配置、运行时、每个产物的字节数和 SHA-256。

因此一个 baseline run 可以被复制、比较和审阅。manifest 中的 hash 只覆盖本次生成的文件，不把运行时间写进结果，所以适合检查两个运行是否真的产生了相同的研究产物。

## 3. 还没有实现的部分

以下内容明确留在 roadmap 中，不能从当前输出推断已经完成：

1. 合成数据不是历史市场数据；没有退市、复权、期货换月、时区和修订数据的 point-in-time 适配器。
2. 成本是教学用线性 bps；没有盘口、成交队列、部分成交、borrow、margin 或交易所撮合。
3. 没有在线服务、brokerage connector、paper/live account、监控和 kill switch。
4. 没有把每次运行送入 MLflow/DVC；manifest 是本地、轻量的替代物。
5. Project B 默认只展示固定 chronological split；真实重叠标签需要 purged/embargo 和滚动训练。

## 4. 推荐的升级顺序

完成两个教学项目后按下面顺序升级，每一步都保留旧 baseline：

1. **Data adapter**：接入公开 ETF/SEC 数据，先建立 schema、时间、复权、实体 ID 和缺失报告；
2. **Research matrix**：用同一 `run_manifest` 批量保存 lookback、成本、coverage 和 exposure 的实验矩阵；
3. **Validation**：加入滚动训练、purged/embargo、真实 out-of-sample 锁定；
4. **Portfolio/TCA**：加入 beta/sector neutralization、order/ADV 冲击、borrow 和容量；
5. **Experiment store**：把本地 manifest 迁移到 MLflow/DVC，并在 CI 中运行不变量测试；
6. **Paper/shadow**：最后才接 LEAN/券商模拟、监控和回滚规则。

每次升级都要回答同一组面试问题：信息何时可得？预测如何变成仓位？成交如何发生？成本和容量怎样改变结论？出了异常怎样停止？

## 5. 学习者的互动闭环

每个项目的 `project_lab.ipynb` 都遵循五步：

1. 先运行固定 baseline，保存 manifest；
2. 在 notebook 中只改变一个参数，并在运行前写下预期；
3. 运行并查看图、分组表和 validation/test 差异；
4. 回到代码模块定位变化来自 data、feature、portfolio、cost 还是 metric；
5. 把结论写入 `reports/memo_template.md`，包括支持证据和失败条件。

这套闭环使 notebook 用于探索，`src/` 用于可复用逻辑，`tests/` 用于不变量，`run_manifest.json` 用于复现；四者各自职责不同。
