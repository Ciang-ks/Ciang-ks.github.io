"""Run both teaching baselines and check that their manifests exist.

This is intentionally a thin orchestrator, not a workflow engine. It keeps the
two projects independently runnable while providing one command for a learner
to produce a complete baseline bundle.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def run_project(name: str, output_root: Path | None, semantic: bool = False) -> Path:
    project = ROOT / name
    command = [sys.executable, "-m", "src.run"]
    if output_root is not None:
        destination = output_root / name
        destination.mkdir(parents=True, exist_ok=True)
        command += ["--output-dir", str(destination)]
    else:
        destination = project / "outputs"
    if name == "ml_llm_research" and semantic:
        command.append("--semantic")
    print(f"\n=== {name} ===")
    subprocess.run(command, cwd=project, check=True)
    manifest = destination / "run_manifest.json"
    if not manifest.exists():
        raise FileNotFoundError(f"baseline did not create {manifest}")
    payload = json.loads(manifest.read_text(encoding="utf-8"))
    print(f"manifest: {manifest}")
    print(f"artifacts: {len(payload.get('artifacts', {}))}")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Run both research research baselines")
    parser.add_argument(
        "--output-root",
        type=Path,
        default=None,
        help="optional directory; writes alpha_research/ and ml_llm_research/ below it",
    )
    parser.add_argument(
        "--semantic",
        action="store_true",
        help="also request Project B's optional local semantic provider",
    )
    args = parser.parse_args()
    if args.output_root is not None:
        args.output_root = args.output_root.expanduser().resolve()
        args.output_root.mkdir(parents=True, exist_ok=True)
    manifests = [
        run_project("alpha_research", args.output_root),
        run_project("ml_llm_research", args.output_root, semantic=args.semantic),
    ]
    print("\nBaseline bundle complete:")
    for manifest in manifests:
        print(f"- {manifest}")


if __name__ == "__main__":
    main()
